#!/bin/sh
echo "Do a Build Continuously"
cd /Users/antoinerosset/InsightToolkit-2.2.0
if [ -e continuous.lock ]
then exit;
else
date >continuous.lock
"/usr/bin/tclsh" "DART_ROOT-NOTFOUND/Source/Client/DashboardManager.tcl" DartConfiguration.tcl Continuous Start Update Configure Build Test Submit 2>&1 > "/Users/antoinerosset/InsightToolkit-2.2.0/Testing/Continuous.log"
rm continuous.lock
rm -f /Users/antoinerosset/InsightToolkit-2.2.0/Testing/Temporary/*
fi
