Insight/Applications README
---------------------------

The Insight/Applications directory has been moved to a separate CVS checkout.
Please check out InsightApplications using the following commands:

cvs -d :pserver:anonymous@www.itk.org:/cvsroot/Insight login
  -> password insight

cvs -d :pserver:anonymous@www.itk.org:/cvsroot/Insight  co InsightApplications


See the README.txt file in InsightApplications for further instructions.
