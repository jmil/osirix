/*=========================================================================

  Program:   Insight Segmentation & Registration Toolkit
  Module:    $RCSfile: itkTestStreamLongLong.cxx.in,v $
  Language:  C++
  Date:      $Date: 2005/01/22 21:02:11 $
  Version:   $Revision: 1.1 $

  Copyright (c) Insight Software Consortium. All rights reserved.
  See ITKCopyright.txt or http://www.itk.org/HTML/Copyright.htm for details.

     This software is distributed WITHOUT ANY WARRANTY; without even
     the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
     PURPOSE.  See the above copyright notices for more information.

=========================================================================*/
#if defined(_MSC_VER)
# pragma warning (push, 1)
#endif

// Include the streams library.
/* #undef ITK_USE_ANSI_STDLIB */
#if defined(ITK_USE_ANSI_STDLIB)
# include <iostream>
using std::ostream;
using std::istream;
using std::cout;
using std::cin;
#else
# include <iostream.h>
#endif

#if defined(_MSC_VER)
# pragma warning (pop)
#endif

#if defined(ITK_TEST_OSTREAM_LONG_LONG)
int test_ostream(ostream& os, long long x)
{
  return (os << x)? 1:0;
}
#endif

#if defined(ITK_TEST_ISTREAM_LONG_LONG)
int test_istream(istream& is, long long& x)
{
  return (is >> x)? 1:0;
}
#endif

int main()
{
#if defined(ITK_TEST_OSTREAM_LONG_LONG)
  long long x = 0;
  return test_ostream(cout, x);
#endif
#if defined(ITK_TEST_ISTREAM_LONG_LONG)
  long long x;
  return test_istream(cin, x);
#endif
}

