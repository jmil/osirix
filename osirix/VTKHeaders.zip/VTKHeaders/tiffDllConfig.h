#ifndef _tiffDllConfig_h
#define _tiffDllConfig_h

/* #undef TIFFDLL */
/* #undef TIFFSTATIC */

#endif
