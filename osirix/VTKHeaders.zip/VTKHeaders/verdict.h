#ifndef VERDICT_PRECONF_INCLUDE
#define VERDICT_PRECONF_INCLUDE

#define VERDICT_VERSION 120

/* #undef BUILD_SHARED_LIBS */

#ifdef BUILD_SHARED_LIBS
# define VERDICT_SHARED_LIB
#endif

#endif

#include <include/verdict.h>
