#ifndef _jpegDllConfig_h
#define _jpegDllConfig_h

/* #undef JPEGSTATIC */

#endif
