#ifndef __vtk_SystemInformation_h
#define __vtk_SystemInformation_h

#define VTK_BINARY_DIR "/Users/antoinerosset/vtk"
#define CMAKE_BINARY_DIR "/Users/antoinerosset/vtk"

#endif
