#ifndef VLIPERSPECTIVE_H
#define VLIPERSPECTIVE_H

/*****************************************************************************
 *
 * $Id: vliperspective.h,v 1.5 2004/10/19 17:07:05 vesper Exp $
 *
 *	Structure to pass perspective parameters into VLI
 *
 *    Copyright 2002,2003,2004 by Real Time Visualization, TeraRecon, Inc.
 *    All Rights Reserved.
 *****************************************************************************/

class VLIMiniFrustum
{
public:
	VLIVector3D		mNearPoly[4];		// Near and far viewing polygons
	VLIVector3D		mFarPoly[4];		//   (usually coplanar with volume faces)
	VLIVector3D		mEyePoint;			// Eye Point
	VLIVector3D		mSightPoint;		// SightPoint
	int				mDimXs;				// Volume size
	int				mDimYs;
	int				mDimZs;
	int				mSectionSizeX;		// Section size
	int				mSectionSizeY;
	unsigned int	mTransform;			// The actual permutation transform register
	double			mMinD;				// Minimum depth to generate (0 to 1)
	double			mMaxD;				// Maximum depth to generate (0 to 1)
};

#endif // VLIPERSPECTIVE_H
