/*****************************************************************************
 *
 * $Id: vlisamplespace.h,v 1.68 2004/10/19 17:07:07 vesper Exp $
 *
 *	Given traditional graphical space transformations, derive register values
 *	of Condor Volume spaces.
 *
 *    Copyright 2001,2002,2003,2004 by Real Time Visualization, TeraRecon, Inc.
 *    All Rights Reserved.
 *****************************************************************************/


#ifndef VLISAMPLESPACE_H
#define VLISAMPLESPACE_H

#define qScaleACLut         1 //Should enable, disable syncrnously with vlisamplespace.h, vlivolumeRender.cpp

#include "vliperspective.h"
#include "VLIRational.h"

static const int kVLIGradientMagLutSize = 128;
static const int kVLIGradientMagLutSize64 = kVLIGradientMagLutSize /2; // 2 entries per VLIuint64:62
static const int kVLIGradientMagLutSizeBytes = kVLIGradientMagLutSize64 * 8;

static const int kVLIAlphaLUTSize = 96;
static const int kVLIAlphaPreLUTSize = 16;
static const int kVLIAlphaCorrectionLutSize64 = (kVLIAlphaLUTSize + kVLIAlphaPreLUTSize)/2; //2 entries per VLIuint64:
static const int kVLIAlphaCorrectionLutSizeBytes =  kVLIAlphaCorrectionLutSize64 * sizeof (VLIuint64);
static const int kVLIHalfAlphaValue = 2048;
static const int kVLIHalfAlphaCorrectSize = kVLIHalfAlphaValue + 128;

// constants needed for programming the hardware

static const int kWorkingdZv_dZsBits		= 4;
static const int kWorkingdZv_dZsPrecision	= 1 << kWorkingdZv_dZsBits;

static const VLIint32 kMinTrimValueRational = -0x3ffeff;
static const VLIint32 kMaxTrimValueRational =  0x3ffeff;

static const VLIuint32 kHwDepthRange = kVLIMaxDepthValue;
//static const VLIuint64 kStepRounding  	= (1 << 22);
//static const VLIuint64 kOriginRounding	= (((VLIuint64)(1) << 31) | (1 << 22));
//static const VLIuint64 m_numOfRenderBrick = ((VLIuint64)(1) << 31);

#define	UINT64_ZERO		UINT64_CONST(0)
#define	UINT64_ONE		UINT64_CONST(1)
#define UINT64_ALL_ONES	(~UINT64_ZERO)

static const VLIint32 ZERO_S23_8	=	(0L << 8);
static const VLIint32 ONE_S23_8		=	(1L << 8);
static const VLIint32 HALF_S23_8	=	(1L << 7);
static const VLIint32 NEG_HALF_S23_8 =	(-1L << 7);

static const VLIint64 ZERO_S23_40		= INT64_CONST(0);
static const VLIint64 ONE_EIGHTH_S23_40 = INT64_CONST(1) << 37;
static const VLIint64 ONE_QUARTER_S23_40 = INT64_CONST(1) << 38;
static const VLIint64 ONE_HALF_S23_40	= INT64_CONST(1) << 39;
static const VLIint64 ONE_S23_40		= INT64_CONST(1) << 40;
static const VLIint64 TWO_S23_40		= INT64_CONST(2) << 40;

static const VLIint64 ZERO_S31_32		= INT64_CONST(0) << 32;
static const VLIint64 ONE_S31_32		= INT64_CONST(1) << 32;

//Clear the sub voxel bits of origin at each pass of multiple rendering
static const VLIuint64 kOriginZClear = (UINT64_ALL_ONES << 40);
//Clear the lower sub voxel bits of dZv_dZs 
static const VLIuint64 kdZv_dZsClear = (UINT64_ALL_ONES << (40-kWorkingdZv_dZsBits));


static const VLIuint64 kDepthStepRounding	= UINT64_ONE << 22;
static const VLIuint64 kDepthOriginRounding = (UINT64_ONE << 31) | (UINT64_ONE << 22);

//Yin 01/15/02 RenderHang Fix Try, set all rounding into 0
static const VLIuint64 kStepRounding		=	UINT64_ZERO;
static const VLIuint64 kOriginRounding		=	UINT64_ZERO;
static const VLIuint64 kOriginZRounding		=	UINT64_ZERO;

static const VLIuint64 kReg2PipeFormatMask			= UINT64_ALL_ONES << 23;	// X and Y
static const VLIuint64 kReg2PipeHangFix				= UINT64_ONE      << 23;	// Z
static const VLIuint64 kReg2SubVoxelFormatMask		= UINT64_ALL_ONES << 32;	// Z needs more 0 bits

//Currrently, we only support support ZsuperSampling upto 1/16
static const int kTrimOffsetOriginSlab	=	16;					

//Set Transform 
static const VLIuint8 transformNegX_shift = 0;
static const VLIuint8 transformNegY_shift =	1;
static const VLIuint8 transformNegZ_shift =	2;
	
static const VLIuint8 transformSelectX_shift =	4;
static const VLIuint8 transformSelectY_shift =	6;
static const VLIuint8 transformSelectZ_shift =	8;

template <class T> class Range;

class VLIVolumeInternal;

class VLISampleSpace
{
public:
	enum VGAxis 
	{
		kU = 0,
		kV = 1,
		kW = 2
	};
	
	enum VGNeg 
	{
		kNotNeg = 0,
		kIsNeg =1
	};

	

	VLISampleSpace ();

	// void Clear(){};

	
	//XY Image order, matrix format
	////////////////////////////////////////////////////////////////////////////////////
	//If we fixed dD_dZs: kFixedD_dZSampling
	//						indZv_dZsOrdD_dZs		=	dD_dZs
	//
	//
	//If we fixed dZv_dZs: kFixedZsSampling
	//						indZv_dZsOrdD_dZs	=	dZv_dZs
	// ** TODO: in VLIContext, or VLIVolume we should have flag to specify different 
	//		interface using XY-Image Order Rendering
	//
	//////////////////////////////////////////////////////
	
	VLIStatus Assign(const VLIContext *inContext,
					VLIVolume *inVolume,
					VLIImageBuffer *inOutImage,
					bool &outIsNewSampleSpace, 
					bool inDepthTestOn);

	VLIStatus ObjectAssign(const VLIContext *inContext, 
					   VLIVolume *inVolume,
					   VLIImageBuffer *outputImage, 
					   bool & outIsNewSamplespace, const VLIVector3D &inSampling);



	~VLISampleSpace() { }
	
	// Note -- the hardware limits are -3fff.ff to +3fff.ff.
	// We limit to -3ffe.ff to +3ffe.ff here because we need
	// to add a bias when the permutation negates a direction.
private:
	
	
	static const VLIint32 ConvertTrimToInternal (double inValue)
	{ 
		const double kMaxTrimValue =  16382.99609375; //16383.0 - 1.0/256.0;
		const double kMinTrimValue = -kMaxTrimValue;

		if (inValue <= kMinTrimValue)
			return kMinTrimValueRational;
		if (inValue >= kMaxTrimValue)
			return kMaxTrimValueRational;
		return (FloatToS23F8(inValue, kVLIRound));
	}
public:

	VLIbool GetEyeOrViewInVoxelSpace(const VLIContext *inContext, VLIVolume *inVolume,
					VLIVector4D &outVector);
	
	static const VLIStatus ConvertTrimRange(const double inTrimMin[3], const double inTrimMax[3],
		VLIint32 outTrimMin[3], VLIint32 outTrimMax[3])
	{
		for (int i = 0; i < 3; i++)
		{
			outTrimMin[i] = VLISampleSpace::ConvertTrimToInternal(inTrimMin[i]);
			outTrimMax[i] = VLISampleSpace::ConvertTrimToInternal(inTrimMax[i]);
		}
		
		return kVLIOK;
	}
	
	
	VLIStatus ComputeTrimRange(
		const double inTrimMin[3],const double inTrimMax[3],
		VLIint32 outTrimMin[3], VLIint32 outTrimMax[3]);

	VLIStatus ComputeCropFlags (int inFlags, int & outFlags);
	VLIuint32 ComputeExtendFlags (VLIuint32 inInterpControl);

	VLIStatus ComputeCutplaneRegisters(const VLIContext *inContext,
										  VLIVolume *inVolume,
										  bool outEnable[4],
										  bool outFallOff[4],
										  VLICutPlane::Flags outInsideOrOutside[4],
										  VLIint32 out_d_cut_dXs[4],
										  VLIint32 out_d_cut_dYs[4],
										  VLIint32 out_d_cut_dZs[4],
										  VLIint32 out_d_cut_dZv[4],
										  VLIint32 outDmin[4],
										  VLIint32 outDmax[4]);

	VLIStatus ComputeCutplaneRegistersAndChecking(const VLIContext *inContext,
										  VLIVolume *inVolume,
										  bool outEnable[4],
										  bool outFallOff[4],
										  VLICutPlane::Flags outInsideOrOutside[4],
										  VLIint32 out_d_cut_dXs[4],
										  VLIint32 out_d_cut_dYs[4],
										  VLIint32 out_d_cut_dZs[4],
										  VLIint32 out_d_cut_dZv[4],
										  VLIint32 outDmin[4],
										  VLIint32 outDmax[4],
										  double &outScaleFallOffFactor);


	VLIStatus ComputeSampleSpaceRegisters(VLIuint32 & outTransform,
		VLIint64 & outOriginXv8,
		VLIint64 & outOriginYv8,
		VLIint64 & outOriginZv8,
		VLIint64 & out_dXv8_dXs,
		VLIint64 & out_dXv8_dYs,
		VLIint64 & out_dXv8_dZs,
		VLIint64 & out_dYv8_dXs,
		VLIint64 & out_dYv8_dYs,
		VLIint64 & out_dYv8_dZs,
		VLIint64 & out_dZv8_dZs,
		VLIint64 & out_dXv8_dZv,
		VLIint64 & out_dYv8_dZv,
		VLIuint8 outSectionSize[2]);
	
	VLIStatus ComputePerspectiveRegisters(
		VLIint64& out_ddXv8_dXs_dZs,
		VLIint64& out_ddXv8_dYs_dZs,
		VLIint64& out_ddYv8_dXs_dZs,
		VLIint64& out_ddYv8_dYs_dZs,
		VLIint64& out_ddXv8_dXs_dZv,
		VLIint64& out_ddXv8_dYs_dZv,
		VLIint64& out_ddYv8_dXs_dZv,
		VLIint64& out_ddYv8_dYs_dZv);

	VLIStatus SetMiniFrustum(VLIMiniFrustum& inFrustum)
	{
		m_miniFrustum = &inFrustum;
		return kVLIOK;
	}

	VLIMiniFrustum& GetMiniFrustum(void) const
	{
		return *m_miniFrustum;
	}

	VLIStatus  ComputeSampleSpaceRegistersOfMultiZSlicePass(
		VLIint64 & outOriginXv8,
		VLIint64 & outOriginYv8,
		VLIint64 & outOriginZv8,
		VLIint64 & outOriginDepth,
		VLIint64 & out_dXv8_dXs,
		VLIint64 & out_dXv8_dYs,
		VLIint64 & out_dYv8_dXs,
		VLIint64 & out_dYv8_dYs);

	VLIStatus  ComputeSampleSpaceRegistersWithTrimOffset(VLIint32 inTrimZ[2],
		VLIint64 & outOriginXv8,
		VLIint64 & outOriginYv8,
		VLIint64 & outOriginZv8,
		VLIint64 & outOriginDepth,
		VLIint64 & out_dXv8_dXs,
		VLIint64 & out_dXv8_dYs,
		VLIint64 & out_dYv8_dXs,
		VLIint64 & out_dYv8_dYs,
		bool     & outShiftOrigin
		);
	
	
	VLIStatus  ComputePostWarpRegisters(VLIuint32 & outTransform, 
		VLIint64 & outOriginXv8,
		VLIint64 & outOriginYv8,
		VLIint64 & outOriginZv8,
		VLIint64 & out_dXv8_dXs,
		VLIint64 & out_dXv8_dYs,
		VLIint64 & out_dXv8_dZs,
		VLIint64 & out_dYv8_dXs,
		VLIint64 & out_dYv8_dYs,
		VLIint64 & out_dYv8_dZs,
		VLIint64 & out_dZv8_dZs,
		VLIint64 & out_dXv8_dZv,
		VLIint64 & out_dYv8_dZv,
		VLIuint8 outSectionSize[2]);


	VLIStatus  ComputeTrimOfMultiZSlicePass(
		VLIint32 & inOutTrimMinZ, 
		VLIint32 & inOutTrimMaxZ);

	VLIStatus ComputeCutplanesOfMultiZSlicePass(
		const VLIint32 inCutZs[4],
		VLIint32 inOutDMin[4],
		VLIint32 inOutDMax[4]);

	VLIStatus ComputeCutplanesOfSpaceLeapingPass(
		const VLIint32 inCutZs[4],
		VLIint32 inOutDMin[4],
		VLIint32 inOutDMax[4]);

	void SetCutplanesForSpaceLeapingPass( // design to minimaze clutter in caller.
		VLIint32 cp0_min, VLIint32 cp0_max, VLIint32 cp1_min, VLIint32 cp1_max, 
		VLIint32 cp2_min, VLIint32 cp2_max, VLIint32 cp3_min, VLIint32 cp3_max);

	VLIStatus ComputeDepthWarpRegisters(
		VLIint64 & outDepthOrigin,
		VLIint64 & out_dD_dXs,
		VLIint64 & out_dD_dYs,
		VLIint64 & out_dD_dZs,
		VLIint64 & out_dD_dZv,
		VLIuint32 inDepthPrecision);

	bool SetTrimOffsetZSample(VLIint32 inTrimZ);

	VLIStatus ComputeEyeVector(VLIint16 outEyeVector[3], bool inGradientCorrection);
	VLIStatus ComputeGradientCorrection(VLIint16 outGradCorrection[6]);
	VLIStatus GetLightToWorldMatrix(VLIMatrix &outLightMatrix);
	VLIStatus GetEyeVectorInLightSpace(VLIVector3D &outEyeVector, VLIbool inGradientCorrection);
	
	VLIuint64 * GetCombinedAlphaCorrectionLUT(bool & outChanged);

	
	VLIStatus VP500Wrapper(VLIContext *inContext,
						   VLIVolume *inVolume,
						   unsigned int &outbaseWidthPow2Round,
						   unsigned int &outbaseHeightPow2Round,
						   unsigned int &outImageSizeX,
						   unsigned int &outImageSizeY,
						   VLIMatrix &outAdjustedProjectionMatrix,
						   VLIVector3D outHexagon[6],
						   VLIVector2D outTexture[6],
						   bool &outViewportSet);

	VLIStatus GetGeometryInEyeSpace(unsigned int &outbaseWidthPow2Round,
									unsigned int &outbaseHeightPow2Round,
									unsigned int &outImageSizeX,
									unsigned int &outImageSizeY,
									VLIVector3D outHexagon[6],
									VLIVector2D outTxtVertex[6]);

	VLIStatus ComputeSpaceLeapingSampleSpaceRegisters(
		VLIVolumeRange &inRange,
		VLIint32 inEdgeMin[3],
		VLIint32 inEdgeMax[3], 
		VLIint64 & outOriginXv8,
		VLIint64 & outOriginYv8,
		VLIint64 & outOriginZv8,
		VLIint64 & outOriginDepth,
		VLIint32  outTrimMin[3],
		VLIint32  outTrimMax[3],
		bool & outNewSampleSpace
	);

	int ComputeSpaceLeapingPass(VLIVolumeRange &inRange){ return 1;}

	// Return the limits of the volume in sample space
	// Used for render and resample code


	VLIStatus ComputeTrimRangeViewFrustum( double inTrimMin[3], double inTrimMax[3], bool valid = false);

	VLIVolumeRange	GetVolumeFrustum (void)
	{
		return VLIVolumeRange (
					m_viewFrustumVolumeMax[0] + 1 - m_viewFrustumVolumeMin[0],
					m_viewFrustumVolumeMax[1] + 1 - m_viewFrustumVolumeMin[1],
					m_viewFrustumVolumeMax[2] + 1 - m_viewFrustumVolumeMin[2],
					m_viewFrustumVolumeMin[0],
					m_viewFrustumVolumeMin[1],
					m_viewFrustumVolumeMin[2]);
	}
	void VLISampleSpace::ComputeTrimVolumeRangeIntersection(const VLIContext * inContext,
										VLIVolumeRange &fullRange,
										double doubleMin[3], 
										double doubleMax[3]);


	// Return the values computed for testing for CantSubsample error
	// Used for render and resample code

	void			GetSubSampleTests (double &outX, double &outY)
	{ outX = m_subSampleTestX; outY = m_subSampleTestY; }

	// Keep track of output volume and mode from RenderToVolume

	void			SetRenderToVolume (VLIVolume* inVolume)
	{ m_renderToVolume = inVolume; }

	VLIVolume*		GetRenderToVolume (void) const
	{ return m_renderToVolume; }

	void			SetRenderToVolumeMode (VLIVolume::RenderToVolumeMode inMode)
	{ m_renderToVolumeMode = inMode; }

	VLIVolume::RenderToVolumeMode	GetRenderToVolumeMode (void) const
	{ return m_renderToVolumeMode; }

		VLIVector4D		m_samplingSizeInPermuted;
private:

	bool			DecomposeCorrectionMatrix();

	//Sub Volume Information
	bool			m_isValidSampleSpace;
	bool			m_isCorrectionReady;

	int				m_volumeMin[3];
	int				m_volumeMax[3];

	VLIVector4D		m_volumeVertices[8];
	VLIVector2D		m_polygonVertices[8];
	unsigned int	m_numberOfPolygonVertices;
	unsigned int	m_numberOfValidVertices;

	//View Information

	int				m_viewportWidth;
	int				m_viewportHeight;
	int				m_viewportMinX;
	int				m_viewportMinY;
	double			m_depthNear;
	double			m_depthFar;

	//Z super sampling factor
	double			m_ZSampleFactor;	// = dZv_dZs if Baseplane Space
										// otherwise, = dDv_dZs/unitMeasure
	
	
	//Sampling Limit
	double m_minXYSampling ;
	double m_maxXYSampling ;
	double m_minZSampling ;
	double m_maxZSampling ; 

	VLICoordinateSpace m_ZSampleSpace;

	//In object space 
	// Yin: 9/20/01 These two vectors are saved, UpVector not used afterwards
	VLIVector4D		m_viewUpInObjectSpace;
	VLIVector4D		m_viewVectorInObjectSpace;

	VLIVector4D		m_eyeVectorInLightSpace;

	//In Permuted Space


	VGAxis			m_primaryAxis;
	VGAxis			m_select[3]; //SelectX, SelecY, SelectZ;
	VGNeg			m_neg[3]; //	NegX,   negY,	negZ

	VLIuint64		m_ACLuT[kVLIAlphaCorrectionLutSize64];
	double			m_lastACLUTExponent;



	double			m_subSampleTestX;		// values computed for testing for
	double			m_subSampleTestY;		// cantsubsample error

	VLIVolume*						m_renderToVolume;		// Output of a RenderToVolume call
	VLIVolume::RenderToVolumeMode	m_renderToVolumeMode;	// Special RenderToVolume mode

public:
	// Yin 9/19/01, following two variables are added to
	//support future optimization of window range

	// move to public to support optimization of window range, 
	// used in vlivolumerender.cpp

	int m_minXsVsPermutedIndex[3];
	int m_minYsVsPermutedIndex[3];

	VLIint32		m_viewFrustumVolumeMin[3];
	VLIint32		m_viewFrustumVolumeMax[3];

	VLIint32		m_wholeVolumeViewFrustumMax[3];
	VLIint32		m_wholeVolumeViewFrustumMin[3];

	VLIint32		m_viewFrustumSpaceLeapingMin[3];
	VLIint32		m_viewFrustumSpaceLeapingMax[3];

	VLIint32		m_viewFrustumRangeMin[3];
	VLIint32		m_viewFrustumRangeMax[3];

	// Matrices

	//////////////////////////////////////////////
	//Permutation:
	
	VLIMatrix		m_permutation;
	// define Permut(axisP, axisObj) = Direct(axisP) * Selected(axisP, axisObj)
	// define Selected(axisP, axisObj) = (Select_axisP== axisObj?1:0)
	// define Direct(axisP) = Neg(axisP)?-1:1;

	//	| Permut(X,u), Permut(X,v),Permut(X, w), 0|
	//	| Permut(Y,u), Permut(Y,v),Permut(Y, w), 0|
	//	| Permut(Z,u), Permut(Z,v),Permut(Z, w), 0|
	//	|	0		 ,			0 ,    0	   , 1|

	/////////////////////////////////////////////////

	//////////////////////////////////////////////
	// Shear 
	VLIMatrix		m_shear;
	//	| dXs_dXv dXs_dYv dXs_dZv 0| | 1 0 0 -SampleOriginX |
	//	| dYs_dXv dYs_dYv dYs_dZv 0| | 0 1 0 -SampleOriginY |
	//	|	0		0	  dXs_dZv 0|*| 0 0 1 -SampleOriginZ |
	//	|	0		0		0	  1| | 0 0 0		1		|
	//

	// dXs_dYv == 0 & dYs_dXv == 0 for object order

	VLIMatrix		m_correctedModelViewMatrix;
	VLIMatrix       m_correctedModelMatrix;
	VLIMatrix		m_projectionMatrix;
	VLIMatrix		m_viewportMatrix;
	VLIMatrix		m_correctionMatrix;
	VLIMatrix		m_postWarp;


#if qScaleACLut 
	double			m_maxSampleDistance;
	double			m_ACLutScale[kVLIAlphaLUTSize];
	double          m_alphaScale[kVLIHalfAlphaCorrectSize];

	int    			m_ACLutScaledMaxId;
	int             m_ACLutScaledMaxAlpha;
	bool            m_isACLutInitReady;
	bool            IsAlphaCorrectionLUTSNeedToScale(
							bool inExponentChanged,
							int& outUpScaleLimitOfAlpha, 
							double * &outACLutScaleList); 
#endif

	VLIMatrix		m_VP_VM_CRMVMatrix;			//ViewPort-ViewMapping-CorrectedModelView Matrix
	VLIMatrix		m_voxelToLightSpaceMatrix;	// Matrices used for Gradient Correction, 
	VLIMatrix       m_lightToWorldSpaceMatrix;

	///////////////////////////////////////////
	// Transformation from sample space into permuted space
	VLIMatrix		m_dv_dsMatrix;

	//////////////////////////////////////////////
	//	| dXv_dXs dXv_dYs dXv_dZs SampleOriginX |

	//	| dYv_dXs dYv_dYs dYv_dZs SampleOriginY |
	//	|	0		0	  dZv_dZs SampleOriginZ |
	//	|	0		0		0			1		|
	//
	
	// dXv_dYs == 0 & dYv_dXs == 0 for object order


	////////////////////////////////////////////////////////////
	// Double deltas for perspective
	double			m_ddXv_dXs_dZs;
	double			m_ddXv_dYs_dZs;
	double			m_ddYv_dXs_dZs;
	double			m_ddYv_dYs_dZs;

	////////////////////////////////////////////////////////////
	// Perspective data for generating this scene
	VLIMiniFrustum*	m_miniFrustum;


	////////////////////////////////////////////////////////////
	//Warp:Transform from sample space to eye space
	// warp = CorrectedModelView * m_dv_dsMatrix *m_permutation.Inverse()
	// Used to support Object Order Rendering
	VLIMatrix		m_depthWarp;


	////////////////////////////////////////////////////////////
	//WarpPlus: Transform from sample space to image space
	//		m_depthWarp = m_VP_VM*m_dv_dsMatrix *m_permutation.Inverse()
	// for	 XY-Image order
	//	|	1		0		0		0|
	//	|	0		1		0		1|
	//	| dD_dXs dD_dYs	dD_dZs Depth0|
	//	|	0		0		0		1|

	// Render Hang Workarounds
              
	// Hold the sample origin of TrimZMin plane, 
	// Whole holding the origin of whole volume at dv_ds matrix
	// When TrimZ changes, update these value similar to multiple pass

	VLIint64        m_originXv8; 
    VLIint64        m_originYv8;
	VLIint64        m_originZv8;
	VLIuint32		m_trimOffsetZSlices;

	int             m_pciRev;
	int				m_renderPass;
	int				m_renderZSlices;
	int				m_depthZSlices;
	VLIint32		m_trimMinZ, m_trimMaxZ;
	VLIint32		m_wholeTrimMin[3], m_wholeTrimMax[3];
	VLIint64		m_depthOrigin;
	VLIint64		m_dD_dZs;
	bool			m_cutplaneEnable[4];
	bool			m_backToFront;
	bool			m_isPerspective;

	int		        m_prevZSliceOffset;

	VLIint32		m_firstSpaceLeapingCutDmin[4];
	VLIint32		m_firstSpaceLeapingCutDmax[4];
};
#endif
