/*
 * $Id: ClipCubeST3H.h,v 1.5 2003/01/09 18:36:46 ford Exp $
 *
 *    Copyright 2002 by Real Time Visualization, TeraRecon, Inc.
 *    All Rights Reserved.
 *
 */  
// ClipCubeST3H - Clip version of CubeST3H Object
//  returns polygons moved "inward" due to near Clipping Planes
#ifndef CLIPCUBEST3H_H
#define CLIPCUBEST3H_H


class ClipCubeST3H: public CubeST3H {
public:

  // Constructors
  ClipCubeST3H (void);

  ClipCubeST3H (PointST3H &min, PointST3H &max);

  // Operate on the Clip Cube

  // Get the Distance to the Clip Cube from the current Viewpoint, and direction
  double GetCubeDist (int inNearSide, PointST3H inViewpoint);
  double GetCubeDist (int inNearSide);

  // Get the distance to the far side of the cube
  double GetFarCubeDist (int inNearSide);

  // Update a Dimension of the Internal ClipCube
  //   Return whether anything's visible
  bool SetClipCube (int inNearSide, double inMinDist, double inMaxDist);

  // Create Near Polygon, from the Original Volume (not Clipped)
//  PolygonST3H GetNearPoly (int inNearSide);

  // Create Near Polygon, from Clipped Volume
  PolygonST3H GetNearClipPoly (int inNearSide);

  // Create Far Polygon, from the Original Volume (not Clipped)
  PolygonST3H GetFarPoly (int inNearSide);

  // Get the Zv value of the Near Clip Polygon
  double GetNearClipPolyDist (int inNearSide);

  // Get the Zv value of the Far Polygon
  double GetFarPolyDist (int inNearSide);

  // Get, Set
  // Set the Viewpoint in use
  void SetViewpoint (PointST3H inViewpoint);

  // Get the ClipCube (two Points)
  void GetClipCube (PointST3H &outClipMin, PointST3H &outClipMax);

  // Get the ClipCube Dimensions
  PointST3H GetClipMin (void);
  PointST3H GetClipMax (void);

private:

  // Clipped version of mDimMin, mDimMax from Base CubeST3H Class
  PointST3H mClipMin, mClipMax;

  // The current viewpoint, which is used to determine clip distance
  //  when the direction of viewing is known
  PointST3H mViewpoint;
};
#endif
