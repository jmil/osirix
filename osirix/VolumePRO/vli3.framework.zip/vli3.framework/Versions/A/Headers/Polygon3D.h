/*
 * $Id: Polygon3D.h,v 1.2 2002/10/14 21:03:38 vesper Exp $
 *
 *    Copyright 2002 by Real Time Visualization, TeraRecon, Inc.
 *    All Rights Reserved.
 *
 */  
// Polygon3D.h - Polygon Object with Point3D (x,y,z) Vertices
#ifndef POLYGON3D_H
#define POLYGON3D_H

#define POLY_MAXVERTS 16

class Polygon3D {
public:

  // Constructors
  // No initial verts, use AddVert (), below
  Polygon3D ();

  // Three Sided
  Polygon3D (Point3D &v1, Point3D &v2, Point3D &v3);

  // Four Sided
  Polygon3D (Point3D &v1, Point3D &v2, Point3D &v3, Point3D &v4);

  // Get a Vertex of the Polygon
  Point3D operator [](int);

  // Operate on the Polygon

  // Add a Vertex to the Polygon
  int AddVert (Point3D &v1);

  // Replace a given Vertex with new information
  int ReplaceVert (Point3D &inVert, int inVertNum);

  // Scale the Vertices
  // <<< Consider defining a Vect3, and using it instead of Point3D>>>
  void Scale3D (Point3D &inMult3D);

  // Get surrounding XYZ Box
  Box3D GetBoxXYZ (void);

  // Update surrounding XYZ Box, given an Initial XYZ Box
  void UpdBoxXYZ (Box3D &inBox);

  // Determine if the Polygon is Frontfacing
  bool FrontFacing (void);

  // Reverse the order of the Vertices to "Flip" a Polygon
  void Reverse (void);

  // Calculate the Centroid of the Polygon by averaging
  bool Centroid3D (Point3D &outCent3D);

  // Determine if the Polygon is Edge-on
  bool EdgeOn (void);

  // Get/Put
  // Get the number of Vertices
  int GetNumbVerts (void);

  // Set the number of Vertices
  void SetNumbVerts (int inNumbVerts);

  // Get whether polygon is Null, or non Null (has vertices)
  bool NonNull (void);

  // Get a Vertex (index starting at zero)
  // Point3D GetVertex (int vert);

  // Print
  // Print the Polygon
  void Print (void);

private:

  // Manage the number of Vertices stored
  int m_verts;

  // Store Vertices in an array, for now
  Point3D m_vert [POLY_MAXVERTS];
};
#endif
