/*
 * $Id: Box3D.h,v 1.3 2002/10/23 15:38:05 vesper Exp $
 *
 *    Copyright 2002 by Real Time Visualization, TeraRecon, Inc.
 *    All Rights Reserved.
 *
 */  
// Box3D.h - Box in X,Y,Z
// Used to calculate the min, max extent of a set of Points in X,Y,Z
#ifndef BOX3D_H
#define BOX3D_H

class Box3D {
public:

  // Constructor
  Box3D (void);
  Box3D ( const Point3D &inPoint);
  Box3D ( const Point3D &inMin,  const Point3D &inMax);

  // Operate on the Box

  // Update the box to be larger, to include the Point passed in
  void Update (double &inX, double &inY, double &inZ);

  // Update the box to be larger, to include the Point passed in
  void Update ( const Point3D &inPt);

  // Get/Put
  Point3D GetMin (void) const ;
  Point3D GetMax (void) const ;
  double GetMinX (void) const ;
  double GetMinY (void) const ;
  double GetMinZ (void) const ;
  double GetMaxX (void) const ;
  double GetMaxY (void) const ;
  double GetMaxZ (void) const ;

  void SetMin (Point3D &inPoint);
  void SetMax (Point3D &inPoint);
  void SetMinX (double &inX);
  void SetMinY (double &inY);
  void SetMinZ (double &inZ);
  void SetMaxX (double &inX);
  void SetMaxY (double &inY);
  void SetMaxZ (double &inZ);

private:

  // One Point stores the Min, one stores the Max
  Point3D m_min, m_max;
};
#endif
