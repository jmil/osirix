/*******************************************************************************

 THIS SOURCE FILE IS KEPT IN <CVSROOT>/common/RTVIZSystem.h
 any other file is just a shadow copy DO NOT EDIT SHADOW COPIES!

 $Id: RTVIZSystem.h,v 1.13 2004/10/21 21:15:44 vesper Exp $

      Copyright, Mitsubishi Electric Information Technology Center
      America, Inc., 1999, All rights reserved.
      CONFIDENTIAL AND PROPRIETARY PROPERTY OF MITSUISHI ELECTRIC ITA.
      
	  Copyright 2001,2002,2003,2004 by Real Time Visualization, TeraRecon, Inc.
      All Rights Reserved.

 Purpose:
        Define certain preprocessor macros describing the
        Operating System, Compiler and CPU.

        <compiler> is one of the following
        MICROSOFT, SUN, GNU, SGI

        #define RTVIZ_COMPILER <compiler>
        #define RTVIZ_COMPILER_<compiler>
        #define RTVIZ_COMPILER_STRING "string descriptive of compiler"
        #define RTVIZ_COMPILER_MAJOR (compiler's_major_revision)
        #define RTVIZ_COMPILER_MINOR (compiler's_minor_revision)

        <os> is one of the following
        AIX, SUN, WIN32, LINUX, IRIX, UNIX

        #define RTVIZ_OS <os>
        #define RTVIZ_OS_<os>
        #define RTVIZ_OS_STRING "string descriptive of OS"

        <cpu> is one of the following
        X86, SPARC, PPC, MIPS

        #define RTVIZ_CPU <cpu>
        #define RTVIZ_CPU_<cpu>
        #define RTVIZ_CPU_STRING "string descriptive of CPU"

*******************************************************************************/

#ifndef RTVIZSYSTEM_H
#define RTVIZSYSTEM_H

/* COMPILER *******************************************************************/
/* Note: Use in conjunction with the predefined macro "__cplusplus" as necessary. */

#if defined(_MSC_VER)
#define RTVIZ_COMPILER MICROSOFT
#define RTVIZ_COMPILER_MICROSOFT
#ifdef __cplusplus
#define RTVIZ_COMPILER_STRING "Microsoft Visual C++"
#else
#define RTVIZ_COMPILER_STRING "Microsoft Visual C"
#endif /* __cplusplus */
#define RTVIZ_COMPILER_MAJOR (_MSC_VER/100-6)
#define RTVIZ_COMPILER_MINOR (_MSC_VER-((_MSC_VER/100)*100))

#elif defined(__KCC_VERSION)
#define RTVIZ_COMPILER KAI
#define RTVIZ_COMPILER_KAI
#define RTVIZ_COMPILER_STRING "Kai C++"
#define RTVIZ_COMPILER_MAJOR (__KCC_VERSION/1000)
#define RTVIZ_COMPILER_MINOR (__KCC_VERSION%1000)

#elif defined(__SUNPRO_C)
#define RTVIZ_COMPILER SUN
#define RTVIZ_COMPILER_SUN
#define RTVIZ_COMPILER_STRING "SUN WorkShop C"
#define RTVIZ_COMPILER_MAJOR (__SUNPRO_C>>8)
#define RTVIZ_COMPILER_MINOR (__SUNPRO_C&0xFF)

#elif defined(__SUNPRO_CC)
#define RTVIZ_COMPILER SUN
#define RTVIZ_COMPILER_SUN
#define RTVIZ_COMPILER_STRING "SUN WorkShop C++"
#define RTVIZ_COMPILER_MAJOR (__SUNPRO_CC>>8)
#define RTVIZ_COMPILER_MINOR (__SUNPRO_CC&0xFF)

#elif defined(__GNUG__)
#define RTVIZ_COMPILER GNU
#define RTVIZ_COMPILER_GNU
#define RTVIZ_COMPILER_STRING "GNU C++"
#define RTVIZ_COMPILER_MAJOR __GNUC__
#define RTVIZ_COMPILER_MINOR __GNUC_MINOR__

#elif defined(__GNUC__)
#define RTVIZ_COMPILER GNU
#define RTVIZ_COMPILER_GNU
#define RTVIZ_COMPILER_STRING "GNU C"
#define RTVIZ_COMPILER_MAJOR __GNUC__
#define RTVIZ_COMPILER_MINOR __GNUC_MINOR__

#elif defined(__sgi)
#define RTVIZ_COMPILER SGI
#define RTVIZ_COMPILER_SGI
#if defined(_STANDARD_C_PLUS_PLUS) && ! defined(__cplusplus)
#define __cplusplus
#endif
#ifdef __cplusplus
#define RTVIZ_COMPILER_STRING "SGI C++"
#else
#define RTVIZ_COMPILER_STRING "SGI C"
#endif /* __cplusplus */
#define RTVIZ_COMPILER_MAJOR -1
#define RTVIZ_COMPILER_MINOR -1

#elif defined(__KCC)
#define RTVIZ_COMPILER KAI
#define RTVIZ_COMPILER_KAI
#define RTVIZ_COMPILER_STRING "KAI"
#define RTVIZ_COMPILER_MAJOR -1
#define RTVIZ_COMPILER_MINOR -1

#elif defined(hpux)
#define RTVIZ_COMPILER HPC
#define RTVIZ_COMPILER_HPC
#define RTVIZ_COMPILER_STRING "HP-UX aC++"
#define RTVIZ_COMPILER_MAJOR -1
#define RTVIZ_COMPILER_MINOR -21


#else
#error "Unrecognized Compiler"

#endif /* End of COMPILER */

/* OPERATING SYSTEM ***********************************************************/
/* NOTE!  For most situations 'ifdef' off the compiler, not the OS */

#if defined(_AIX32)
#define RTVIZ_OS AIX
#define RTVIZ_OS_AIX
#define RTVIZ_OS_STRING "IBM 32 bit AIX"

#elif defined(__sun) || defined(__sun__) || defined(sun)
#define RTVIZ_OS SUN
#define RTVIZ_OS_SUN
#define RTVIZ_OS_STRING "SunOS or Sun Solaris"

/* NOTE: Test for Win64 first. Win64 has both _WIN64 and _WIN32 defined. */
#elif defined(_WIN64) || defined(__WIN64)
#define RTVIZ_OS WIN64
#define RTVIZ_OS_WIN64
#define RTVIZ_OS_STRING "Microsoft Windows64"

#elif defined(_WIN32) || defined(__WIN32)
#define RTVIZ_OS WIN32
#define RTVIZ_OS_WIN32
#define RTVIZ_OS_STRING "Microsoft Windows"

#elif defined(__linux) || defined(linux) || defined(__linux__)
#define RTVIZ_OS LINUX
#define RTVIZ_OS_LINUX
#define RTVIZ_OS_STRING "LINUX"

#elif defined(__APPLE__)
#define RTVIZ_OS MACOSX
#define RTVIZ_OS_MACOSX
#define RTVIZ_OS_STRING "MacOSX"

#elif defined(__sgi)
#define RTVIZ_OS IRIX
#define RTVIZ_OS_IRIX
#define RTVIZ_OS_STRING "IRIX"

#elif defined(__unix) || defined(unix) || defined(__unix__)
#define RTVIZ_OS UNIX
#define RTVIZ_OS_UNIX
#define RTVIZ_OS_STRING "Generic UNIX"

#else

#error "Unrecognized OS"

#endif /* End of OPERATING SYSTEM */

/* CPU TYPE *******************************************************************/
/* For informational purposes only, compiler should be CPU independent!? */

#if defined(i386) || defined(_i386) || defined(__i386) || defined(__i386__) || defined(M_IX86) || defined(_M_IX86)
#define RTVIZ_CPU X86
#define RTVIZ_CPU_X86
#define RTVIZ_CPU_STRING "Intel x86 Compatible"
#define RTVIZ_LITTLE_ENDIAN 1

#elif defined(_AMD64_) || defined(__x86_64__) || defined(__amd64__) || defined (_M_AMD64)
#define RTVIZ_CPU X64
#define RTVIZ_CPU_X64
#define RTVIZ_CPU_STRING "Intel/AMD x64"
#define RTVIZ_LITTLE_ENDIAN 1

#elif defined(sparc) || defined(_sparc) || defined(__sparc) || defined(__sparc__) || defined(__sparc_v9__) || defined(__sparcv9)
#define RTVIZ_CPU SPARC
#define RTVIZ_CPU_SPARC
#define RTVIZ_CPU_STRING "SUN SPARC Compatible"
#define RTVIZ_BIG_ENDIAN 1

#elif defined(POWER) || defined(_POWER) || defined(__POWER) || defined(__POWER__) || defined(powerpc) || defined(_powerpc) || defined(__powerpc) || defined(__powerpc__) || defined(__APPLE__)
#define RTVIZ_CPU PPC
#define RTVIZ_CPU_PPC
#define RTVIZ_CPU_STRING "IBM PowerPc"
#define RTVIZ_BIG_ENDIAN 1

#elif defined(mips) || defined(_mips) || defined(__mips) || defined(__mips__)
#define RTVIZ_CPU MIPS
#define RTVIZ_CPU_MIPS
#define RTVIZ_CPU_STRING "MIPS"
#define RTVIZ_BIG_ENDIAN 1

#elif defined(hp_pa_risc)
#define RTVIZ_CPU HP_PA_RISC
#define RTVIZ_CPU_HP_PA_RISC
#define RTVIZ_CPU_STRING "HP PA-Risc"
#define RTVIZ_BIG_ENDIAN 1


#else

#error "Unrecognized CPU"

#endif /* End of CPU TYPE */

#endif /* RTVIZSYSTEM_H */
