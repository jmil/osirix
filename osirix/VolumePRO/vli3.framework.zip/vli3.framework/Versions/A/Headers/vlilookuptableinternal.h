/******************************************************************************
 *
 * $Id: vlilookuptableinternal.h,v 1.3 2004/11/02 14:51:22 vesper Exp $
 *
 *
 *	 Routines that are used by VLI that is not exposed to the user.
 *
 *    Copyright 2004 by Real Time Visualization, TeraRecon, Inc.
 *    All Rights Reserved.  
 *****************************************************************************/

#ifndef vlilookuptableinternal_h
#define vlilookuptableinternal_h 1

class VLILookupTableInternal : public VLILookupTable
{
public:

	VLILookupTableInternal(
							int inTableSize, 
							int inNumberFields,
							const VLIFieldDescriptor inFields[]
						);

	~VLILookupTableInternal(void);

	// Routines to implement VLILookupTable virtual member routines
public:
	// Size query

	VLILookupTable::Size			GetSize (void				// Return number of entries in table
						) const;

	// Field descriptor access

	VLIFieldDescriptor		GetFieldDescriptor (			// Return a field descriptor
							VLIChannel inFieldNumber			// which field to return
						) const;

	VLIStatus		SetFieldDescriptor (			// Set a field descriptor
							VLIChannel inFieldNumber,				// which field to set
							const VLIFieldDescriptor &inDescriptor	// field descriptor
						);

	// Routines to change one or more color entries

	VLIStatus		SetColorEntry (				// Set color for one entry (int)
							unsigned int inIndex,	// index (0 based)
							unsigned int inRed,		// red value, 0 to 255
							unsigned int inGreen,	// green value, 0 to 255
							unsigned int inBlue		// blue  value, 0 to 255
						);

	VLIStatus		SetColorEntry (				// Set color for one entry (double)
							unsigned int inIndex, 	// index (0 based)
							double inRed,			// red value, 0.0 to 1.0
							double inGreen, 		// green value, 0.0 to 1.0
							double inBlue			// blue value, 0.0 to 1.0
						);

	VLIStatus		SetColorEntries (				// Set color for multiple entries (VLIuint8)
							unsigned int inIndex,		// starting index (0 based)
							unsigned int inLength,		// number of entries to set
							const VLIuint8 inRGB[][3]	// color data
						);

	VLIStatus		SetColorEntries (				// Set color for multiple entries (VLIRGBColor)
							unsigned int inIndex,		// starting index (0 based)
							unsigned int inLength,		// number of entries to set
							const VLIRGBColor* inEntries // color data
						);

	// Routines to retrieve color entries

	VLIStatus		GetColorEntries (				// Return color for multiple entries (int)
							unsigned int inIndex,		// starting index (0 based)
							unsigned int inLength,		// number of entries to return
							VLIuint8 outRGB[][3]		// RETURNED color data (0 to 255)
						) const;

	// Red, green and blue in the range 0.0 to 1.0
	VLIStatus		GetColorEntries (				// Return color for multiple entries (VLIRGBColor)
							unsigned int inIndex,		// starting index (0 based)
							unsigned int inLength,		// number of entries to return
							VLIRGBColor* outEntries		// RETURNED color data (0.0 to 1.0)
						) const;

	// Routines to change one or more alpha entries

	// Alpha in the range 0 to 4095.
	VLIStatus		SetAlphaEntry (					// Set alpha for one entry (int)
							unsigned int inIndex,		// index (0 based)
							unsigned int inAlpha		// alpha data (0 to 4095)
						);

	// Alpha in the range 0.0 to 1.0.
	VLIStatus		SetAlphaEntry (					// Set alpha for one entry (double)
							unsigned int inIndex,		// index (0 based)
							double inAlpha				// alpha data (0.0 to 1.0)
						);

	// Alpha in the range 0 to 4095.
	VLIStatus		SetAlphaEntries (				// Set alpha for multiple entries (VLIuint16)
							unsigned int inIndex,		// starting index (0 based)
							unsigned int inLength,		// number of entries to set
							const VLIuint16* inAlpha	// alpha data (0 to 4095)
						);

	// Alpha in the range 0.0 to 1.0.
	VLIStatus		SetAlphaEntries (				// Set alpha for multiple entries (float)
							unsigned int inIndex,		// starting index (0 based)
							unsigned int inLength,		// number of entries to set
							const float * inAlpha		// alpha data (0.0 to 1.0)
						);

	// Routines to retrieve alpha entries

	// Alpha in the range 0 to 4095.
	VLIStatus		GetAlphaEntries (				// Return alpha for multiple entries (VLIuint16)
							unsigned int inIndex,		// starting index (0 based)
							unsigned int inLength,		// number of entries to return
							VLIuint16* outAlpha			// RETURNED alpha data (0 to 4095)
						) const;	

	// Alpha in the range 0.0 to 1.0.
	VLIStatus		GetAlphaEntries (				// Return alpha for multiple entries (float)
							unsigned int inIndex,		// starting index (0 based)
							unsigned int inLength,		// number of entries to return
							float * outAlpha			// RETURNED alpha data (0.0 to 1.0)
						) const;	

	// Routines to change both color and alpha of one or more entries

	// Red, green and blue in the range 0 to 255, alpha in the range 0 to 4095.
	VLIStatus		SetRGBAEntry (					// Set color and alpha data for one entry (int)
							unsigned int inIndex,		// index (0 based)
							unsigned int inRed,			// red value, 0 to 255
							unsigned int inGreen, 		// green value, 0 to 255
							unsigned int inBlue, 		// blue value, 0 to 255
							unsigned int inAlpha		// alpha value, 0 to 4095
						);

	// Red, green, blue and alpha in the range 0.0 to 1.0.
	VLIStatus		SetRGBAEntry (					// Set color and alpha data for one entry (double)
							unsigned int inIndex,		// index (0 based)
							double inRed,				// red value, 0.0 to 1.0
							double inGreen,				// green value, 0.0 to 1.0
							double inBlue,				// blue value, 0.0 to 1.0
							double inAlpha				// alpha value, 0.0 to 1.0
							);

	VLIStatus		SetRGBAEntry (					// Set color and alpha data for one entry (VLIRGBAPacked)
							unsigned int inIndex,		// index (0 based)
							VLIRGBAPacked inPacked		// color and alpha data in packed form (0 to 255)
						);

	VLIStatus		SetRGBAEntries (				// Set color and alpha for multiple entries (VLIRGBAPacked)
							unsigned int inIndex,		// starting index (0 based)
							unsigned int inLength,		// number of entries to set
							const VLIRGBAPacked* inRGBA	// color and alpha data in packed form (0 to 255)
						);

	VLIStatus		SetRGBAEntries (				// Set color and alpha for multiple entries (VLIRGAFloat)
							unsigned int inIndex,		// starting index (0 based)
							unsigned int inLength,		// number of entries to set
							const VLIRGBAFloat* inRGBA	// color and alpha data, 0.0 to 1.0
						);

	// Routines to retrieve color and alpha entries

	VLIStatus		GetRGBAEntries (				// Return color and alpha for multiple entries (VLIRGBAPacked)
							unsigned int inIndex,		// starting index (0 based)
							unsigned int inLength,		// number of entries to return
							VLIRGBAPacked* outRGBA		// RETURNED color and alpha data in packed form (0 to 255)
						) const;

	VLIStatus		GetRGBAEntries (				// Return color and alpha for multiple entries (VLIRGBAFloat)
							unsigned int index,			// starting index (0 based)
							unsigned int length,		// number of entries to return
							VLIRGBAFloat* inRGBA		// RETURNED color and alpha data, 0.0 to 1.0
						) const;


	// General routines to manage arbitrary fields

	VLIStatus		UpdateField (					// Update one lookup table field with new values
							const void * inData,					// location of input data
							unsigned int inIndex,					// starting index (0 based)
							unsigned int inLength,					// number of entries to set
							const VLIFieldDescriptor & inTableField	// description of output
					);

	VLIStatus		UnloadField (					// Unload one lookup table field to application storage
							void	 * outData,			// RETURNED field data
							unsigned int inIndex,						// starting index (0 based)
							unsigned int inLength,						// number of entries to return
							const VLIFieldDescriptor & inDestinationField	// description of output
					) const;

	// VLI 4.0 additions

	 VLIStatus		Lookup (							// Lookup the field value in this lookup table
								double inFieldValue,			// Field value
								double & outRed,				// RETURNED red value
								double & outGreen,				// RETURNED green value
								double & outBlue,				// RETURNED blue value
								double & outAlpha				// RETURNED alpha value
							) const;

	 VLIRGBAFloat	Lookup (							// Return the result of Looking up the field value in this lookup table
								double inFieldValue				// Field value
							) const;

	 VLIStatus		SetInterpolationMode (				// Set the interpolation mode
								VLIInterpolationMode inMode		// Interpolation mode
							);

	 VLIInterpolationMode GetInterpolationMode (			// Return the interpolation mode
							) const;

	 int					GetBase (void) const;

	 VLIStatus				SetBase (							// Set the base index
								int inBase						// base index
							);

	 double					GetScaleFactor (void) const;

	 VLIStatus				SetScaleFactor (				// Set scale factor
								double inScaleFactor
							);

	// Methods used by VLILookupTable methods

	void InitializeRampRGBA (void);
	void InitializeRampColor (void);
	void InitializeRampAlpha (void);
	void InitializeDescriptors (void);

	// Data

	typedef	VLIuint64		EntryT;
	typedef VLIuint32		FieldT;

	EntryT			*m_colors;


private:

	// Other routines


	double			GetFieldDouble(EntryT entry, VLIChannel c) const;
	VLIuint8		GetField8(EntryT entry, VLIChannel c) const;
	VLIuint16		GetField12(EntryT entry, VLIChannel c) const;
	// D.M. Linux fix - added functions accepting 'double'
	void			DoSetRGB(unsigned int inIndex, FieldT r, FieldT g, FieldT b);
	void			DoSetRGB(unsigned int inIndex, double inR, double inG, double inB);
	void			DoSetAlpha(unsigned int inIndex, FieldT alpha);
	void			DoSetAlpha(unsigned int inIndex, double inAlpha);


	unsigned int	m_size;
	int				m_base;

	VLIFieldDescriptor	m_fields[kVLIMaxLookupTableFields];
	EntryT			m_fieldMask[kVLIMaxLookupTableFields];
	FieldT			m_fieldMax[kVLIMaxLookupTableFields];
	double			m_convert8[kVLIMaxLookupTableFields];
	double			m_convert12[kVLIMaxLookupTableFields];
	double			m_convertDouble[kVLIMaxLookupTableFields];
	double			m_convertTo8[kVLIMaxLookupTableFields];
	double			m_convertTo12[kVLIMaxLookupTableFields];
	double			m_convertToDouble[kVLIMaxLookupTableFields];

	double			m_scaleFactor;
	VLIInterpolationMode	m_interpolationMode;

};

#endif // vlilookuptableinternal_h
