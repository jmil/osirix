/*******************************************************************************

 THIS SOURCE FILE IS KEPT IN <CVSROOT>/common/RTVIZTypes.h
 any other file is just a shadow copy DO NOT EDIT SHADOW COPIES!

 $Id: RTVIZTypes.h,v 1.36 2004/10/19 16:58:04 vesper Exp $

      Copyright, Mitsubishi Electric Information Technology Center
      America, Inc., 1999, All rights reserved.
      CONFIDENTIAL AND PROPRIETARY PROPERTY OF MITSUISHI ELECTRIC ITA.
  
	  Copyright 2001,2002,2003,2004 by Real Time Visualization, TeraRecon, Inc.
      All Rights Reserved.

 Purpose:
      Define basic types with "C" and "C++" compatibility across all compilers in use.
      Types are created if necessary, otherwise they are declared, using the system's
      own include files if possible.

      bool
      uint
      int64, int64_t, uint64, uint64_t
      int32, int32_t, uint32, uint32_t
      int16, int16_t, uint16, uint16_t
      int8,  int8_t,  uint8,  uint8_t

      The include file RTVIZSystem.h is also included see it for details.

 NOTE: (using the 64 bit integral types)
      As an aid to using the 64 bit types the macro "INT64FORMAT" is defined.
      (Required because the format specifier "ll" is not used by the microsoft compiler)
      Use it as part of a format specifier as in: printf( "X is %" INT64FORMAT "d\n", x );

      Also macros for defining 64 bit integral constants are defined.
      (Required because the suffix "LL" is not used by the Microsoft compiler version 6.)
      For example: INT64_CONST( 0x8000000000000000 ) or UINT64_CONST( 0x8000000000000000 ).

      See the warning below.

 WARNING: (using 64 bit stream operations)
      The stream operators for compiling under Microsoft Visual C++ require linking with
      RTVIZTypes.cpp!  (If you aren't using the operators, you don't need to.)
      Note:  The stream operators are not 100%. They have limitations; see RTVIZTypes.cpp
      for details.

      Passing 64 bit integers into printf functions requires the correct
      format specifier be used or you will get junk!

 NOTE: (changing this code)
      New releases must compile and verify under the following compiler and architectures.
      Tests must be done with "C" and "C++" compilers.
      SunOS 5.x    Sun Compiler 4.32  (arcturus.rtviz.com)
      SunOS 5.x    Sun Compiler 5.0   (arcturus.rtviz.com)
      SunOS 5.x    GNU Compiler 2.8.1 (arcturus.rtviz.com)
      WinNT 4.0    Microsoft Visual C++ 6.0 SP3

      Other compatible machines
      AIX   3.4    GNU Compiler 2.95     ( darrius.rtviz.com)
      Linux 2.2    GNU Compiler 2.91     (linuxdev.rtviz.com)
      IRIX  6.5    MIPspro Compiler 7.30 (  rtsgi1.rtviz.com)
      IRIX  6.5    GNU Compiler 2.8.1    (  rtsgi1.rtviz.com)

*******************************************************************************/

#ifndef RTVIZTYPES_H
#define RTVIZTYPES_H "$Revision: 1.36 $"

#include "RTVIZSystem.h"

#ifndef RTVIZTYPES_DISABLE_CHECK /* Escape mechanism for non 64 bit capable machines */

#if   defined(RTVIZ_COMPILER_MICROSOFT) && (RTVIZ_COMPILER_MAJOR== 6) && (RTVIZ_COMPILER_MINOR== 0)
#elif defined(RTVIZ_COMPILER_MICROSOFT) && (RTVIZ_COMPILER_MAJOR== 7) && (RTVIZ_COMPILER_MINOR== 10)
#elif defined(RTVIZ_COMPILER_MICROSOFT) && (RTVIZ_COMPILER_MAJOR== 8) && (RTVIZ_COMPILER_MINOR== 0)
#elif defined(RTVIZ_COMPILER_SUN      ) && (RTVIZ_COMPILER_MAJOR== 4) && (RTVIZ_COMPILER_MINOR==32)
#elif defined(RTVIZ_COMPILER_SUN      ) && (RTVIZ_COMPILER_MAJOR>= 5) && (RTVIZ_COMPILER_MINOR>= 0)
#elif defined(RTVIZ_COMPILER_GNU      ) && (RTVIZ_COMPILER_MAJOR== 2) && (RTVIZ_COMPILER_MINOR== 8)
#elif defined(RTVIZ_COMPILER_GNU      ) && (RTVIZ_COMPILER_MAJOR== 2) && (RTVIZ_COMPILER_MINOR==95)
#elif defined(RTVIZ_COMPILER_GNU      ) && (RTVIZ_COMPILER_MAJOR== 2) && (RTVIZ_COMPILER_MINOR==96)
#elif defined(RTVIZ_COMPILER_GNU      ) && (RTVIZ_COMPILER_MAJOR== 3) && (RTVIZ_COMPILER_MINOR==0)
#elif defined(RTVIZ_COMPILER_GNU      ) && (RTVIZ_COMPILER_MAJOR== 3) && (RTVIZ_COMPILER_MINOR==2)
#elif defined(RTVIZ_COMPILER_GNU      ) && (RTVIZ_COMPILER_MAJOR== 3) && (RTVIZ_COMPILER_MINOR==3)
#elif defined(RTVIZ_COMPILER_GNU      ) && (RTVIZ_COMPILER_MAJOR== 2) && (RTVIZ_COMPILER_MINOR==91)
#elif defined(RTVIZ_COMPILER_SGI      ) && (RTVIZ_COMPILER_MAJOR==-1) && (RTVIZ_COMPILER_MINOR==-1)
#elif defined(RTVIZ_COMPILER_KAI      )
#elif defined(RTVIZ_COMPILER_HPC      )

#else
#error "Unqualified Compiler" RTVIZ_COMPILER_MAJOR
#endif /* End of compilers check */

#endif /* RTVIZTYPES_DISABLE_CHECK */

/*##############################################################################

  START BOOL INTEGRAL TYPE

##############################################################################*/

#ifndef RTVIZTYPES_DISABLE_BOOL /* Escape mechanism */
#ifdef bool /* Make sure no braindead individual defined "bool" as a macro! */
#error bool macro declared HELP!
#undef bool
#endif /* bool */

/* Versions before rev 5.0 (0x500) don't support bool and Standard C++ Library.*/
#if (defined(__SUNPRO_CC) && __SUNPRO_CC<=0x420) || (defined(__SUNPRO_C) && __SUNPRO_C<=0x500)
typedef int bool;
#define bool bool /* Force someone to undef bool to change into something else. */
static const bool false = 0;
static const bool true  = 1;
#elif !defined(__cplusplus) && !defined(__SUNPRO_C)
typedef int bool;
#define bool bool /* Force someone to undef bool to change into something else. */
static const bool false = 0;
static const bool true  = 1;
#endif
#endif /* RTVIZTYPES_DISABLE_BOOL */

/*##############################################################################

  START 32 BIT INTEGRAL TYPES

##############################################################################*/

#ifndef RTVIZTYPES_DISABLE_UINT /* Escape mechanism */
#define RTVIZTYPES_DISABLE_UINT

/* SUN: "/usr/include/sys/types.h", line 219: warning: typedef redeclared: uint
Line 219: typedef unsigned int uint; */
#if defined(RTVIZ_OS_SUN) && (defined(__EXTENSIONS__) || defined(_KERNEL) || (!defined(_POSIX_C_SOURCE) && !defined(_XOPEN_SOURCE)))
#include <sys/types.h>

//#ifdef _KERNEL
	/* solaris 64 bit driver (kernel) compile, uint32 was an 8 byte quantity ! */
	#define RTVIZTYPES_DISABLE_SIZED_INTS
	typedef unsigned int	uint32;
	typedef unsigned short	uint16;
	typedef unsigned char	uint8;

	typedef signed int		int32;
	typedef signed short	int16;
	typedef signed char		int8;
//#endif

/* simplify HP-UX, LMH 1/03/2002 */
#elif defined(hpux)

#include <sys/_inttypes.h> /* Define uint32_t */

#define RTVIZTYPES_DISABLE_SIZED_INTS
typedef	uint32_t	uint32;
typedef	uint16_t	uint16;
typedef	uint8_t		uint8;

typedef	int32_t		int32;
typedef	int16_t		int16;
typedef	int8_t		int8;

/* SGI: /usr/include/sys/bsd_types.h:33: warning: `uint' previously declared here
   Line 33: typedef     unsigned int    uint; */
#elif defined(RTVIZ_OS_IRIX)
#include <sys/bsd_types.h>

/* LINUX x86: /usr/include/sys/types.h:130: warning: `uint' previously declared here
   Line 130: typedef unsigned int uint; */
#elif defined(RTVIZ_OS_LINUX)  || defined(RTVIZ_OS_MACOSX)

#ifdef __KERNEL__
#else
#include <sys/types.h>
#endif /* __KERNEL__ */

/* /usr/local/lib/gcc-lib/powerpc-ibm-aix4.3.2.0/2.95/include/sys/types.h:455: warning: `uint' previously declared here
   Line 142: typedef unsigned int uint_t;
   Linie 455: typedef uint_t uint; */
#elif defined(RTVIZ_OS_AIX) && defined(_POSIX_SOURCE) && defined(RTVIZ_COMPILER_GNU)
#include <sys/types.h>

#else
typedef unsigned int uint;
#endif

#endif /* RTVIZTYPES_DISABLE_UINT */

/*##############################################################################

  START SIZED <64 BIT INTEGRAL TYPES

##############################################################################*/

#ifndef RTVIZTYPES_DISABLE_SIZED_INTS /* Escape mechanism */
#define RTVIZTYPES_DISABLE_SIZED_INTS

typedef unsigned long  uint32;
typedef unsigned short uint16;
typedef unsigned char  uint8;

#if defined(_AIX)

#include <sys/inttypes.h> /* Defines these all for IBM AIX */

#else

typedef   signed long  int32;
typedef   signed short int16;
typedef   signed char  int8;

#endif /* defined(_AIX) && !defined(_H_INTTYPES) */

#endif /* RTVIZTYPES_DISABLE_SIZED_INTS */

/*##############################################################################

  START SIZED <64 BIT INTEGRAL TYPES with "_t"

##############################################################################*/

#ifndef RTVIZTYPES_DISABLE_SIZED_T_INTS /* Escape mechanism */
#define RTVIZTYPES_DISABLE_SIZED_T_INTS

#if defined(_AIX)

#include <sys/inttypes.h> /* Define uint32_t */

#elif defined(hpux)

#include <sys/_inttypes.h> /* Define uint32_t */

#elif defined(RTVIZ_COMPILER_SGI)

#if defined(_KERNEL)
#include <sys/types.h> /* Define uint32_t */
#include <stdarg.h>
#else
#include <inttypes.h> /* Define uint32_t */
#endif /* defined(_KERNEL) */

#elif defined(RTVIZ_COMPILER_KAI)
/* Don't define _t types */

#elif defined(RTVIZ_COMPILER_SUN) && !defined(__cplusplus)
/* Use system types */
#include <inttypes.h> /* Define uint32_t */


#elif defined(RTVIZ_OS_LINUX) || defined(RTVIZ_OS_MACOSX)


#ifdef __KERNEL__
#else
#include <stdint.h>
#endif /* __KERNEL__ */

#else /* _AIX elif hpux,SGI,KAI,SUN C,LINUX & MACOSX. So... Sun c++ & WIN left */

#if defined(RTVIZ_COMPILER_GNU) && (RTVIZ_COMPILER_MAJOR<=2) && (RTVIZ_COMPILER_MINOR<=8)
typedef unsigned int   uint32_t;
#elif defined(RTVIZ_COMPILER_MICROSOFT)
typedef unsigned long  uint32_t;
#endif /* defined(RTVIZ_COMPILER_SUN) && defined(__cplusplus) */

typedef unsigned short uint16_t;
typedef unsigned char  uint8_t;

#ifndef RTVIZ_COMPILER_HPC
#ifndef _SYS_INT_TYPES_H
typedef          long  int32_t;
#endif
#endif

typedef          short int16_t;

#ifndef RTVIZ_COMPILER_HPC
#ifndef _SYS_INT_TYPES_H
typedef   signed char  int8_t;
#endif
#endif

#endif /* _AIX */

#endif /* RTVIZTYPES_DISABLE_SIZED_T_INTS */

/*##############################################################################

  START 64 BIT INTEGRAL TYPES

##############################################################################*/

#ifndef RTVIZTYPES_DISABLE_64INTS /* Escape mechanism for non 64 bit capable machines */
#define RTVIZTYPES_DISABLE_64INTS

#ifndef __INT64_H
#define __INT64_H  /* In case Int64.H is still being included some place. */
#endif /* __INT64_H */
#ifdef _MSC_VER /* The Microsoft Visual Compiler (as of 6.0 SP2, _MSC_VER is 1200) */

typedef          __int64  int64;
typedef unsigned __int64 uint64;

typedef          __int64  int64_t;
typedef unsigned __int64 uint64_t;

#define INT64FORMAT "I64" /* Used as in : printf( "X is %" INT64FORMAT "d\n", x ); */
/* #define gFormatString "%I64x" // This macro is depreciated, use INT64FORMAT */

#ifdef __cplusplus
/* Yes, believe it or not Microsoft doesn't have stream operators for 64 bit integers! */
/* Currently unsupported: unsigned decimal, ios::showbase,showpos, paddding with fill... */
#include <iostream>
#include <ostream>
#if _MSC_VER < 1300
/* These are implemented in <CVSROOT>/common/RTVIZ.cpp */
std::ostream& operator<<( std::ostream& os, const          __int64& foo);
std::ostream& operator<<( std::ostream& os, const unsigned __int64& foo);
#endif /*  _MSC_VER < 1300 */

/* Note fixed Microsoft VC++ Bug SRX990910600458 */
#ifndef WORKAROUND_SRX990910600458
#define WORKAROUND_SRX990910600458
namespace Workaround_SRX990910600458 { class Class_SRX990910600458 { Class_SRX990910600458(){}; }; };
#endif /* WORKAROUND_SRX990910600458 */
#endif /* __cplusplus */

/* I believe that the HP-UX C compiler treats long long as long */
#elif defined(hpux) /*  _MSC_VER */

#include <sys/_inttypes.h> /* Define uint64_t */

typedef	uint64_t	uint64;

#define INT64FORMAT "ll" /* Used as in : printf( "X is %" INT64FORMAT "d\n", x ); */
/* #define gFormatString "%llx" // This macro is depreciated, use INT64FORMAT */

/* The SUN Compiler 5.0 defines __unix; GNU uses __unix__, IBM's AIX compiler uses _AIX */
#elif defined(__unix__) || defined(__unix) || defined(_AIX) || defined(RTVIZ_OS_MACOSX)

#if defined(_AIX) && ! defined(__GNUG__)
/* don't conflict GNU "C" and with IBM's AIX definition of int64 in sys/inttypes.h */
#include <sys/inttypes.h> /* Defines these all for IBM AIX */

#elif defined(RTVIZ_COMPILER_SUN) && !defined(__cplusplus)
#include <inttypes.h> /* Define uint64_t */

#else  /* ! _AIX &! __GNUG__ || SUN C So... All other cases (Linux, Mac, Sun C++) */

typedef signed long long  int64;

#if defined(RTVIZ_OS_LINUX) || defined(RTVIZ_OS_MACOSX)

#ifdef __KERNEL__
#define INT64FORMAT "l"
#else
#include <stdint.h>
#endif /* __KERNEL__ */

#elif defined(RTVIZ_COMPILER_SGI)

#if defined(_KERNEL)
#include <sys/types.h> /* Define int64_t */
#include <stdarg.h>
#else
#include <inttypes.h> /* Define int64_t */
#endif /* defined(_KERNEL) */

#elif defined(RTVIZ_COMPILER_SUN)

// AFV 10/15/2002; Problem with 64-bit SUN compiler.
// Do not define int64_t or uint64_t

#else /* RTVIZ_OS_LINUX) || RTVIZ_OS_MACOSX || SGI || SUN */

typedef signed long long  int64_t;
typedef unsigned long long uint64_t;

#endif /* RTVIZ_OS_LINUX) || RTVIZ_OS_MACOSX || SGI || SUN */

#endif /* defined(_AIX) & __GNUG__ || SUN C So... All other cases */

typedef unsigned long long uint64;

#ifndef INT64FORMAT
#define INT64FORMAT "ll" /* Used as in : printf( "X is %" INT64FORMAT "d\n", x ); */
/* #define gFormatString "%llx" // This macro is depreciated, use INT64FORMAT */
#endif  /* INT64FORMAT */

#else /* Unknown OS or machine architecture */
#error "Unknown OS or machine architecture"
#endif /* _MSC_VER, hpux, UNIX/AIX/Mac */

#define RTVIZ_CONCAT__(A,B) A ## B
#ifdef _MSC_VER
#define  INT64_CONST(c) RTVIZ_CONCAT__(c,i64)
#define UINT64_CONST(c) RTVIZ_CONCAT__(c,ui64)
#else /* all other compilers! */
#define  INT64_CONST(c) RTVIZ_CONCAT__(c,LL)
#define UINT64_CONST(c) RTVIZ_CONCAT__(c,ULL)
#endif

#if defined(_AIX) && defined(_H_INTTYPES)
/* IBM's definition in sys/inttypes.h, line 156 version 1.8 has the wrong type!
#define INT64_MIN       (-9223372036854775807-1)
#define INT64_MAX       (9223372036854775807)
#define UINT64_MAX      (18446744073709551615) */
#undef   INT64_MIN
#define  INT64_MIN  INT64_CONST(0x8000000000000000)
#undef   INT64_MAX
#define  INT64_MAX  INT64_CONST(0x7FFFFFFFFFFFFFFF)
#undef  UINT64_MAX
#define UINT64_MAX UINT64_CONST(0xFFFFFFFFFFFFFFFF)
#endif /* defined(_AIX) && defined(_H_INTTYPES) */

#if !defined(INT64_MIN) && defined(__cplusplus)

// rcf Not sure if this is right, but it works...
#ifdef RTVIZ_OS_MACOSX
       #include <ppc/limits.h>
#else
       #include <climits>
#endif
#endif

#if defined(INT64_MAX) && defined(RTVIZ_COMPILER_GNU) && defined(RTVIZ_OS_SUN)
/* warning: decimal integer constant is so large that it is unsigned
   From sys/int_limits.h: on chester
   #define	INT64_MAX	(9223372036854775807) */
#undef INT64_MAX
#define  INT64_MAX  INT64_CONST(0x7FFFFFFFFFFFFFFF)
#endif

#if defined(RTVIZ_COMPILER_SUN) && RTVIZ_COMPILER_MAJOR > 5
// AFV 2/21/2003 Use inttypes.h to define INT64_MIN etc.
#include <inttypes.h>
#endif

#if !defined(INT64_MIN)
#define  INT64_MIN  (INT64_CONST(-9223372036854775807)-1) /* 9223372036854775808 is too large for sun pre-processor! */
#define  INT64_MAX  INT64_CONST(0x7FFFFFFFFFFFFFFF)
#define UINT64_MAX UINT64_CONST(0xFFFFFFFFFFFFFFFF)
#endif

#endif /* RTVIZTYPES_DISABLE_64INTS */

/*##############################################################################

  END 64 BIT INTEGRAL TYPES

##############################################################################*/

#endif /* RTVIZTYPES_H */
