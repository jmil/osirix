/*
 * $Id: PerspInterf.h,v 1.21 2004/04/13 20:34:29 ford Exp $
 *
 *    Copyright 2002-2004 by Real Time Visualization, TeraRecon, Inc.
 *    All Rights Reserved.
 *
 */  
// PerspInterf.h - Class to Support Interfacing VLI to the Condor Perspective Library
//
//  The Condor Perspective Library handles all of the processing needed to complete
//   a full perspective rendering via a number of specially limited Mini-Frustum
//   rendering operations that are supported by Condor hardware.
//  This PerspInterf class handles the interface between VLI and the Perspective
//   library.  Here's the goal: VLI specific stuff goes into the PerspInterf Class.
//   The Perspective Library will be something that does not need to change.  With
//   time the VLI team may end up adding to the PerspInterf, or may change what is
//   in this Interface - but the Perspective Library will remain mostly unchanged.
#ifndef PERSPINTERF_H
#define PERSPINTERF_H

// Since this is included by VLI, include all necessary header files here

// Get Basic Types for the Perspective Sampling Testbed
#include "PSTtypes.h"

// Box2D Object
#include "Box2D.h"

// BoxST Object
#include "BoxST.h"

// Transform 3D Structurs and Functions
#include "Transform3D.h"

// Declaration of Vector2D, Vector3D, Matrix3D
#include "VectMat.h"

// Declaration of PointST3H Object
#include "PointST3H.h"

// Declaration of BoxST3H Object
#include "BoxST3H.h"

// Declaration of Box3D Object
#include "Box3D.h"

// Polygon3D Object Declaration
#include "Polygon3D.h"

// Declaration of PolygonST3H Object
#include "PolygonST3H.h"

// Declaration of Cube Object
#include "CubeST3H.h"

// Declaration of Clip Cube Object
#include "ClipCubeST3H.h"

// Dual Hyperbolic Class Definition
#include "DualHyper.h"

// Tile2D Declaration
#include "Tile2D.h"

// Plane3H Declaration (For use with Clipper3H)
#include "Plane3H.h"            // Needed for CondorPersp.h

// Geometry Clipper for 3D Homogeneous Coordinates
#include "Clipper3H.h"          // Needed for CondorPersp.h

// Object for Sample Space related calculations
#include "SampleSpace.h"        // Needed for CondorPersp.h

// Object for Clipped Sample Space related calculations
#include "ClipSampleSpace.h"    // Needed for CondorPersp.h

// CondorPersp Class includes a Pointer to a PerspInterf Object
// The PerspInterf Class includes an Instance of a CondorPersp Object
// This self reference is solved as follows
class PerspInterf;

// CondorPersp Object Delcaration
#include "CondorPersp.h"

// VLI interface
#include "vliperspective.h"
#include "vlipostblend.h"
#include "vlipostwarp.h"

// Perspective Interface - Class Declaration
class PerspInterf {
public:

  // Structure to hold multi-buffered data
  struct MultiBuf
  {
    // Image buffer and data for a mini-frustum (16, 32 or 64-bit data)
    VLIImageBuffer* mMiniImageBuf;
    VLIuint64*      mMiniImageData;
    VLISyncEvent    mMiniImageEvent;

    // Depth buffers and data for a mini-frustum
    VLIDepthBuffer* mMiniDepth0Buf;
    VLIuint32*      mMiniDepth0Data;
    VLISyncEvent    mMiniDepth0Event;
    VLIDepthBuffer* mMiniDepth1Buf;
    VLIuint32*      mMiniDepth1Data;
    VLISyncEvent    mMiniDepth1Event;

    // Size of Mini Image Buffer currently being processed
    int mMiniWidth, mMiniHeight;

    // Z information (Volume, and View Space) used by Distort Depth process
    // Near and far Zv (Zv == Z of the Volume)
    float m_nZv, m_fZv;

    // Near and Far Zs at TL, TR, BL, BR (Zs == Z of the View Space)
    float m_nZs_TL, m_nZs_TR, m_nZs_BL, m_nZs_BR;
    float m_fZs_TL, m_fZs_TR, m_fZs_BL, m_fZs_BR;

    // Near and Far W at TL, TR, BL, BR (W at these points in the View Space)
    float m_nW_TL, m_nW_TR, m_nW_BL, m_nW_BR;
    float m_fW_TL, m_fW_TR, m_fW_BL, m_fW_BR;

    // Post-resample data
    VLIVector2D mGeomOut[8];
    int         mNumPoints;
    VLIMatrix   mMatrixOut;
  };

  // Constructors and destructors
  PerspInterf (void);
  ~PerspInterf (void);

  // Method called by VLI to access the mini-frustum
  VLIMiniFrustum& GetMiniFrustum (void)
  {
    return mMiniFrust;
  }

  // Perspective Render (all arguments, the last three should have defaults=NULL)
  VLISyncEvent RenderCondorPersp (VLIVolumeInternal *inVolume, const VLIContext *inContext,
              VLIImageBuffer *inImageBuf0, VLIDepthBuffer *inDepthBuf0,
              VLIImageBuffer *inImageBuf1, VLIDepthBuffer *inDepthBuf1);

  // Get active area of writeport
  bool GetVolumeArea ();

  // Member Functions Called by the CondorPersp Class, to interface with VLI
  // These can be called "Callbacks", but right now we're just passing a pointer
  //  to the PerspInterf Class, then invoking these Methods directly.

  // Prepare to render the mini-frustum, and set up for resampling
  int PrepareRender (Polygon3D &inNearPoly, Polygon3D &inFarPoly,
      Point3D &inEyePoint, Point3D &inSightPoint,
      int inDimXs, int inDimYs, int inDimZs,
      int inSectX, int inSectY, int inTransfReg,
      DualHyper &inNearHyper, Point2D *inVoxRect);

  // Pre-render resample of the depth buffers
  int PreResample (PolygonST3H &inClipPoly);

  // Distort a depth buffer for use in Condor rendering
  void DistortDepthIn (PolygonST3H inNearPoly, PolygonST3H inFarPoly);

  // Load warped depth buffers into Condor
  int LoadBuffers (void);

  // Render Mini-Frustum - Invokes Condor Rendering within a Mini-Frustum
  int RenderMiniFrustum (void);

  // Unload image and possibly depth buffers from Condor
  int UnloadBuffers (void);

  // Do the Unload of image and depth buffers
  int DoUnloadBuffers (MultiBuf& buf);

  // Distort a depth buffer from a Condor render
  int DistortDepthOut (PolygonST3H inNearPoly, PolygonST3H inFarPoly);

  // Do the distort of a depth buffer from a Condor render
  int DoDistortDepthOut (MultiBuf& buf);

  // Post-render resample of the image and depth buffers
  int PostResample (PolygonST3H &inClipPoly);

  // Do the post-render resample of the image and depth buffers
  int DoPostResample (MultiBuf& buf);


protected:

  // Instance of the CondorPersp Class
  CondorPersp  mCondPersp;

  // Pointers to VLI objects: Interface between VLI and CondorPersp
  VLIVolumeInternal* mVolume;
  VLIContext*		mContext;
  VLIImageBuffer*	mImageBuf0;
  VLIImageBuffer*	mImageBuf1;
  VLIDepthBuffer*	mDepthBuf0;
  VLIDepthBuffer*	mDepthBuf1;
  VLISyncEvent      mDepthBuf0Event, mDepthBuf1Event;
  bool              mBlend0, mBlend1;
  bool              mNeedBlend;
  int               mElementSize;
  VLIFieldDescriptor mFields[4];
  double            mImageRed, mImageGreen, mImageBlue, mImageAlpha;
  bool              mReadDepth0;
  bool              mReadDepth1;
  bool              mWriteDepth0;
  bool              mWriteDepth1;
  bool              mNeedDepth0;
  bool              mNeedDepth1;
  VLIStatus         mStatus;

  // Viewing related information that is in the VLIVolume object
  VLIMatrix			mCorrMatrix;
  unsigned int		mVolMinX, mVolMinY, mVolMinZ;
  unsigned int		mVolMaxX, mVolMaxY, mVolMaxZ;

  // Pointer to VLICamera that is in the VLIContext object
  VLICamera*		mCamera;

  // Viewing information that is in the VLICamera object
  VLIMatrix			mModelMatrix, mViewMatrix, mProjMatrix;

  // Viewport dimensions
  VLIImageRange		mViewport;
  double			mViewMinZ, mViewMaxZ;

  // Writeport (portion of viewport to write) dimensions
  VLIImageRange		mWriteport;

  // Software post-warp interface
  VLIPostWarp   mWarp;

  // Post-blend interface
  VLIPostBlend  mBlend;

  // << Also start using the DepthRange in VLICamera >>

  // FrameBuffer, set to the size of the VLI Viewport
  VLIuint64*	mFrameBuf;
  int			mFrameSize;
  VLISyncEvent	mFrameEvent;
  bool			mFrameClear;

  // Clear value for the frame buffer
  VLIuint64     mClearValue;

  // Internal depth buffers, the same size as the frame buffer
  VLIuint32* mDepth0;
  VLIuint32* mDepth1;

  // Per Baseplane Area Member Variables

  // Dimensions of the Baseplane Texture area dimensions (Tile2D)
  Tile2D mBaseTile2D;

  // Per Mini-Frustum Member Variables -- two of each for double-buffering
  // (we could expand to more buffers if it is warrented)

  // Multi-buffering structure
  enum {kNumBufs = 3};
  MultiBuf mBuf[kNumBufs];

  // Dimensions of the MiniFrustum Color Tile
  Tile2D mMiniFrustTile2D;

  // Structure containing Mini-Frustum specification, used for VLI Perspective Render
  VLIMiniFrustum mMiniFrust;

  // Frustum count for double buffering
  int       mFrustNum;

  // Image flipping variables, since Condor requires double deltas to always be positive
  bool      mFlipX;
  bool      mFlipY;
  int       mFlipMask;

  // Dump Level control
  int mDumpLevel;

  // Allow access by CondorPersp
  friend class CondorPersp;
};

#endif  // PERSPINTERF_H
