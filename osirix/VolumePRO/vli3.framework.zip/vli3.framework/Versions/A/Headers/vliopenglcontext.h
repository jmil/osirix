#ifndef VLIOPENGLCONTEXT_H
#define VLIOPENGLCONTEXT_H
/*********************************************************************
 * $Id: vliopenglcontext.h,v 1.1 2000/03/10 20:10:23 vesper Exp $
 *
 *   Purpose
 *      OpenGL context for VLI
 *
 *   Copyright:
 *              Copyright, Mitsubishi Electric Information Technology Center
 *       America, Inc., 1998, All rights reserved.                             
 **********************************************************************/

#include "vli.h"

#ifdef WIN32
#include <windows.h>
#endif

#include <GL/gl.h>
#include <GL/glu.h>


class VLIEXPORT VLIOpenGLContext: public VLIGraphicsContext
{
   public:
    VLIOpenGLContext(void);
	virtual  ~VLIOpenGLContext(void);


	// a fallback routine to transfer the baseplane in host memory to the 
    // texture memory of the 3D card via standard OpenGL calls such as 
    // TexImage or TexSubImage
    virtual int    TransferBasePlane(int inBuffer, 
		                             unsigned int inX, unsigned int inY,
		                             unsigned int inIX,unsigned int inIY,
		                             VLIPixel* inBasePlane);

	// Using OpenGL extension to obtain the address of the texture memory so
	// a DMA operation can be performed.
	virtual int    GetTextureMemoryAddress(int inBuffer, 
                     unsigned int inX, unsigned int inY, 
   		             unsigned int& outStride, unsigned int &outFormat,
   		             void *& outVirutalAddress, unsigned int outBusAddress[2]);

	// Perform texture mapping
	virtual int    RenderHexagon(int inBuffer, VLIVector3D inGeomHex[6],
		           VLIVector2D inTexHex[6]);

	virtual GLuint NewTextureObject(int inBuffer);

	virtual int    ShouldLeaveOnBoard(void);	

	// read the OpenGL matrix stack or other settings and populate VLIContext
	virtual int    ImportAttributesToVLIContext(VLIContext& inContext, 
                                                InfoType inFlag);

  private:
	 GLuint m_textureID[kVLIMaxRenderBuffers];
	 int	m_texWidth [kVLIMaxRenderBuffers];
	 int	m_texHeight[kVLIMaxRenderBuffers];
	 int	m_maxTexSize;
};


#endif    /* VLIOpenGLContext */
