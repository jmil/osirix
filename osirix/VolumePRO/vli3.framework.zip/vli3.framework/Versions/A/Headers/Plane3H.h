/*
 * $Id: Plane3H.h,v 1.2 2002/10/14 21:03:38 vesper Exp $
 *
 *    Copyright 2002 by Real Time Visualization, TeraRecon, Inc.
 *    All Rights Reserved.
 *
 */  
// Plane Equation in 3D Homogeneous Coordinates
#ifndef PLANE3H_H
#define PLANE3H_H

class Plane3H {
public:

  // Constructors
  // Null, initialized to all zeros
  Plane3H ();

  // Construct from separate components
  Plane3H (double inX, double inY, double inZ, double inW);

  // Construct from a Vector 4
  Plane3H (Vect4 &inVect);


  // Operate on the Plane3H
  // Calculate the Perpendicular Distance from the Plane
  // Version that uses a PointST3H
  double PerpDist (PointST3H &inVert);

  // Version that uses a Vector4
  double PerpDist (Vect4 &inVect);

private:

  // Use separate terms for now
  double mX, mY, mZ, mW;

  // <<< Next you must create a good Vector3H Class           >>>
  // <<< Then other basic types...                            >>>
  // <<< Currently using Math functions instead of classes so >>>
  // <<< the code can be used from both C and C++ modules     >>>

};
#endif
