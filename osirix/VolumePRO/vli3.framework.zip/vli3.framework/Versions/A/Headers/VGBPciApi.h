/*
 * VGBPciApi.h
 *
 * $Id: VGBPciApi.h,v 1.3 2001/03/12 23:02:08 ford Exp $
 *
 * Class to handle PciApi stuff for the vgb wrapper.
 *
 * Copyright, Mitsubishi Electric Information Technology Center 
 * America, Inc., 2000 All rights reserved.
 *
 *    Copyright 2001 by Real Time Visualization, TeraRecon, Inc.
 *    All Rights Reserved.
 */

#ifndef VGBPCIAPI_H
#define VGBPCIAPI_H

#undef min
#undef max

#ifdef _MSC_VER
# pragma warning (disable : 4786) // identifier truncated
#endif

#include "PciApi.H"					// Condor, PCI API files
#include "PciApiDevice.H"
#include "AsimPciApi.H"
#include "ControlDevice.h"

enum RWOp { None, C32, R32, W32, R64, W64, RMem, WMem};

class VGBPciApi : public PciApi
{
public:
	ControlDevice	m_controlDevice;		// The control device
	ASIMPciApi		m_asimPciApi;			// The target device

	uint64			m_registerBase;

	uint64			m_memoryBase;

	int				m_status;
	RWOp			m_rwOp;
	uint64			m_offset;
	uint64			m_size;

	bool			m_usable;
	bool			m_dumpRegisters;

	DeviceCharacter m_devChar;


	VGBPciApi ();
	~VGBPciApi ();

	int WriteRegisters32 (uint64 inOffset, const uint32 * inData, int inCount = 1);
	int WriteRegister32 (uint64 inOffset, uint32 inData);

	int WriteRegisters64 (uint64 inOffset, const uint64 * inData, int inCount = 1);
	int WriteRegister64 (uint64 inOffset, uint64 inData);

	int WriteMemory (uint64 inOffset, const void * inData, int inCount = 4);
	int WriteMemory32 (uint64 inOffset, const uint32 * inData, int inCount = 1);
	int WriteMemory32 (uint64 inOffset, uint32 inData);

	int WriteMemory64 (uint64 inOffset, const uint64 * inData, int inCount = 1);
	int WriteMemory64 (uint64 inOffset, uint64 inData);

	int ReadRegisters32 (uint64 inOffset, uint32 * outData, int inCount = 1);
	int ReadRegisters64 (uint64 inOffset, uint64 * outData, int inCount = 1);

	int ReadMemory (uint64 inOffset, void * inData, int inCount = 4);
	int ReadMemory32 (uint64 inOffset, uint32 * outData, int inCount = 1);
	int ReadMemory64 (uint64 inOffset, uint64 * outData, int inCount = 1);

	int ReadConfig32 (uint32 inOffset, uint32 * outData, int inCount = 1 );

	int LoadTable (int whichTable, uint64 inOffset, int inCount);

	int UnloadImage (void * outAddress, uint32 inSizeX, uint32 inSizeY,
							uint32 &outImageX, uint32 &outImageY);

#define DEBUG_CHECK_STATUS(routine_) \
	do {if (m_status != kVLIOK) DebugCheckStatus (__FILE__, __LINE__, routine_);} while (0)

	void DebugCheckStatus (char * fileName, int lineNumber, char * routineName);
};

#endif VGBPCIAPI_H