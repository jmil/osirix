/*****************************************************************************
 *
 *	$Id: vlipostwarp.h,v 1.17 2004/10/19 17:07:06 vesper Exp $
 *
 *	Purpose - 
 *		To provide software (non-OpenGL) postwarp functionality.
 *		Highly optimized for Intel Pentium III processors under
 *		MSVC (Windows) and GCC (Linux).
 *
 *	Copyright 2000,2001,2002,2003,2004 by Real Time Visualization, TeraRecon, Inc.
 *	All Rights Reserved.
 *
 ****************************************************************************/

#ifndef VLIPOSTWARP_H
#define VLIPOSTWARP_H

#define qOptimizePrewarp	1		// Only prewarp if depth test is used

#ifdef sun
#include "vli.h"
#include <math.h>
#ifndef NULL
#define NULL 0
#endif
#else
#include "vliinternal.h"
#endif


#ifdef _M_IX86
#define WARP_PROFILE 1	// Set to 1 to enable Warp performance profiling. Uses Windows specific stuff.
#endif

class VLIPostWarp
{
public:
	VLIPostWarp();

	~VLIPostWarp();

	// Postwarps pBasePlane into pCanvas. Uses PIII optimized code if hardware and OS
	// support was detected in the constructor.
	void			WarpBasePlane(
							void*				inBasePlane,
							VLIuint32*			inBasePlaneDepth0,
							VLIuint32*			inBasePlaneDepth1,
							int 				inBasePlaneWidth,
							int 				inBasePlaneHeight,
							void*				inCanvas,
							VLIuint32*			inCanvasDepth0,
							VLIuint32*			inCanvasDepth1,
							int 				inCanvasWidth,
							int 				inCanvasHeight,
							int					inElementSize,
							VLIFieldDescriptor	inFields[4],
							VLIVector2D*		inGeometry,
							int					inNumPoints,
							VLIMatrix&			inMatrix);

private:

	// Methods
	bool			PIIISupported();		// Returns true if it is safe to use PIII
											// instructions.

	// Optimized math routines. Special support for PII and up.
	// See method for limitations.
	int 			FastFTOL(float f);		// Float to Int
	unsigned long	FastPFTOL(float f); 	// Float to Int for POSITIVE numbers only
	int 			FastFloor(float f); 	// Floor
	unsigned long	FastPFloor(float f);	// Fast Floor, positive values only.

	// Translate and filter a single scanline on the canvas.
	inline void		FilterScanlinePIII(
							float			u,
							float			v,
							float			w,
							float			uInc,
							float			vInc,
							float			wInc,
							int 			ix,
							unsigned int	startOfLine,
							int 			istopx
							);

	// Generic versions of above. Better accuracy.
	void			FilterScanline32(
							float			u,
							float			v,
							float			w,
							float			uInc,
							float			vInc,
							float			wInc,
							int 			ix,
							unsigned int	startOfLine,
							int 			istopx
							);

	void			FilterScanline48(
							float			u,
							float			v,
							float			w,
							float			uInc,
							float			vInc,
							float			wInc,
							int 			ix,
							unsigned int	startOfLine,
							int 			istopx
							);

	// Variables

	void*			m_pCanvas;				// Pointer to target for warp.
	VLIuint32*		m_pCanvasDepth0;		// Pointer to depth0 target for warp
	VLIuint32*		m_pCanvasDepth1;		// Pointer to depth1 target for warp
											// Owned by Consumer object.

	int 			m_iCanvasWidth;			// Dimensions of Canvas
	int				m_iCanvasHeight;

	void*			m_pBasePlane;			// Pointer to source for warp.
	VLIuint32*		m_pBasePlaneDepth0;		// Pointer to depth0 source for warp
	VLIuint32*		m_pBasePlaneDepth1;		// Pointer to depth1 source for warp
											// Owned by Consumer object.

	int 			m_iBasePlaneWidth;		// Dimensions of Canvas
	int				m_iBasePlaneHeight;

	VLIMatrix		m_matrix;				// Image to texture space matrix

	bool			m_bUsePIIIInstructions;	// True if we detected an Intel Pentium III in
											// the constructor.

	// We need some work space that is 16 byte aligned for fast SIMD transfers
	// Since the MSVC does not support 16 byte alignment, we'll
	// do it ourselves.
	unsigned long 	m_dwScratchPad[44];		// Scratch space. At least 40 DWORDS
											// after alignment.

	unsigned long * m_iScratch;				// 16 byte aligned int pointer
	float * 		m_fScratch;				// Float alias to m_iScratch

#if WARP_PROFILE
	__int64 		m_total_warp_time;		// Total time spent in the postwarp filter,
											// in processor clocks.
	__int64 		m_total_warp_pixels;	// Total number of pixels written to by
											// the postwarp.
	int 			m_total_warp_scanline;	// Total number of scanlines written to by
											// the postwarp.
#endif //WARP_PROFILE
};

#endif // VLIPOSTWARP_H
