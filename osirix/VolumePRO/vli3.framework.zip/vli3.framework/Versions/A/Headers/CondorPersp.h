/*
 * $Id: CondorPersp.h,v 1.14 2003/03/01 01:22:18 fadden Exp $
 *
 *    Copyright 2002 by Real Time Visualization, TeraRecon, Inc.
 *    All Rights Reserved.
 *
 */  
// CondorPersp.h - Class to support Condor Double Delta Perspective
//
//  A Full Perspective viewing context is set up via calls to Member Functions
//   and then other Member Functions are used to reduce a rendering problem
//   down to a set of "Mini-Frustum" rendering operations that can be handled
//   by Condor Double Delta rendering.
#ifndef CONDORPERSP_H
#define CONDORPERSP_H

// Condor Perspective - Class Declaration
class CondorPersp {
public:

  // Constructors
  CondorPersp (void);


  // Set Viewport
  int SetViewport (int inMinX, int inMinY, int inMaxX, int inMaxY);

  // Set Writeport
  int SetWriteport (int inMinX, int inMinY, int inMaxX, int inMaxY);

  // Functions to Set Matrices which ultimately control Viewing

  // Set Correction Matrix
  int SetCorrMatrix (VLIMatrix &inCorrMatrix);

  // Set Model Matrix
  int SetModelMatrix (VLIMatrix &inModelMatrix);

  // Set View Matrix
  int SetViewMatrix (VLIMatrix &inViewMatrix);

  // Set View Matrix - Eyepoint, Sightpoint version
  // int SetViewMatrix (Point3D &inEyePoint, Point3D &inSightPoint);

  // Set Projection Matrix
  int SetProjMatrix (VLIMatrix &inProjMatrix);

  // Set Projection Matrix to Default Orthographic projection
  // int SetOrthoProjMatrix  (void);

  // Functions for setting other important controls

  // Set Volume Dimensions - used to control rendering
  void SetVolDim (Point3D &inVolMin, Point3D &inVolMax);

  // Same as above, but using three Ints
  void SetSize (int inMinX, int inMinY, int inMinZ, int inMaxX, int inMaxY, int inMaxZ);

  // Set SuperSampling limits
  void SetSampMultLimits (double inMinXY, double inMaxXY, double inMinZ, double inMaxZ);

  // Set desired Z sampling factor
  void SetSamplingFactor (double inFactor);

  // Set Minimum Voxel Distance - Keeps Sample space in front of the viewer
  int SetMinVoxDist (double inDist);

  // Set Maximum Voxel Distance - Could work like Minimum Voxel Distance
  int SetMaxVoxDist (double inDist);

  // Main Working Member Functions

  // Render Perspective Frustum - Render the entire Frustum via a set of sub-
  //  rendering operations.  Renders Mini-Frustum via Condor Double Delta rendering
  // Pass in Pointer to PerspInterf Class so the "Callback" Member Functions can be
  //  called.  In this version we do not need Pointers to the Member Functions (we
  //  would use this technique if the PerspInterf Class did not exist).
  // Probably need to pass "this".
  int RendPerspFrustum (PerspInterf *inPerspInterfP);

  // Calculates the Area to Process for the specified Baseplane
  bool GetBaseplaneArea (void);

  // Render Perspective Baseplane - Processes a single Baseplane in detail by
  //  dividing the rendering problem into Single Permutation Matrix areas.  A special
  //  tiler iterates over all Permute areas (the Permute Tiler).
  // Uses the PerspInterf Class to Render a Mini-Frustum     (like a Callback)
  // Uses the PerspInterf Class to Unload the rendered Image (like a Callback)
  bool RendBaseplaneArea (void);

  // Convenience Functions

  // Convert from VLIMatrix to Mat44 structure
  void VLIMatToMat44 (Mat44 &out, VLIMatrix &in);

  // Convert from a Mat44 structure to a VLIMatrix object
  void Mat44ToVLIMat (VLIMatrix &out, Mat44 &in);

private:

  // Calculate Isotropic Sampling Scale Factors for X,Y
  void CalcIsotropicScale (void);

  // Calculate Anisotropic Sampling Scale Factors for X,Y
  void CalcAnisoScale (void);


  // Pointer to Perspective Interface Object
  PerspInterf *mPerspInterf;

  // Tile2D Viewport Dimensions
  Tile2D mViewPort;

  // Tile2D Writeport Dimensions
  Tile2D mWritePort;

  // Volume Correction Matrix
  Mat44 mCorrMat;

  // View Related Matrices: Model, View, Projection
  Mat44 mModelMat, mViewMat, mProjMat;

  // Projection ModelView Matrix, and it's Inverse
  Mat44 mPmvMat, mInvPmvMat;

  // Anisotropy factors
  VLIVector3D mAniso;

  // Viewpoint, in a convenient format
  PointST3H mViewPoint;

  // Dimensions of the volume
  Point3D mVolMin;
  Point3D mVolMax;

  // Minimum SuperSampling Scale Factors (causes Supersampling to increase if > 1)
  double mMinXYSampMult;
  double mMinZSampMult;

  // Maximum SuperSampling Scale Factors
  double mMaxXYSampMult;
  double mMaxZSampMult;

  // Desired relative sampling factor
  double mSamplingFactor;

  // Ratio of Scaling between Near and Far Plane
  double mNearFarRatio;

  // Create Vector to contain Sample Scaling in X,Y,Z
  Point3D mScalSamp;

  // Clipping object for use by RendBaseplaneArea and the ClipSampleSpace object
  Clipper3H	mClipper;

  // A numeric code of the Near Side (baseplane) that we are processing
  int mNearSide;

  // Get the Hither Clipping Distance by looking at all rendering Axes
  //  take the Max of the distance to all near surfaces, don't go below a minimum
  // Use SetMinVoxDist (double inDist) to set this Control
  // << The User really *will* want to set this control - this affects what you see >>
  double mMinVoxDist, mMaxVoxDist;

  // Calculated Clip Distance (near and far), limited by mMinVoxDist and mMaxVoxDist
  double mClipNear, mClipFar;

  // Clip Cube Dimensions - Distance from the Eye to the near and far surface of
  //  the ClipCube along the Zs axis (perpendicular to the baseplane).
  PointST3H mClipMin, mClipMax;

  // Near and Far DualHyperbolic Functions
  DualHyper mNearHyper, mFarHyper;

  // The S,T Components of the Volume, Clipped to the View Window, then
  //  projected onto the specified Baseplane.  When the view is rotated, this
  //  rectangle can extend outside the clipped screen area.
  BoxST mClipBoxST;

  // Tile2D version of this same ClipBox
  Tile2D mClipTile2D;

  // Pre-Transformed rendering polygon for OpenGL texturing
  // <<< This is only useful for OpenGL Perspective Texture Sampling (later) >>>
  PolygonST3H mRendPoly;

  // The Transformed version of the Rendering Polygon for the Software ReSample
  // A clip polygon for communicating between Sampling and the Resample operation
  // << Change the name of this to something other than ClipPoly - RendTransfPoly? >>
  PolygonST3H mClipPoly;

  // Near, Far Zv values
  double mNearZv, mFarZv;

  // Number of steps of sampling
  int mDeltaZ;

  // Member Variables for the Current Permutation Tile

  // Non-Scaled Tile2D area of Baseplane rendering
  Tile2D mRendTile;

  // Scaled Tile2D area of Baseplane rendering
  Tile2D mScalRendTile;

  // Used to Permute Coordinates, and get mini-Frustum to the RenderInterf Object
  Polygon3D mNearPoly3D, mFarPoly3D;

  // EyePoint, SightPoint for supplying View Direction to center of Mini-Frustum
  // Used for Lighting, Alpha Correction, and other calculations
  Point3D mEyePoint3D, mSightPoint3D;

  // Dimensions of Area to be Rendered
  int mDimXs, mDimYs, mDimZs;

  // Calculated Section Size
  int mSectionX, mSectionY;

  // Transform Register for the current Permutation Tile
  int mTransformReg;

  // Dump Level control
  int mDumpLevel;
};

#endif  // CONDORPERSP_H
