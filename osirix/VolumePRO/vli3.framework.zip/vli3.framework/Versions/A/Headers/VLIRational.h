///////////////////////////////////////////////////////////////////////////////
// $Id: VLIRational.h,v 1.14 2004/10/19 17:07:00 vesper Exp $
//	VLIVolumeRender.cpp
//
//  Rational Conversion template function definition and inline implementation
//
//    Copyright 2001,2002,2003,2004 by Real Time Visualization, TeraRecon, Inc.
//    All Rights Reserved.
//    Created by Yin WU April 5, 2001
///////////////////////////////////////////////////////////////////////////////


#ifndef VLIRATIONAL_H_
#define VLIRATIONAL_H_

#include "vli.h"

enum VLIRoundOrTruncType
{
	kVLITrunc =0,
	kVLIRound =1
} ;

// D.M. 6/14/01 - !!!!!!!!!!! TEMPORARY !!!!!!!!!!!!
// 'Type' can't be initialized by an integer; Argument of type Tipe must be one of function arguments
//template <class Type>
//inline Type VLIRationalPackFixedPoint(const double inValue, const int inShift,	
//									  const VLIRoundOrTruncType inRoundOn = kVLIRound, 
//									  const Type inRoundMask =0 )
/*template <class Type>
inline Type VLIRationalPackFixedPoint(	const double inValue,
					const int inShift,
					const VLIRoundOrTruncType inRoundOn = kVLIRound)
{
	// inRoundMask = 0
	if (inValue >0)
	return(  (Type)(inValue * ( double)((Type)1 << inShift) +0.5 *inRoundOn ));
	else 
	return(  (Type)(inValue * ( double)((Type)1 << inShift) -0.5 *inRoundOn ));
}
*/


template <class Type>
inline Type VLIRationalPackFixedPoint(  const double inValue,
                                        const int inShift,
                                        const Type inRoundMask,
                                        const VLIRoundOrTruncType inRoundOn = kVLIRound)
{
        if (inValue >0)
        	return( (Type)(inValue * ( double)((Type)1 << inShift) +0.5 *inRoundOn )   + inRoundMask);
        else
	        return( (Type)(inValue * ( double)((Type)1 << inShift) -0.5 *inRoundOn )   + inRoundMask);
}


template <class Type>
inline Type VLIRationalPackClampedSMRF( const double inValue, const unsigned int inShift,
									   const VLIRoundOrTruncType inRoundOn = kVLIRound)
{
	Type scale, outValue;

	double absValue = (inValue <0.0) ? -inValue: inValue;

	scale =  ((Type) 1 << inShift ) -1;
	if (absValue >=1.0)
		outValue = scale;
	else
		outValue = (Type)(absValue * scale + 0.5 *inRoundOn);

	if (inValue <0.0)
		outValue = (++scale)| outValue;
	return outValue;

		
}


template <class Type>
inline Type VLIRationalPackClampedUnsignedRF(	const double inValue,
						const unsigned int inShift, 
						const VLIRoundOrTruncType inRoundOn,
						const Type inTipe)
{
	if (inValue < 0.0)	
		return ((Type) 0);

	Type scale =((Type) 1 << inShift ) -1;
	if (inValue <= 1.0)
		return( (Type)(inValue * scale + 0.5 *inRoundOn));

	return scale;	// positive max
	
		
}


//////////////////////////////////////////
// Do we do clampe to uplimit   ?????
////////////////////////////////////////////

// D.M. 6/18/01
template <class Type>
inline Type VLIRationalPackClampedProduct( const double inValue, const unsigned int inShift, 
						const VLIRoundOrTruncType inRoundOn,
						Type inType)
{
	if (inValue < 0.0)	
		return ((Type) 0);
	
	Type scale =((Type) 1 << inShift ) -1;
	scale = scale *scale;
	
	return( (Type)(inValue * scale + 0.5 *inRoundOn));
		
}


#define FloatToS23F40(value_, roundMask_) VLIRationalPackFixedPoint <VLIint64>  (value_,40, roundMask_, kVLITrunc)
#define FloatToS31F32(value_, roundMask_) VLIRationalPackFixedPoint <VLIint64>  (value_,32, roundMask_, kVLITrunc)

#define FloatToSM0RF9(value_)	VLIRationalPackClampedSMRF			<VLIuint16>(value_, 9, kVLIRound)
#define FloatToSM0RF12(value_)	VLIRationalPackClampedSMRF			<VLIuint16>(value_, 12, kVLIRound)

#define FloatToS23F8(value_, round_) VLIRationalPackFixedPoint	<VLIuint32>(value_, 8, (VLIuint32)0, round_)

#define FloatToU0RF8(value_)	VLIRationalPackClampedUnsignedRF	<VLIuint8> (value_, 8U, kVLIRound, (VLIuint8)0)

#define FloatToU0RF12(value_)	VLIRationalPackClampedUnsignedRF	<VLIuint16>(value_, 12U,kVLIRound, (VLIuint16)0)

#define FloatToU2RF9RF9(value_) VLIRationalPackClampedProduct	<VLIuint32>(value_, 9U, kVLIRound, (VLIuint32)0)
#endif // VLIRATIONAL_H_


/*VLIuint64 VLISampleSpace::FloatToS23F40( const double inValue, const VLIuint64 inRound) const
{
	
	VLIuint64 value64 = (VLIuint64) (inValue *( (VLIuint64)(1) << 40));
	value64 = value64 + inRound;
	
	return (VLIuint64)(value64);
}



VLIuint16 VLISampleSpace::FloatToSM0RF9(const double inValue) const
{
	double uValue;
	VLIuint16 rValue;

	if (inValue <0.0)
		uValue = -inValue;
	
	if (uValue >=1.0)
		rValue = 0x1ff;
	else
	{
		rValue = (VLIuint16)(uValue * 511.0 +0.5);
	}
	

	if (inValue <0.0)
		rValue =0x200 | rValue;
	return rValue;

}

VLIuint32 VLISampleSpace::FloatToS23R8(const double inValue, const VLIuint32 inRound) const
{
	VLIuint32 value32 = (VLIuint32) ((inValue *( (VLIuint32)(1) << 8)) + 0.5);

	
	return  value32;
}*/
