/*
 * $Id: PolygonST3H.h,v 1.4 2003/01/09 19:31:02 fadden Exp $
 *
 *    Copyright 2002 by Real Time Visualization, TeraRecon, Inc.
 *    All Rights Reserved.
 *
 */  
// PolygonST3H.h - Polygon Object with x,y,z,h, and s,t values
#ifndef POLYGONST3H_H
#define POLYGONST3H_H

#define POLY_MAXVERTS 16

class PolygonST3H {
public:

  // Constructors
  // No initial verts, use AddVert (), below
  PolygonST3H ();

  // Three Sided
  PolygonST3H (const PointST3H &v1, const PointST3H &v2, const PointST3H &v3);

  // Four Sided
  PolygonST3H (const PointST3H &v1, const PointST3H &v2, const PointST3H &v3, const PointST3H &v4);

  // Get a Vertex of the Polygon
  PointST3H operator [](int);

  // Operate on the Polygon
  // N Sided
  int AddVert (const PointST3H &v1);

  // Scale the S,T components only
  // <<<Define a Vect3, and use it instead of Point3D>>>
  void ScaleST (const Point3D &inSampMult);

  // Transform
  void Transform (const Mat44 &inMat);

  // DivideW
  void DivideW (void);

  // Get surrounding XYZ Box
  BoxST3H GetBoxXYZ (void);

  // Update surrounding XYZ Box, given an Initial XYZ Box
  void UpdBoxXYZ (BoxST3H &inBox);

  // Determine if the Polygon is Frontfacing
  bool FrontFacing (void);

  // Reverse the order of the Vertices to "Flip" a Polygon
  void Reverse (void);

  // Calculate the Centroid of the Polygon by averaging, ST3H version
  bool CentroidST3H (PointST3H &outCentST3H);

  // Calculate the Centroid of the Polygon by averaging, 3 component version
  bool Centroid3D (Point3D &outCent3D);

  // Determine if the Polygon is Edge-on
  bool EdgeOn (void);

  // Calculate the Area of the Polygon in X,Y only
  double CalcAreaXY (void);

  // Calculate the Area of the Polygon in S,T only
  double CalcAreaST (void);

  // Get/Put

  // Convert to Polygon3D, take S,T and use specified Z
  Polygon3D GetPolygonST (double inZ);

  // Get the number of Vertices
  int GetNumbVerts (void);

  // Set the number of Vertices
  void SetNumbVerts (int inNumbVerts);

  // Get whether polygon is Null, or non Null (has vertices)
  bool NonNull (void);

  // Get a Vertex (index starting at zero)
  // PointST3H GetVertex (int vert);

  // Print
  // Print the Polygon
  void Print (void);

private:

  // Manage the number of Vertices stored
  int m_verts;

  // Store Vertices in an array, for now
  PointST3H m_vert [POLY_MAXVERTS];
};
#endif
