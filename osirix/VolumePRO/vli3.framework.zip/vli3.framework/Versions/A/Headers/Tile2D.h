/*
 * $Id: Tile2D.h,v 1.4 2002/10/23 15:38:07 vesper Exp $
 *
 *    Copyright 2002 by Real Time Visualization, TeraRecon, Inc.
 *    All Rights Reserved.
 *
 */  
// Tile2D - A 2D Tile, Dimensions, Coordinates, etc...
#ifndef TILE2D_H
#define TILE2D_H

class Tile2D {
public:

  // Constructors
  Tile2D (void);

  Tile2D (double inMinX, double inMinY, double inMaxX, double inMaxY);

  Tile2D (int inMinX, int inMinY, int inMaxX, int inMaxY);

  Tile2D (const Point2D &inMin, const Point2D &inMax);

  Tile2D (const Point2Di &inMin, const Point2Di &inMax);

  Tile2D (const Point2Di &inMin, int inDimX, int inDimY);

  Tile2D (int inDimX, int inDimY);

  // Construct a Tile2D from a BoxST, with optional Scaling
  Tile2D (const BoxST &inBoxST, const Point3D &inScale3D);
  Tile2D (const BoxST &inBoxST);


  // Operate on Tile

  // Apply scale factor, Up, Down
  void ScaleUp   (Point3D &inScale3D);
  void ScaleDown (Point3D &inScale3D);

  // Get a Box2D representation of the Tile2D
  Box2D GetBox2D ();

  // Get/Put
#ifdef NEVER
  int GetMinX (void);
  int GetMinY (void);
  int GetMaxX (void);
  int GetMaxY (void);
  int GetDimX (void);
  int GetDimY (void);
#endif

  double GetDminX (void);
  double GetDminY (void);
  double GetDmaxX (void);
  double GetDmaxY (void);
  double GetDdimX (void);
  double GetDdimY (void);

  // Print Tile2D contents
  void Print (void);


  // It is not productive right now to hide the Member Variables
  // and restrict their access.  The extra Get/Set Member Functions
  // just slow our development, making the code "clunky" and difficult.
  // We directly access these variables to save effort.

  // Tile Size
  int dimX, dimY;

  // Current Position of min, and max pixel
  int minX, minY, maxX, maxY;

  // Double Precision internal storage
  double mDdimX, mDdimY;

  double mDminX, mDminY, mDmaxX, mDmaxY;

private:

  // Set Internal Double values from the input Integer values
  void SetDoubleInternal (void);

  // Update calculated member storage from new precise inputs
  void UpdateInternal (void);

  // Properly Clamp Box Coordinates with special Box related logic
  int Floor   (double inVal);
  int Ceiling (double inVal);

  // Rounding Function << Switch to one in <math.h> >>
  int Round (double inVal);
};
#endif
