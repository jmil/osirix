#ifndef VLIDATEBUILT_H
#define VLIDATEBUILT_H
#include "vliversion.h"

/*
 * $Id: vlidatebuilt.h,v 1.14 2004/10/21 17:40:24 vesper Exp $
 *
 *    Copyright 2001 by Real Time Visualization, TeraRecon, Inc.
 *    All Rights Reserved.
 *
 */   



static char sVLIVersionStringFormat[] = 
VLI_VERSION_STRING
" (%d-bit)"
// REPLACEWITHDATE
" Thu Oct 21 12:38:57 2004"
;

#endif // VLIDATEBUILT_H
