#ifndef MPR_H
#define MPR_H

/******************************************************************************
 *
 *  vli3mpr.h      $Revision: 1.4 $    $Date: 2004/10/19 17:07:01 $
 *
 *   Purpose:
 *       This is a header file to define the CheckMPR auxilary
 *       routine. This is part of VLI 3.x.
 *
 *   VLI (Volume Library Interface) 3.x provides a software interface
 *   to the VolumePro 1000 Hardware. See http://www.rtviz.com
 *   if the Online help has not been installed.
 *
 *    Copyright 1998, 1999, 2000 by Mitsubishi Electric Information Technology
 *    Center America, Real Time Visualization. All Rights Reserved.
 *
 *    Copyright 2001, 2002, 2003, 2004 by Real Time Visualization, TeraRecon, Inc.
 *    All Rights Reserved.
 *
 *****************************************************************************/


#include "vli3.h"

namespace vli3
{
	VLIEXPORT VLIStatus CheckMPR(VLIVolume *inVolume, VLIContext *inContext, 
		VLIImageBuffer *inOuputImage, double &outFalloffScaleUp);
}

#endif
