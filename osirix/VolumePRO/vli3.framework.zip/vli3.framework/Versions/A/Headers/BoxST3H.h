/*
 * $Id: BoxST3H.h,v 1.2 2002/10/14 21:03:35 vesper Exp $
 *
 *    Copyright 2002 by Real Time Visualization, TeraRecon, Inc.
 *    All Rights Reserved.
 *
 */  
// BoxST3H.h - Box in x,y,z,h, and s, t, with Min and Max
// Used to calculate the min, max extent of a set of Points in x,y,z,h,s,t
#ifndef BOXST3H_H
#define BOXST3H_H

class BoxST3H {
public:

  // Constructor
  BoxST3H ();
  BoxST3H (PointST3H &inPoint);
  BoxST3H (PointST3H &inMin, PointST3H &inMax);

  // Operate on the Box
  void Update (double &inX, double &inY, double &inZ);
  void Update (double &inS, double &inT);
  void Update (PointST3H &inPt);

  // Return whether a point is outside the box
  bool OutSide (float inX, float inY);

  // Get/Put
  PointST3H GetMin (void);
  PointST3H GetMax (void);
  double GetMinX (void);
  double GetMinY (void);
  double GetMinZ (void);
  double GetMinW (void);
  double GetMinS (void);
  double GetMinT (void);
  double GetMaxX (void);
  double GetMaxY (void);
  double GetMaxZ (void);
  double GetMaxW (void);
  double GetMaxS (void);
  double GetMaxT (void);

  void SetMin (PointST3H &inPoint);
  void SetMax (PointST3H &inPoint);
  void SetMinX (double &inX);
  void SetMinY (double &inY);
  void SetMinZ (double &inZ);
  void SetMinW (double &inW);
  void SetMinS (double &inS);
  void SetMinT (double &inT);
  void SetMaxX (double &inX);
  void SetMaxY (double &inY);
  void SetMaxZ (double &inZ);
  void SetMaxW (double &inW);
  void SetMaxS (double &inS);
  void SetMaxT (double &inT);

  // Get a Subset of the Object, returning a Box2D
  Box2D GetBox2D (void);

  // Get a Subset of the Object, returning a BoxST
  BoxST GetBoxST (void);


  // Print
  // Print the Box
  void Print (void);

private:

  // One Point stores the Min, one stores the Max
  PointST3H m_min, m_max;
};
#endif
