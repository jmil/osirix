///////////////////////////////////////////////////////////////////////////////
// $Id: VLIAllRenderRegisters.h,v 1.9 2004/10/19 17:06:59 vesper Exp $
//	VLIAllRenderCondorRegisters.h
//
//  a class to declare all rendering registers and their initialization 
//
//    Copyright 2001,2002,2003,2004 by Real Time Visualization, TeraRecon, Inc.
//    All Rights Reserved.
//    Created by Yin WU March 30, 2001
///////////////////////////////////////////////////////////////////////////////


#ifndef VLIAllRenderRegisters_H_
#define VLIAllRenderRegisters_H_

#include "VLICondorRegisters.h"

class VLIAllRenderRegisters
{
public:
	VLIAllRenderRegisters();
	void ClearAll();
// Array Register Information will be handled by driver
	VLIuint64  m_VolumeArrayBase;	
	VLIuint64  m_VolumeArraySize;
	VLIuint32  m_VolumeArrayDimensions;
	VLIuint64  m_VolumeArrayOffsetModulus;
	VLIuint64  m_VolumeRangeMin;
	VLIuint64  m_VolumeRangeMax;
	
	VLIuint64  m_Depth0ArrayBase;
	VLIuint64  m_Depth0ArraySize;
	VLIuint32  m_Depth0ArrayDimensions;
	VLIuint64  m_Depth0ArrayOffsetModulus;
	VLIuint64  m_Depth0InitRangeMin;
	VLIuint64  m_Depth0InitRangeMax;
	
	VLIuint64  m_Depth1ArrayBase;
	VLIuint64  m_Depth1ArraySize;
	VLIuint32  m_Depth1ArrayDimensions;
	VLIuint64  m_Depth1ArrayOffsetModulus;
	VLIuint64  m_Depth1InitRangeMin;	VLIuint64  m_Depth1InitRangeMax;
	
	VLIuint64  m_Image0ArrayBase;
	VLIuint64  m_Image0ArraySize;
	VLIuint32  m_Image0ArrayDimensions;
	VLIuint64  m_Image0ArrayOffsetModulus;
	VLIuint64  m_Image0InitRangeMin;
	VLIuint64  m_Image0InitRangeMax;
	
	VLIuint64  m_Image1ArrayBase;
	VLIuint64  m_Image1ArraySize;
	VLIuint32  m_Image1ArrayDimensions;
	VLIuint64  m_Image1ArrayOffsetModulus;
	VLIuint64  m_Image1InitRangeMin;
	VLIuint64  m_Image1InitRangeMax;


	VLIuint64  m_ViewFrustumRangeMin;
	VLIuint64  m_ViewFrustumRangeMax;
	VLIuint32  m_Transform;

	VLIuint32  m_LookupTableFormat0;
	VLIuint32  m_LookupTableFormat1;
	VLIuint32  m_LookupTableFormat2;
	VLIuint32  m_LookupTableFormat3;

	VLIuint32  m_Image0FieldSel;
	VLIuint32  m_Image1FieldSel;

	VLIuint32  m_CutPlane0_dCut_dXs;
	VLIuint32  m_CutPlane0_dCut_dYs;
	VLIuint32  m_CutPlane0_dCut_dZs;
	VLIuint32  m_CutPlane0_dCut_dZv;
	VLIuint32  m_CutPlane0_min;
	VLIuint32  m_CutPlane0_max;
	VLIuint32  m_CutPlane1_dCut_dXs;
	VLIuint32  m_CutPlane1_dCut_dYs;
	VLIuint32  m_CutPlane1_dCut_dZs;
	VLIuint32  m_CutPlane1_dCut_dZv;
	VLIuint32  m_CutPlane1_min;
	VLIuint32  m_CutPlane1_max;
	VLIuint32  m_CutPlane2_dCut_dXs;
	VLIuint32  m_CutPlane2_dCut_dYs;
	VLIuint32  m_CutPlane2_dCut_dZs;
	VLIuint32  m_CutPlane2_dCut_dZv;
	VLIuint32  m_CutPlane2_min;
	VLIuint32  m_CutPlane2_max;
	VLIuint32  m_CutPlane3_dCut_dXs;
	VLIuint32  m_CutPlane3_dCut_dYs;
	VLIuint32  m_CutPlane3_dCut_dZs;
	VLIuint32  m_CutPlane3_dCut_dZv;
	VLIuint32  m_CutPlane3_min;
	VLIuint32  m_CutPlane3_max;
	VLIuint32  m_CutPlaneControl;

	VLIuint32  m_CropControl;	
	VLIint32  m_CropRangeXmin;
	VLIint32  m_CropRangeXmax;
	VLIint32  m_CropRangeYmin;
	VLIint32  m_CropRangeYmax;
	VLIint32  m_CropRangeZmin;
	VLIint32  m_CropRangeZmax;


	VLIint32  m_TrimRangeXmin;
	VLIint32  m_TrimRangeXmax;
	VLIint32  m_TrimRangeYmin;
	VLIint32  m_TrimRangeYmax;
	VLIint32  m_TrimRangeZmin;
	VLIint32  m_TrimRangeZmax;

	////Not used in 
	// 	VLIuint64  m_EmptyArrayBase;
	//	VLIuint64  m_EmptyArraySize;
	
	VLIint64  m_OriginXv8;
	VLIint64  m_OriginYv8;
	VLIint64  m_OriginZv8;
	VLIint64  m_dXv8_dXs;
	VLIint64  m_dYv8_dYs;
	VLIint64  m_dZv8_dZs;
	VLIint64  m_dXv8_dZs;
	VLIint64  m_dYv8_dZs;
	VLIint64  m_dYv8_dZv;
	VLIint64  m_dXv8_dZv;
	VLIint64  m_dYv8_dXs;
	VLIint64  m_dXv8_dYs;
	VLIint64  m_OriginDepth;
	VLIint64  m_dD_dXs;
	VLIint64  m_dD_dYs;
	VLIint64  m_dD_dZs;
	VLIint64  m_dD_dZv;
	
	VLIuint64  m_VoxelFormat;
	VLIuint64  m_VoxelBorder;
	
	//---------------Experiement register for perspective				
	VLIint64  m_ddXv8_dXs_dZs;
	VLIint64  m_ddXv8_dYs_dZs;
	VLIint64  m_ddYv8_dXs_dZs;
	VLIint64  m_ddYv8_dYs_dZs;
	VLIint64  m_ddXv8_dXs_dZv;
	VLIint64  m_ddXv8_dYs_dZv;
	VLIint64  m_ddYv8_dXs_dZv;
	VLIint64  m_ddYv8_dYs_dZv;
	


	VLIuint32  m_Alu0;
	VLIuint32  m_Alu1;
	VLIuint32  m_Alu2;
	VLIuint32  m_GradientCorrection0;
	VLIuint32  m_GradientCorrection1;
	VLIuint32  m_GradientCorrection2;
	VLIuint64  m_GradientMagnitudeRange;
	VLIuint64  m_EyeVector;
	VLIuint64  m_SpecularColor;
	VLIuint32  m_LightingCoefficient;
	VLIuint32  m_GradientMagnitudeModulation;
	VLIuint32  m_SampleAlphaRange;
	VLIuint32  m_AccumAlphaRange;

	VLIuint32  m_DepthInitValue0;
	VLIuint32  m_DepthInitValue1;
	VLIuint64  m_ImageAccumValue;
	VLIuint64  m_ImageLastValue;

	VLIuint32  m_ErtThreshold;
	VLIuint32  m_EmptyThreshold;
	
	VLIuint32  m_Section;
	VLIuint32  m_SequencerDebug;


	VLIuint64  m_AddressOperand;

	VLIuint32  m_InterpolateControl;
	VLIuint32  m_GradientControl;
	VLIuint32  m_DepthControl;
	VLIuint32  m_ImageControl;

	VLIuint32  m_RenderOperation;
};

inline VLIAllRenderRegisters::VLIAllRenderRegisters()
{
	ClearAll();
}

#define REGISTER_INIT(name_) \
		{m_	##	name_ = NVG1000_ ## name_ ##_Init;}
void
inline VLIAllRenderRegisters::ClearAll()
{
	REGISTER_INIT(VolumeArrayBase);	
	REGISTER_INIT(VolumeArraySize);
	REGISTER_INIT(VolumeArrayDimensions);
	REGISTER_INIT(VolumeArrayOffsetModulus);
	REGISTER_INIT(VolumeRangeMin);
	REGISTER_INIT(VolumeRangeMax);
	
	REGISTER_INIT(Depth0ArrayBase);
	REGISTER_INIT(Depth0ArraySize);
	REGISTER_INIT(Depth0ArrayDimensions);
	REGISTER_INIT(Depth0ArrayOffsetModulus);
	REGISTER_INIT(Depth0InitRangeMin);
	REGISTER_INIT(Depth0InitRangeMax);
	
	REGISTER_INIT(Depth1ArrayBase);
	REGISTER_INIT(Depth1ArraySize);
	REGISTER_INIT(Depth1ArrayDimensions);
	REGISTER_INIT(Depth1ArrayOffsetModulus);
	REGISTER_INIT(Depth1InitRangeMin);
	REGISTER_INIT(Depth1InitRangeMax);
	
	REGISTER_INIT(Image0ArrayBase);
	REGISTER_INIT(Image0ArraySize);
	REGISTER_INIT(Image0ArrayDimensions);
	REGISTER_INIT(Image0ArrayOffsetModulus);
	REGISTER_INIT(Image0InitRangeMin);
	REGISTER_INIT(Image0InitRangeMax);
	
	REGISTER_INIT(Image1ArrayBase);
	REGISTER_INIT(Image1ArraySize);
	REGISTER_INIT(Image1ArrayDimensions);
	REGISTER_INIT(Image1ArrayOffsetModulus);
	REGISTER_INIT(Image1InitRangeMin);
	REGISTER_INIT(Image1InitRangeMax);


	REGISTER_INIT(ViewFrustumRangeMin);
	REGISTER_INIT(ViewFrustumRangeMax);
	REGISTER_INIT(Transform);
	
	REGISTER_INIT(LookupTableFormat0);
	REGISTER_INIT(LookupTableFormat1);
	REGISTER_INIT(LookupTableFormat2);
	REGISTER_INIT(LookupTableFormat3);

	REGISTER_INIT(Image0FieldSel);
	REGISTER_INIT(Image1FieldSel);

	REGISTER_INIT(CutPlane0_dCut_dXs);
	REGISTER_INIT(CutPlane0_dCut_dYs);
	REGISTER_INIT(CutPlane0_dCut_dZs);
	REGISTER_INIT(CutPlane0_dCut_dZv);
	REGISTER_INIT(CutPlane0_min);
	REGISTER_INIT(CutPlane0_max);
	REGISTER_INIT(CutPlane1_dCut_dXs);
	REGISTER_INIT(CutPlane1_dCut_dYs);
	REGISTER_INIT(CutPlane1_dCut_dZs);
	REGISTER_INIT(CutPlane1_dCut_dZv);
	REGISTER_INIT(CutPlane1_min);
	REGISTER_INIT(CutPlane1_max);
	REGISTER_INIT(CutPlane2_dCut_dXs);
	REGISTER_INIT(CutPlane2_dCut_dYs);
	REGISTER_INIT(CutPlane2_dCut_dZs);
	REGISTER_INIT(CutPlane2_dCut_dZv);
	REGISTER_INIT(CutPlane2_min);
	REGISTER_INIT(CutPlane2_max);
	REGISTER_INIT(CutPlane3_dCut_dXs);
	REGISTER_INIT(CutPlane3_dCut_dYs);
	REGISTER_INIT(CutPlane3_dCut_dZs);
	REGISTER_INIT(CutPlane3_dCut_dZv);
	REGISTER_INIT(CutPlane3_min);
	REGISTER_INIT(CutPlane3_max);
	REGISTER_INIT(CutPlaneControl);

	REGISTER_INIT(CropControl);	
	REGISTER_INIT(CropRangeXmin);
	REGISTER_INIT(CropRangeXmax);
	REGISTER_INIT(CropRangeYmin);
	REGISTER_INIT(CropRangeYmax);
	REGISTER_INIT(CropRangeZmin);
	REGISTER_INIT(CropRangeZmax);


	REGISTER_INIT(TrimRangeXmin);
	REGISTER_INIT(TrimRangeXmax);
	REGISTER_INIT(TrimRangeYmin);
	REGISTER_INIT(TrimRangeYmax);
	REGISTER_INIT(TrimRangeZmin);
	REGISTER_INIT(TrimRangeZmax);

	
//	REGISTER_INIT(EmptyArrayBase);
//	REGISTER_INIT(EmptyArraySize);
	
	REGISTER_INIT(OriginXv8);
	REGISTER_INIT(OriginYv8);
	REGISTER_INIT(OriginZv8);
	REGISTER_INIT(dXv8_dXs);
	REGISTER_INIT(dYv8_dYs);
	REGISTER_INIT(dZv8_dZs);
	REGISTER_INIT(dXv8_dZs);
	REGISTER_INIT(dYv8_dZs);
	REGISTER_INIT(dYv8_dZv);
	REGISTER_INIT(dXv8_dZv);
	REGISTER_INIT(dYv8_dXs);
	REGISTER_INIT(dXv8_dYs);
	REGISTER_INIT(OriginDepth);
	REGISTER_INIT(dD_dXs);
	REGISTER_INIT(dD_dYs);
	REGISTER_INIT(dD_dZs);
	REGISTER_INIT(dD_dZv);
	
	REGISTER_INIT(VoxelFormat);
	REGISTER_INIT(VoxelBorder);
	
	//------Experiement register for perspective				
	REGISTER_INIT(ddXv8_dXs_dZs);
	REGISTER_INIT(ddXv8_dYs_dZs);
	REGISTER_INIT(ddYv8_dXs_dZs);
	REGISTER_INIT(ddYv8_dYs_dZs);
	REGISTER_INIT(ddXv8_dXs_dZv);
	REGISTER_INIT(ddXv8_dYs_dZv);
	REGISTER_INIT(ddYv8_dXs_dZv);
	REGISTER_INIT(ddYv8_dYs_dZv);
	
	REGISTER_INIT(Alu0);
	REGISTER_INIT(Alu1);
	REGISTER_INIT(Alu2);
	REGISTER_INIT(GradientCorrection0);
	REGISTER_INIT(GradientCorrection1);
	REGISTER_INIT(GradientCorrection2);
	REGISTER_INIT(GradientMagnitudeRange);
	REGISTER_INIT(EyeVector);
	REGISTER_INIT(SpecularColor);
	REGISTER_INIT(LightingCoefficient);
	REGISTER_INIT(GradientMagnitudeModulation);
	REGISTER_INIT(SampleAlphaRange);
	REGISTER_INIT(AccumAlphaRange);

	REGISTER_INIT(DepthInitValue0);
	REGISTER_INIT(DepthInitValue1);
	REGISTER_INIT(ImageAccumValue);
	REGISTER_INIT(ImageLastValue);

	REGISTER_INIT(ErtThreshold);
	REGISTER_INIT(EmptyThreshold);
	
	REGISTER_INIT(Section);
	REGISTER_INIT(SequencerDebug);


//	REGISTER_INIT(AddressOperand);

	REGISTER_INIT(InterpolateControl);
	REGISTER_INIT(GradientControl);
	REGISTER_INIT(DepthControl);
	REGISTER_INIT(ImageControl);

	REGISTER_INIT(RenderOperation);	
}
#undef REGISTER_INIT
#endif // VLIAllRenderRegisters_H_
