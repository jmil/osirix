/*
 *	$Id: vliimagebuffer.h,v 1.4 2004/10/19 17:07:03 vesper Exp $
 *
 *    Copyright 2004 by Real Time Visualization, TeraRecon, Inc.
 *    All Rights Reserved.
 *
 * Omnipotent image buffer support
 */

#ifndef	VLIIMAGEBUFFER_H_
#define VLIIMAGEBUFFER_H_

#include "vli.h"


class VLIOmniImageBuffer : public VLIImageBuffer
{
public:


	// Location and size access

	virtual VLILocation 	GetLocation (void					// Return location of buffer
							) const;

	virtual void			GetSize (							// Return the size of the image in pixels
								unsigned int& outWidth, 		// RETURNED width in pixels
								unsigned int& outHeight 		// RETURNED height in pixels
							) const;

	virtual unsigned int	GetWidth (void						// Return the width of the image in pixels
							) const;

	virtual unsigned int	GetHeight (void 					// Return the height of the image in pixels
							) const;

	virtual unsigned int	GetPixelSize (void					// Return the size of a pixel in bits
							) const;

	// Field descriptor access

	virtual VLIFieldDescriptor	GetFieldDescriptor (			// Return a field descriptor
								VLIChannel inFieldNumber		// which field to return
							) const;

	virtual VLIStatus		SetFieldDescriptor (				// Set a field descriptor
								VLIChannel inFieldNumber,		// which field to set
								const VLIFieldDescriptor &inDescriptor // field descriptor
							);

	// Updating the data in the image

	virtual VLIStatus		Update (							// Update a color image with new values
								const void * inData,			// location of input image data
								const VLIImageRange & inRange,	// range of image to update
								unsigned int inWidth		// width of application buffer (0 means use range)
							);

	virtual VLIStatus		UpdateField (						// Update one color image field with new values
								const void * inData,			// location of input image data
								const VLIFieldDescriptor & inDescriptor, // description of output
								const VLIImageRange & inRange,	// range of image to update
								unsigned int inWidth		// width of application buffer (0 means use range)
							);

	virtual VLISyncEvent	StartUpdate (						// ASYNCHRONOUS Start to update a color image with new values
								const void * inData,			// location of input image data
								const VLIImageRange & inRange,	// range of image to update
								unsigned int inWidth		// width of application buffer (0 means use range)
							);

	virtual VLISyncEvent	StartUpdateField (					// ASYNCHRONOUS Start to update a color image field with new values
								const void * inData,			// location of input image data
								const VLIFieldDescriptor & inDescriptor, // description of output
								const VLIImageRange & inRange,	// range of image to update
								unsigned int inWidth		// width of application buffer (0 means use range)
							);

	virtual VLIStatus		Clear ( 							// Clear a range of this buffer
								const VLIImageRange & inRange,	// range to clear
								VLIuint64 inValue				// clear value
							);

	// Reading the data in the image

	virtual VLIStatus		Unload (							// Unload a color image to application storage
								void * outData, 				// RETURNED pixel data
								const VLIImageRange & inRange,	// range of image to return
								unsigned int inWidth		// width of application buffer (0 means use range)
							) const;

	virtual VLIStatus		UnloadField (						// Unload a color image field to application storage
								void * outData, 				// RETURNED image data
								const VLIFieldDescriptor & inDescriptor, // description of output
								const VLIImageRange & inRange,	// range of image to return
								unsigned int inWidth		// width of application buffer (0 means use range)
							) const;

	virtual VLISyncEvent	StartUnload (						// ASYNCHRONOUS Start to unload a color image to application storage
								void * outData, 				// RETURNED pixel data
								const VLIImageRange & inRange,	// range of image to return
								unsigned int inWidth		// width of application buffer (0 means use range)
							) const;

	virtual VLISyncEvent	StartUnloadField (					// ASYNCHRONOUS Start to unload a color image field to application storage
								void * outData, 				// RETURNED image data
								const VLIFieldDescriptor & inDescriptor, // description of output
								const VLIImageRange & inRange,	// range of image to return
								unsigned int inWidth		// width of application buffer (0 means use range)
							) const;

	// Accessing the data in the image

	virtual VLIStatus		Map (								// Map a 16-bit image into application memory space
								VLIuint16 *& outData,			// RETURNED pointer to image data
								const VLIImageRange & inRange,	// range of image to map in
								unsigned int & outWidth 		// RETURNED width of application buffer
							);

	virtual VLIStatus		Map (								// Map a 32-bit image into application memory space
								VLIuint32 *& outData,			// RETURNED pointer to image data
								const VLIImageRange & inRange,	// range of image to map in
								unsigned int & outWidth 		// RETURNED width of application buffer
							);

	virtual VLIStatus		Map (								// Map a 64-bit image into application memory space
								VLIuint64 *& outData,			// RETURNED pointer to image data
								const VLIImageRange & inRange,	// range of image to map in
								unsigned int & outWidth 		// RETURNED width of application buffer
							);

	virtual VLIStatus		Map (								// Map an image into application memory space
								void *& outData,				// RETURNED pointer to image data
								const VLIImageRange & inRange,	// range of image to map in
								unsigned int & outWidth 		// RETURNED width of application buffer
							);

	virtual VLIStatus		Unmap ( 							// Release an image buffer mapping
								void * inData					// mapped image pointer to be released
							);

	// Addressing modes

	virtual VLIStatus		SetOffset ( 						// Set addressing mode to kVLIOffsetAddress and set the offset values
								int inOffsetX,					// Offset for X (must be even)
								int inOffsetY					// Offset for Y (must be even)
							);

	virtual VLIStatus		SetWrap (							// Set addressing mode to kVLIWrapAddress and set the modulus values
								int inWrapX,					// Wrap modulus for X (must be a power of 2)
								int inWrapY 					// Wrap modulus for Y (must be a power of 2)
							);

	virtual VLIStatus		SetAddressParameters (				// Set the addressing parameters
								VLIAddressMode inMode,			// kVLIOffsetAddress or kVLIWrapAddress
								int inAddressParameterX,		// Offset or wrap modulus for X
								int inAddressParameterY 		// Offset or wrap modulus for Y
							);

	virtual void			GetAddressParameters (				// Return the addressing parameters
								VLIAddressMode & outMode,		// RETURNED kVLIOffsetAddress or kVLIWrapAddress
								int& outAddressParameterX,		// RETURNED Offset or wrap modulus for X
								int& outAddressParameterY		// RETURNED Offset or wrap modulus for Y
							) const;

	virtual int 			GetAddressParameterX (void) const;	// Return buffer offset or wrap X value

	virtual int 			GetAddressParameterY (void) const;	// Return buffer offset or wrap Y value

	virtual VLIAddressMode	GetAddressMode (void) const;	// Return kVLIOffsetAddress or kVLIWrapAddress

	// Ranges of interest, input and output

	virtual VLIImageRange	GetInputLimits (void				// Return the input limits (initial range)
							) const;

	virtual VLIStatus		SetInputLimits (					// Set the input limits (initial range)
								const VLIImageRange & inLimits	// input limits
							);

	virtual VLIImageRange	GetOutputLimits (void				// Return the output limits (view frustum?)
							) const;

	// TODO AFV 11/10/2000: Do we want this?
	virtual VLIStatus		SetOutputLimits (					// Set the output limits (view frustum?)
								const VLIImageRange & inLimits	// output limits
							);

	// The border value is used outside the input limits

	virtual void			GetBorderValue (					// Return the border value (double)
								double & outRed,				// red component, 0.0 to 1.0
								double & outGreen,				// green component, 0.0 to 1.0
								double & outBlue,				// blue component, 0.0 to 1.0
								double & outAlpha				// alpha component, 0.0 to 1.0
							) const;

	virtual double			GetBorderRed (void) const;		// Return the red component of the border value

	virtual double			GetBorderGreen (void) const;	// Return the Green component of the border value

	virtual double			GetBorderBlue (void) const; 	// Return the Blue component of the border value

	virtual double			GetBorderAlpha (void) const;	// Return the Alpha component of the border value

	virtual VLIStatus		SetBorderValue (					// Set the border value (double)
								double inRed,					// red component, 0.0 to 1.0
								double inGreen, 				// green component, 0.0 to 1.0
								double inBlue,					// blue component, 0.0 to 1.0
								double inAlpha					// alpha component, 0.0 to 1.0
							);

	virtual VLIStatus Resample (							// Resample the image to a different size
							VLIImageBuffer * outDestination,			// destination image buffer
							const VLIImageRange & inDestinationRange,	// detination range
							const VLIImageRange & inSourceRange			// source range
						);

	virtual VLISyncEvent StartResample (							// ASYNCHRONOUS Resample the image to a different size
							VLIImageBuffer * outDestination,			// destination image buffer
							const VLIImageRange & inDestinationRange,	// detination range
							const VLIImageRange & inSourceRange			// source range
						);

	virtual VLIStatus       SetMigrationMode (                  // Set migration mode
                                VLIMigrationMode inMode         // mode
                            );

    virtual VLIMigrationMode    GetMigrationMode (              // Return migration mode
                            ) const;

    virtual VLIStatus       Migrate (                           // Migrate buffer to particular location (board)
                                VLILocation inLocation          // board
                            );

    virtual VLISyncEvent    StartMigrate (                      // ASYNCHRONOUS Start to migrate buffer to particular location (board)
                                VLILocation inLocation          // board
                            );

	virtual VLISerialNumber	GetLastVolumeRendered (				// Return ID of last volume rendered to this buffer
							) const;


	// methods not inherited from VLIImageBuffer

	VLIImageBufferInternal *	GetImageBuffer (void) 
	{ 
		VLI_ASSERT (m_location != kVLIMultiBoardMode1);
		return m_subBuffers.GetBuffer(0); 
	}

	int GetNumberBuffers (void) const { return m_numberSubBuffers; }

	VLIImageBufferInternal * GetSubImageBuffer (int i)
	{
		VLI_ASSERT (i >= 0 && i < m_numberSubBuffers );
		return m_subBuffers.GetBuffer(i);
	}

	VLIImageRange GetSubImageRange (int i)
	{
		VLI_ASSERT (i >= 0 && i < m_numberSubBuffers );
		return m_subBuffers.Range(i);
	}

	VLISyncEvent    DoStartMigrate (                      // ASYNCHRONOUS Start to migrate buffer to particular location (board)
                                VLILocation inLocation,          // board
								const VLIImageRange & inRange	// range to move
                            );

	void				SetLastVolumeRendered (VLISerialNumber inVolume) { m_lastVolume = inVolume; }

private:
	friend VLIImageBuffer * VLIImageBuffer::Create (
			VLILocation					m_location,				// Where to create buffer (must be specific)
			unsigned int				inWidth,				// width in pixels
			unsigned int				inHeight,				// height in pixels
			unsigned int				inPixelSize,			// size of pixel in bits (16, 32 or 64)
			int							inNumberOfFields,		// number of fields in field array
			const VLIFieldDescriptor	inFieldArray[]			// pointer to field array
			);

	VLIOmniImageBuffer (
							VLILocation inLocation, 		// location -- cannot be kVLIAnyBoard
							unsigned int inWidth,			// width in pixels
							unsigned int inHeight,			// height in pixels
							unsigned int inPixelSize,		// size of pixel in bits (16, 32, or 64)
							int inNumberOfFields,		// number of fields in field array
							const VLIFieldDescriptor inFieldArray[] // pointer to field array
							);

	VLIStatus CreateSubBuffers (VLILocation inLocation, int & outNumberBoardBuffersCreated);

	void ReleaseSubBuffers (void);

	virtual ~VLIOmniImageBuffer (void);


	VLIStatus		ConvertTo3D (void);

	VLISyncEvent	DoStartResample (
								VLIImageBuffer * outDestination,	// ASYNCHRONOUS Start resampling the image
								const VLIImageRange & inDestinationRange,
								const VLIImageRange & inSourceRange
							);

	// Data

	class SubBufferInfo
	{
	public:
		SubBufferInfo (void)
		{
			for (int b = 0; b < kMultiboardMaxVolumes; ++b)
			{
				m_buffer[b] = NULL;
			}
		}

		SubBufferInfo (const SubBufferInfo & inCopy);

		~SubBufferInfo (void)
		{
			ReleaseAll ();
		}

		void Set (int b, VLIImageBufferInternal * inBuffer, const VLIImageRange & inRange)
		{
			if (inBuffer) inBuffer->AddRef();
			if (m_buffer[b]) m_buffer[b]->Release();
			m_buffer[b] = inBuffer;
			m_range[b] = inRange;
		}

		void Release (int b)
		{
			if (m_buffer[b]) 
			{
				m_buffer[b]->Release();
				m_buffer[b] = NULL;
			}
		}

		void ReleaseAll (void)
		{
			for (int b = 0; b < kMultiboardMaxVolumes; ++b)
			{
				if (m_buffer[b]) 
				{
					m_buffer[b]->Release();
					m_buffer[b] = NULL;
				}
			}
		}

		VLIImageBufferInternal *	GetBuffer(int b) { return m_buffer[b]; }
		const VLIImageBufferInternal *	GetBuffer(int b) const { return m_buffer[b]; }
		VLIImageRange &				Range (int b) { return m_range[b]; }
		const VLIImageRange &		Range (int b) const { return m_range[b]; }

	private:
		VLIImageBufferInternal *	m_buffer[kMultiboardMaxVolumes];
		VLIImageRange				m_range[kMultiboardMaxVolumes];
	};


	// Member data items

	VLILocation			m_location;							// location of this buffer
	VLIImageRange		m_wholeRange;
	unsigned int		m_pixelSize;						// size of pixel in bits (16, 32, or 64)
	VLIImageRange		m_inputLimits;						// input limits (initial range)
	VLIImageRange		m_outputLimits;						// output limits (view frustum?)
	VLIAddressMode		m_addressMode;						// wrap mode flag
	int					m_addressParameterX;				// offset or modulus for X
	int					m_addressParameterY;				// offset or modulus for Y
	VLIuint16			m_borderValue[kVLIMaxOutputChannels]; // border color value
	VLIFieldDescriptor	m_fieldList[kVLIMaxPixelFields];	// field descriptors
	VLIMigrationMode	m_migrationMode;					// can we migrate to another board?
	bool				m_is3D;								// True if this is a 3D buffer

	SubBufferInfo		m_subBuffers;
	int					m_numberSubBuffers;					// Number of BOARD buffers, does not count m_systemBuffer
	char *				m_systemBuffer;
	VLISyncEvent		m_systemBufferEvent;

	void *				m_mapAddress;
	char *				m_mapBuffer;						// Used for MB1 map buffer
	VLIImageRange		m_mapRange;

	VLISerialNumber		m_lastVolume;

};


#endif // VLIIMAGEBUFFER_H_
