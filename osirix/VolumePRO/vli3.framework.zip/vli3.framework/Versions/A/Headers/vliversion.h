/*****************************************************************************
 *
 *	$Id: vliversion.h,v 1.19 2004/10/22 16:21:06 vesper Exp $
 *
 *	Purpose:
 *		This file provides the version information for VLI. It is used by the
 *		Microsoft Visual Studio resource script, VLIVersionInfo.rc, the
 *		SetDateBuilt program for Unix builds, and by vliinternal.h to select
 *		between the normal and the advanced features builds of VLI.
 *
 *	Copyright 2003,2004 by Real Time Visualization, TeraRecon, Inc.
 *	All Rights Reserved.
 *
 ****************************************************************************/

#ifndef VLIVERSION_H
#define VLIVERSION_H

#define VLI_VERSION_MAJOR		3
#define VLI_VERSION_MINOR		3
#define VLI_VERSION_SUB			1
#define VLI_VERSION_MICRO		2
#define VLI_VERSION_NAME		Beta2

#ifndef VLI_VERSION_ADVANCED
#error VLI_VERSION_ADVANCED *Must be defined*
#endif

#define VLI_VERSION_DOT			VLI_VERSION_MAJOR.VLI_VERSION_MINOR.VLI_VERSION_SUB.VLI_VERSION_MICRO
#define VLI_VERSION_COMMA		VLI_VERSION_MAJOR,VLI_VERSION_MINOR,VLI_VERSION_SUB,VLI_VERSION_MICRO

#if VLI_VERSION_ADVANCED
	#define VLI_VERSION_FULL	VLI_VERSION_DOT VLI_VERSION_NAME AF
#else
	#define VLI_VERSION_FULL	VLI_VERSION_DOT VLI_VERSION_NAME
#endif

#define VLI_VERSION_STRING		VLI_QSTRING(VLI_VERSION_FULL)

// Helper macros
#define VLI_QSTRING(s)			VLI_QQSTRING(s)
#define VLI_QQSTRING(s)			#s

#endif // VLIVERSION_H
