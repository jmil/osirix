/*
 *  $Id: VLISoftwareBlendVolume.h,v 1.9 2004/10/19 17:07:01 vesper Exp $
 *
 *    Copyright 2002,2003,2004 by Real Time Visualization, TeraRecon, Inc.
 *    All Rights Reserved.
 *
 */
// VLISoftwareBlendVolume.h: interface for the VLISoftwareBlendVolume class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(VLISOFTWAREBLENDVOLUME_H_)
#define VLISOFTWAREBLENDVOLUME_H_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


#include "vliinternal.h"
#include "vliimagebuffer.h"

class VLISoftwareBlendVolume
{
public:
	static VLISoftwareBlendVolume* Create();							// Create a singleton

	VLISoftwareBlendVolume ();
	~VLISoftwareBlendVolume ();

	const int					GetNumSubvolumes() {return m_numSubvolumes;}
	
	void						SetFieldDescriptorsImage0  (const VLIFieldDescriptor inFieldArray[]);
	void						SetFieldDescriptorsImage1 (const VLIFieldDescriptor inFieldArray[]);
	void						SetFieldDescriptorsTransferBuffers (const VLIFieldDescriptor inFieldArray[]);

	void						SetVoxelSizeImage0 (const int inVoxelSize)
									{m_voxelSizeImage0 = inVoxelSize;}
	void						SetVoxelSizeImage1(const int inVoxelSize)
									{m_voxelSizeImage1 = inVoxelSize;}
	void						SetVoxelSizeTransferBuffer (const int inVoxelSize)
									{ m_voxelSizeTransferBuffer = inVoxelSize;}
	void						SetVoxelSizeOutputBuffer (const int inVoxelSize)
									{ m_voxelSizeOutputBuffer= inVoxelSize;}

	void						SetNumOfSubvolumes (const int inNumOfSubolumes)
									{m_numSubvolumes = inNumOfSubolumes;}

	VLISyncEvent				StartUpdate(int inBlendIndex[]);
	VLIStatus					StartBlend (VLIImageBuffer *inOutColor0, VLIImageBuffer *inOutColor1, 
										int *m_softwBlendIndex,  VLIImageRange *allOutputRange, 
										char* m_accumBuffer, char* m_transferBuffer[]);
	void						BlendTwoBuffers8888(VLIuint8 *inresBuff, VLIuint8 *insampleBuff, VLIuint8 *inaccumBuff, 
										 VLIImageRange &inrangeToBlend, int inbufferwidth, 
										 VLIFieldDescriptor infieldDescriptorRes[],
										 VLIFieldDescriptor infieldDescriptorSample[],
										 VLIFieldDescriptor infieldDescriptorAccum[],
										 int invoxelSizeRes, int invoxelSizeSample, int invoxelSizeAccum);
	void						UpdateSubBuffers(VLILocation inLocation, int inWidth, int inHeight, int ind);




	VLIImageRange				m_maxImageRange;
	VLIBlendMode				m_blendMode;
	VLIBlendMode				m_LastBlendMode;
	VLIImageBufferInternal		*m_subbuffer[kMultiboardMaxVolumes];


private:

	// Private data
	unsigned int				m_voxelSizeImage0;
	unsigned int				m_voxelSizeImage1;
	unsigned int				m_voxelSizeTransferBuffer;
	unsigned int				m_voxelSizeOutputBuffer;

													// between boards
	int							m_numSubvolumes;
	int							m_numBoards;
	VLIFieldDescriptor			m_fieldDescriptorImage0[kVLIMaxPixelFields];
	VLIFieldDescriptor			m_fieldDescriptorImage1[kVLIMaxPixelFields];
	VLIFieldDescriptor			m_fieldDescriptorTransferBuffers[kVLIMaxPixelFields];
};





// Inline Functions
inline
void VLISoftwareBlendVolume::SetFieldDescriptorsImage0 (const VLIFieldDescriptor inFieldArray[])
{

	for (int i = 0; i < kVLIMaxPixelFields; i++)
		m_fieldDescriptorImage0[i] = inFieldArray[i];

}
	
inline
void VLISoftwareBlendVolume::SetFieldDescriptorsImage1 (const VLIFieldDescriptor inFieldArray[])
{

	for (int i = 0; i < kVLIMaxPixelFields; i++)
		m_fieldDescriptorImage1[i] = inFieldArray[i];

}

inline
void VLISoftwareBlendVolume::SetFieldDescriptorsTransferBuffers (const VLIFieldDescriptor inFieldArray[])
{

	for (int i = 0; i < kVLIMaxPixelFields; i++)
		m_fieldDescriptorTransferBuffers[i] = inFieldArray[i];

}
	


#endif 
