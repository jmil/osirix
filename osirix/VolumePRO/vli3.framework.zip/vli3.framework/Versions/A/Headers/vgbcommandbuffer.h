/*
 * $Id: vgbcommandbuffer.h,v 1.7 2004/10/19 17:07:09 vesper Exp $
 *
 * User mode interface to the Volume Graphics Board device driver.
 *
 *    Copyright 2001,2002,2003,2004 by Real Time Visualization, TeraRecon, Inc.
 *    All Rights Reserved.
 */


#ifndef VGBCOMMANDBUFFER_H
#define VGBCOMMANDBUFFER_H

// Define a class to implement a buffer of commands
// so that VLI can request register loading and other
// operations that will eventually go into the
// Condor Render Queue.

typedef unsigned int		VGBCommandBlockID;
typedef unsigned int		VGBRegisterAddr;	// Relative to "regBase"
typedef unsigned int		VGBCommandIndex;

class VGBCommandBuffer
{
public:
						VGBCommandBuffer (void);
				virtual	~VGBCommandBuffer (void);

	// VLI makes the following calls to write a block of commands
	// Into the VGBCommandBuffer.

	virtual VLIStatus			StartBlock (VGBCommandBlockID &outID);	// Call this at the start of a rendering
	virtual VLIStatus			FinishBlock (unsigned int &outSize);	// Call this to finalize the block
											
	virtual VLIStatus			WriteRegister32 (VGBRegisterAddr inRegisterAddr, VLIuint32 inRegisterValue);
	virtual VLIStatus			WriteRegister64 (VGBRegisterAddr inRegisterAddr, VLIuint64 inRegisterValue);
	virtual VLIStatus			IncrRegister (VGBRegisterAddr inRegisterAddr, VLIuint32 inIncrValue);
	virtual VLIStatus			Noop (bool inInterrupt, bool inHalt, bool inHaltAll);
	virtual VLIStatus			Sync (VGBRegisterAddr inRegisterAddr, unsigned int inTest, VLIuint32 inValue,
									bool inForceRefetch);
	virtual VLIStatus			StoreRegister (VGBRegisterAddr inRegisterAddr, VLIuint64 * outAddress);
	virtual VLIStatus			StartDMA (bool inIn, unsigned int inCount);
	virtual VLIStatus			DMASegment (VLIuint64 inHostAddress, VLIuint32 inLength, 
									VLIuint32 inHostIncr);
	virtual VLIStatus			EndDMA (void);

	// Other commands needed, such as IncrRegister()

	// The VGB wrapper needs to get the start address
	// and size of the block to pass them to the driver

	virtual VLIuint64 *			GetBlockAddress (VGBCommandBlockID inID) = 0;

	// When the command block is re-usable, VGB wrapper needs to call

	virtual VLIStatus			ReleaseBlock (VGBCommandBlockID inID, unsigned int inSize) = 0;

	virtual void				DumpBlock (VGBCommandBlockID inID, unsigned int inSize);

private:	// methods
	virtual VLIStatus			FlushPendingData (void);
	virtual VLIStatus			CheckForFreeSpace (int inFreeSpaceNeeded) = 0;
	virtual VLIStatus			WaitForFreeSpace (int inFreeSpaceNeeded) = 0;
	virtual VGBCommandIndex		GetNextIndex (void) = 0;
	virtual VLIStatus			WriteNextWord (VLIuint64 inWord) = 0;
	virtual VLIStatus			WriteWordAt (VGBCommandIndex inOffset, VLIuint64 inWord) = 0;
	virtual VLIuint64			ReadWordAt  (VGBCommandIndex inOffset) = 0;

protected:	// data
	
	// Block state
	VGBCommandIndex		m_blockBase;		// offset for block being written (NOT_SET if no block is open)
	unsigned int		m_blockSize;		// size of block being written
	VGBCommandIndex		m_currentCommand;	// offset of command being written (LoadRegisters)
	VLIuint64			m_commandData;		// copy of current commnad (LoadRegisters)
	VGBRegisterAddr		m_currentBaseAddr;	// addr of first register in the current command
	VGBRegisterAddr		m_nextRegisterAddr;	// addr of next register that can be added to the current command
	VLIuint64			m_pendingData;		// pending register load data
	VGBRegisterAddr		m_pendingAddr;		// pending register load address (NOT_SET if non pending)

};


#endif // VGBCOMMANDBUFFER_H
