/*
 * $Id: CubeST3H.h,v 1.3 2003/01/09 19:00:05 ford Exp $
 *
 *    Copyright 2002 by Real Time Visualization, TeraRecon, Inc.
 *    All Rights Reserved.
 *
 */  
// CubeST3H.h - Cube Object with x,y,z,h, and s,t values
#ifndef CUBEST3H_H
#define CUBEST3H_H

#define CUBE_POLYS 6
#define CUBE_SIDES 6

class CubeST3H {

public:

  // Constructors
  CubeST3H (void);

  CubeST3H (PointST3H &min, PointST3H &max);

  // Operate on the Cube

  // Transform the Cube Sides
  void Transform (Mat44 &inMat);

  // Transform the Axis and Origin Points
  void TransformAxis (Mat44 &inMat);

  // Transform Cube Sides and the Axis and Origin Points
  void TransformAll (Mat44 &inMat);

  // Apply DivideW to the Cube Sides
  void DivideW (void);

  // Apply DivideW to the Axis and Origin Points
  void DivideWAxis (void);

  // Apply DivideW to Cube Sides and Axis and Origin Points
  void DivideWAll (void);


  // Get, Put
  // Get Polygon
  PolygonST3H GetPolygon (int index);

  // Get Near Polygon
  PolygonST3H GetNearPoly (int index, double vectX, double vectY, double vectZ);
  PolygonST3H GetNearPoly (int index, Vector3D &inVect3D);

  // Get Far Polygon
  PolygonST3H GetFarPoly (int index, double vectX, double vectY, double vectZ);
  PolygonST3H GetFarPoly (int index, Vector3D &inVect3D);

#if 0
  // Get Near Side
  int GetNearSide (int index, double vectX, double vectY, double vectZ);
  int GetNearSide (int index, Vector3D &inVect3D);

  // Get Far Side
  int GetFarSide (int index, double vectX, double vectY, double vectZ);
  int GetFarSide (int index, Vector3D &inVect3D);
#endif // 0

  // Get surrounding XYZ Box
  BoxST3H GetBoxXYZ (void);

  // Update surrounding XYZ Box, given an Initial XYZ Box
  void UpdBoxXYZ (BoxST3H &inBox);

  // Get Number of Front Facing Polygons
  int GetFrontFacing (void);

  // Print
  // Print out the CubeST3H
  void Print (void);

protected:

  // Function for ordering giving Nearest, next, furthest Axis
  // Given a vector pointing in the direction of view
  // One edge of a cube is most "near" the viewer, this can
  //  be on either side of the X, Y, or Z axis
  void SortAxis (double vectX, double vectY, double vectZ);

  // Store a local Coordinate system axis to aid in the
  //  test for which axis to use during Rendering
  // To save time, we store an Origin and XYZ points
  PointST3H m_orig, m_xaxis, m_yaxis, m_zaxis;

  // Store the original Min/Max X,Y,Z of the Volume
  PointST3H mDimMin, mDimMax;

  // Store Polygons in an array, for now
  PolygonST3H m_poly [CUBE_POLYS];

  // Arrays for getting results from the axis ordering process
  int orderNear [3], orderFar [3];

private:

};
#endif
