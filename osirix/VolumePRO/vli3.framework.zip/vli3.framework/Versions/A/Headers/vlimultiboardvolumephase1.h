/*
 *  $Id: vlimultiboardvolumephase1.h,v 1.20 2004/10/19 17:07:05 vesper Exp $
 *
 *    Copyright 2001,2002,2003,2004 by Real Time Visualization, TeraRecon, Inc.
 *    All Rights Reserved.
 *
 * VLIMultiboard volume wrapper
 */

#ifndef VLIMULTIBOARDVOLUMEPHASE1_H_
#define VLIMULTIBOARDVOLUMEPHASE1_H_

#include "vlimipmapvolume.h"

// A bogus friend class to keep gcc from
// complaining "only defines a private destructor
// and has no friends".

class FriendClassForMBVolumePhase1;

class VLIMultiboardVolumePhase1 : public VLIVolume
{
	friend class FriendClassForMBVolumePhase1;

protected:


public:

	// Routines to implement VLIVolume virtual routines.
	// These are all overrides
	// Queries for whole volume state

	VLIbool		IsReadOnly (void				// Was this volume created in read-only mode?
				) const;

	VLIuint32	GetFormat(void					// DEPRECATED Return format of the volume
				) const;

	Layout		GetLayout(void					// DEPRECATED Return layout of the volume(slice/block)
				) const;
	
	VLIVolumeRange	GetRange (void				// Return the range (size and origin) of the volume in voxels
				) const;


	void		GetSize (						// Return the size of the volume in voxels
					unsigned int& nXVox,		// RETURNED size of volume in X in voxels
					unsigned int& nYVox, 		// RETURNED size of volume in Y in voxels
					unsigned int& nZVox			// RETURNED size of volume in Z in voxels
				) const;

	unsigned int GetSizeX (void					// Return the X size of the volume
				) const;

	unsigned int GetSizeY (void					// Return the Y size of the volume
				) const;

	unsigned int GetSizeZ (void					// Return the Z size of the volume
				) const;

	int			GetVoxelSize (void				// Return the size of voxel in bits (8, 16 or 32)
				) const;

	// Field descriptor access

	VLIFieldDescriptor	GetFieldDescriptor (	// Return a field descriptor
					VLIFieldNumber inFieldNumber 					// which field to return
				) const;

	VLIStatus	SetFieldDescriptor (			// Set a field descriptor
					VLIFieldNumber inFieldNumber,				// which field to set
					const VLIFieldDescriptor &inDescriptor	// field descriptor
				);

	// Locking and unlocking

	VLIStatus	LockVolume (					// Lock volume onto a board
					VLILocation inLocation		// board on which to lock: kVLIAnyBoard for any board
				);

	VLIbool		IsLocked (void					// Return VLItrue if volume is locked
				) const;

	VLIStatus	UnlockVolume (					// Unlock the volume from a board
					VLIbool inUnloadToSource	// should VLI unload modified data back to the source?
				);

	// Access to model and correction matrices

	VLIStatus	SetModelMatrix (				// DEPRECATED Set the model matrix from the given one
					const VLIMatrix& inModel	// new model matrix to set in volume
				);

	VLIMatrix	GetModelMatrix (void			// DEPRECATED Return the model matrix
				) const;

	VLIStatus	SetCorrectionMatrix (			// Set the correction matrix
					const VLIMatrix& inCorrection	// new correction matrix to set in volume
				);

	VLIMatrix	GetCorrectionMatrix (void		// Return the correction matrix
				) const;

	// Subvolume Rendering

	VLIStatus	SetActiveSubVolumeSize (		// DEPRECATED Set the active subvolume size
					unsigned int inNX,			// size of active subvolume in X in voxels
					unsigned int inNY,			// size of active subvolume in Y in voxels
					unsigned int inNZ			// size of active subvolume in Z in voxels
				);

	void		GetActiveSubVolumeSize (		// DEPRECATED Return the active subvolume size
					unsigned int& inNX,			// RETURNED size of active subvolume in X in voxels
					unsigned int& inNY,			// RETURNED size of active subvolume in Y in voxels
					unsigned int& inNZ			// RETURNED size of active subvolume in Z in voxels
				) const;

	int GetActiveSubVolumeSizeX (void	// Return the active subvolume size in X
				) const;

	int GetActiveSubVolumeSizeY (void	// Return the active subvolume size in Y
				) const;
	
	int GetActiveSubVolumeSizeZ (void	// Return the active subvolume size in Z
				) const;

	VLIStatus	SetActiveSubVolumeOrigin (		// DEPRECATED Set the active subvolume origin
					unsigned int inNX,			// origin of active subvolume in X in voxels
					unsigned int inNY,			// origin of active subvolume in Y in voxels
					unsigned int inNZ			// origin of active subvolume in Z in voxels
				);

	void		GetActiveSubVolumeOrigin (		// DEPRECATED Return the active subvolume origin
					unsigned int& inNX,			// RETURNED origin of active subvolume in X in voxels
					unsigned int& inNY,			// RETURNED origin of active subvolume in Y in voxels
					unsigned int& inNZ			// RETURNED origin of active subvolume in Z in voxels
				) const;

	int GetActiveSubVolumeOriginX (void			// Return the active subvolume origin in X
				) const;

	int GetActiveSubVolumeOriginY (void			// Return the active subvolume origin in Y
				) const;
	
	int GetActiveSubVolumeOriginZ (void			// Return the active subvolume origin in Z
				) const;

	VLIStatus	SetActiveSubVolume (			// Set the active subvolume
					const VLIVolumeRange &inVolumeRange	// range for the active subvolume
				);

	VLIVolumeRange		GetActiveSubVolume (	// Return the active subvolume
				) const;

	VLIStatus		SetBorderValue (					// Set the border value (VLIuint32)
								VLIuint32 inBorderValue 		// border value (voxel value)
							);

	VLIuint32		GetBorderValue (void				// Return the border value
							) const;

	VLIStatus		SetExtendMode (						// Set extend modes for all dimensions
								ExtendMode inCommonMode			// extend mode to use for all dimension
							);

	VLIStatus		SetExtendModes (					// Set extend modes
								ExtendMode inXMode,				// extend mode to use for the X dimension
								ExtendMode inYMode,				// extend mode to use for the Y dimension
								ExtendMode inZMode				// extend mode to use for the Z dimension
							);

	void			GetExtendModes (					// Return extend modes
								ExtendMode &outXMode,			// RETURNED extend mode to use for the X dimension
								ExtendMode &outYMode,			// RETURNED extend mode to use for the Y dimension
								ExtendMode &outZMode			// RETURNED extend mode to use for the Z dimension
							) const;

	ExtendMode		GetExtendModeX (void				// Return extend mode to use for the X dimension
							) const;

	ExtendMode		GetExtendModeY (void				// Return extend mode to use for the Y dimension
							) const;

	ExtendMode		GetExtendModeZ (void				// Return extend mode to use for the Z dimension
							) const;

	// Updating the volume with new data

	VLIStatus	UpdateVolume (					// DEPRECATED Update a range of a volume with new data
					VLIuint32 inFormat,			// voxel format
					const void *inVoxels,		// new data
					unsigned int inTargetXVox,	// where to change the volume in X
					unsigned int inTargetYVox,	// where to change the volume in Y
					unsigned int inTargetZVox,	// where to change the volume in Z
					unsigned int inNXVox,		// size of the volume range in X
					unsigned int inNYVox,		// size of the volume range in Y
					unsigned int inNZVox,		// size of the volume range in Z
					VLIVolume::Layout layout	// layout: must be kSliced
				);

	VLIStatus	Update (					// Update a range of a volume with new data
					const void *inVoxels,				// data
					const VLIVolumeRange &inVolumeRange	// range of data to update
				);

	VLIStatus	Update (						// Update a range of a volume from another volume
					const VLIVolume * inVolume,	// volume supplying source
					const VLIVolumeRange &inDestinationRange,	// range of data to update
					int inSourceX,				// X Origin of source range
					int inSourceY,				// Y Origin of source range
					int inSourceZ,				// Z Origin of source range
					VLISource inSource			// Do we want the source or the buffer of inVolume?
												// (default: current target)
				);

	VLIStatus	UpdateField (					// Update a field of a range of a volume with new data
					const void				 * inVoxels,			// location of input data
					const VLIVolumeRange	 & inVolumeRange,		// range of volume to update
					const VLIFieldDescriptor & inDestinationField	// description of output
				);

	VLISyncEvent StartUpdate (					// ASYNCHRONOUS Start to Update a range of a volume with new data
					const void *inVoxels,		// data
					const VLIVolumeRange &inDestinationRange	// range of data to update
				);

	VLISyncEvent StartUpdate (					// ASYNCHRONOUS Start to update a range of a volume from another volume
					const VLIVolume * inVolume,	// volume supplying source
					const VLIVolumeRange &inDestinationRange,	// range of data to update
					int inSourceX,				// X Origin of source range
					int inSourceY,				// Y Origin of source range
					int inSourceZ,				// Z Origin of source range
					VLISource inSource		// Do we want the source or the buffer of inVolume?
												// (default: current target)
				);

	VLISyncEvent StartUpdateField (				// ASYNCHRONOUS Start to update a field of a range of a volume with new data
					const void				 * inVoxels,			// location of input data
					const VLIVolumeRange	 & inVolumeRange,		// range of volume to update
					const VLIFieldDescriptor & inDestinationField	// description of output
				);

	// Mapping the volume for application access

	VLIStatus	MapVolume ( 					// Return a pointer to 8-bit voxel data
					VLIAccessType inAccess,		// access type requested
					VLIuint8 *&outBaseAddress,	// RETURNED address of data
					unsigned int &outSx,		// RETURNED size of mapping in X, in voxels
					unsigned int &outSy,		// RETURNED size of mapping in Y, in voxels
					VLISource inSource			// Do we want the source or the buffer of inVolume?
				);

	VLIStatus	MapVolume ( 					// Return a pointer to 16-bit voxel data
					VLIAccessType inAccess,		// access type requested
					VLIuint16 *&outBaseAddress,	// RETURNED address of data
					unsigned int &outSx,		// RETURNED size of mapping in X, in voxels
					unsigned int &outSy,		// RETURNED size of mapping in Y, in voxels
					VLISource inSource			// Do we want the source or the buffer of inVolume?
				);

	VLIStatus	MapVolume ( 					// Return a pointer to 32-bit voxel data
					VLIAccessType inAccess,		// access type requested
					VLIuint32 *&outBaseAddress,	// RETURNED address of data
					unsigned int &outSx,		// RETURNED size of mapping in X, in voxels
					unsigned int &outSy,		// RETURNED size of mapping in Y, in voxels
					VLISource inSource			// Do we want the source or the buffer of inVolume?
				);

	VLIStatus	MapVolume ( 					// Return a pointer to voxel data
					VLIAccessType inAccess,		// access type requested
					void *&outBaseAddress,		// RETURNED address of data
					unsigned int &outSx,		// RETURNED size of mapping in X, in voxels
					unsigned int &outSy,		// RETURNED size of mapping in Y, in voxels
					VLISource inSource			// Do we want the source or the buffer of inVolume?
				);

	VLIStatus	MapSubVolume (					// DEPRECATED Return a pointer to a portion of voxel data
					VLIAccessType inAccess,		// access type requested
					unsigned int inAtX,			// position of volume range in X
					unsigned int inAtY, 		// position of volume range in Y
					unsigned int inAtZ,			// position of volume range in Z
					unsigned int inNx, 			// position of volume range in X
					unsigned int inNy, 			// position of volume range in Y
					unsigned int inNz,			// position of volume range in Z
					void *&outBaseAddress,		// RETURNED address of data
					unsigned int &outSx,		// RETURNED size of mapping in X, in voxels
					unsigned int &outSy,		// RETURNED size of mapping in Y, in voxels
					VLISource inSource			// Do we want the source or the buffer?
				);

	VLIStatus	MapSubVolume (					// Return a pointer to a portion of 8-bit voxel data
					VLIAccessType inAccess,		// access type requested
					const VLIVolumeRange & inVolumeRange,	// range of data to map
					VLIuint8 *&outBaseAddress,	// RETURNED address of data
					unsigned int &outSx,		// RETURNED size of mapping in X, in voxels
					unsigned int &outSy,		// RETURNED size of mapping in Y, in voxels
					VLISource inSource			// Do we want the source or the buffer?
				);

	VLIStatus	MapSubVolume (					// Return a pointer to a portion of 16-bit voxel data
					VLIAccessType inAccess,		// access type requested
					const VLIVolumeRange & inVolumeRange,	// range of data to map
					VLIuint16 *&outBaseAddress,	// RETURNED address of data
					unsigned int &outSx,		// RETURNED size of mapping in X, in voxels
					unsigned int &outSy,		// RETURNED size of mapping in Y, in voxels
					VLISource inSource			// Do we want the source or the buffer?
				);

	VLIStatus	MapSubVolume (					// Return a pointer to a portion of 32-bit voxel data
					VLIAccessType inAccess,		// access type requested
					const VLIVolumeRange & inVolumeRange,	// range of data to map
					VLIuint32 *&outBaseAddress,	// RETURNED address of data
					unsigned int &outSx,		// RETURNED size of mapping in X, in voxels
					unsigned int &outSy,		// RETURNED size of mapping in Y, in voxels
					VLISource inSource			// Do we want the source or the buffer?
				);

	VLIStatus	MapSubVolume (					// Return a pointer to a portion of voxel data
					VLIAccessType inAccess,		// access type requested
					const VLIVolumeRange & inVolumeRange,	// range of data to map
					void *&outBaseAddress,		// RETURNED address of data
					unsigned int &outSx,		// RETURNED size of mapping in X, in voxels
					unsigned int &outSy,		// RETURNED size of mapping in Y, in voxels
					VLISource inSource			// Do we want the source or the buffer?
				);

	VLIStatus	UnmapVolume (void				// Unmap volume or subvolume
				);

	// Unloading volume data to application memory

	VLIStatus	Unload (						// Unload volume data to application memory
					void * outVoxels,						// where to place the data
					const VLIVolumeRange & inVolumeRange,	// range of data to unload
					VLISource inSource						// Do we want the source or the buffer?
				) const;

	VLIStatus	UnloadField (							// Unload a field of volume data to application memory
					void * outVoxels,					// where to place the data
					const VLIVolumeRange	 & inVolumeRange,	// range of volume to unload
					const VLIFieldDescriptor & inVolumeField,	// description of field to unload
					VLISource inSource					// Do we want the source or the buffer?
				) const;

	VLISyncEvent StartUnload (					// ASYNCHRONOUS Start to unload volume data to application memory
					void * outVoxels,						// where to place the data
					const VLIVolumeRange & inVolumeRange,	// range of data to unload
					VLISource inSource						// Do we want the source or the buffer?
				) const;

	VLISyncEvent StartUnloadField (				// ASYNCHRONOUS Start to unload a field of volume data to application memory
					void * outVoxels,							// where to place the data
					const VLIVolumeRange	 & inVolumeRange,	// range of volume to unload
					const VLIFieldDescriptor & inVolumeField,	// description of field to unload
					VLISource inSource							// Do we want the source or the buffer?
				) const;

	// Other queries

	VLIbool		IsLoaded (void					// Return VLItrue if volume is loaded on a board
				) const;

	VLIAccessType GetAccessControl (void		// Return current access control
				) const;

	VLIStatus	Resize (						// Resize a sourceless volume
					unsigned int inNewSizeX,	// new size for X
					unsigned int inNewSizeY,	// new size for Y
					unsigned int inNewSizeZ,	// new size for Z
					VLIbool inResizeBuffer	// resize buffer also?
				);

	VLIStatus	Resize (							// Resize a volume
					const VLIVolumeRange & inNewRange,	// new addressing range for this volume
					VLIbool inResizeBuffer			// resize buffer also?
				);


	// Buffer routines

	VLIStatus	CreateBuffer (
					VLILocation inLocation		// Where to create buffer
				);

	VLIStatus	CreateBuffer (
					VLILocation inLocation,		// Where to create buffer
					unsigned int inSizeX,		// X size of buffer
					unsigned int inSizeY,		// Y size of buffer
					unsigned int inSizeZ		// Z size of buffer
				);

	VLIStatus	CreateBuffer (						// Create a buffer with the given range
					VLILocation inLocation, 		// Where to create buffer
					const VLIVolumeRange & inRange	// Size and offset for buffer
				);

	VLIBufferID	GetBufferID (void				// Return buffer ID or kVLINoBuffer
				) const;

	void		GetBufferSize (					// Return buffer size; all 0 if no buffer attached
					unsigned int & outSizeX,	// RETURNED size in X
					unsigned int & outSizeY,	// RETURNED size in Y
					unsigned int & outSizeZ		// RETURNED size in Z
				) const;

	unsigned int GetBufferSizeX (void			// Return buffer size in X; 0 if no buffer attached
				) const;

	unsigned int GetBufferSizeY (void			// Return buffer size in Y; 0 if no buffer attached
				) const;

	unsigned int GetBufferSizeZ (void			// Return buffer size in Z; 0 if no buffer attached
				) const;

	VLIVolumeRange	GetBufferRange (void		// Return buffer addressing range; all 0 if no buffer attached
				) const;


	VLIStatus	AttachBuffer (					// Attach this volume to the specified buffer
					VLIBufferID inBufferID		// Buffer ID
				);
	
	VLIStatus	ReleaseBuffer (void				// Release any buffer that may be attached
				);

	VLIStatus	SetBufferPermission (			// Set permission for other processes
					VLIPermission inBufferPermission
				);

	VLIPermission	GetBufferPermission (void	// Return permission
				) const;

	VLILocation	GetBufferLocation (void			// Return location of buffer
				) const;							// or kVLINoBuffer

	VLIStatus	ResizeBuffer (					// Change the size of the buffer
					unsigned int inNewSizeX,	// new size for X
					unsigned int inNewSizeY,	// new size for Y
					unsigned int inNewSizeZ		// new size for Z
				);

	VLIStatus	ResizeBuffer (						// Change the buffer addressing range (offset mode)
					const VLIVolumeRange & inNewRange		// new addressing range
				);

	VLIStatus	SetBufferWrap (						// Set addressing mode to kVLIWrapAddress and set the modulus values
					int inModulusX,					// modulus for X (must be a power of 2)
					int inModulusY,					// modulus for Y (must be a power of 2)
					int inModulusZ					// modulus for Z (must be a power of 2)
				);

	VLIStatus	SetBufferOffset (					// Set addressing mode to kVLIOffsetAddress and set the offset values
					int inOffsetX,					// offset for X (must be even)
					int inOffsetY,					// offset for Y (must be even)
					int inOffsetZ					// offset for Z (must be even)
				);

	void		GetBufferAddressParameters (		// Return the addressing parameters
					VLIAddressMode & outMode,		// RETURNED kVLIOffsetAddress or kVLIWrapAddress
					int &outAddressParameterX, 		// RETURNED offset or modulus for X
					int &outAddressParameterY,		// RETURNED offset or modulus for Y
					int &outAddressParameterZ		// RETURNED offset or modulus for Z
				) const;

	VLIStatus	SetBufferAddressParameters (		// Set the addressing parameters
					VLIAddressMode inMode,			// kVLIOffsetAddress or kVLIWrapAddress
					int inAddressParameterX, 		// offset or modulus for X
					int inAddressParameterY,		// offset or modulus for Y
					int inAddressParameterZ			// offset or modulus for Z
				);

	VLIAddressMode	GetBufferAddressMode (void		// Return kVLIOffsetAddress or kVLIWrapAddress
				) const;

	int			GetBufferAddressParameterX (		// Return the offset/modulus X field
				) const;

	int			GetBufferAddressParameterY (		// Return the offset/modulus Y field
				) const;
	
	int			GetBufferAddressParameterZ (		// Return the offset/modulus Z field
				) const;

	VLIStatus	SetTarget (						// Select source or buffer as target for updates
					VLITarget inNewTarget		// Do we want the source or the buffer?
				);

	VLITarget	GetTarget (void					// Return current target
				) const;

	// VLI 3.x rendering routines

	VLIStatus	Render (							// Render a volume to a color image
					const VLIContext * inContext,	// context (state)
					VLIImageBuffer * inOutColor0,	// color image 0 INPUT (FRONT) and/or OUTPUT
					VLIDepthBuffer * inOutDepth0,	// depth image 0 INPUT (NEAR)  and/or OUTPUT
					VLIImageBuffer * inOutColor1,	// color image 1 INPUT (BACK)  and/or OUTPUT
					VLIDepthBuffer * inOutDepth1	// depth image 1 INPUT (FAR)   and/or OUTPUT
					);

	VLISyncEvent StartRender (						// Start to render a volume to a color image
					const VLIContext * inContext,	// context (state)
					VLIImageBuffer * inOutColor0,	// color image 0 INPUT (FRONT) and/or OUTPUT
					VLIDepthBuffer * inOutDepth0,	// depth image 0 INPUT (NEAR)  and/or OUTPUT
					VLIImageBuffer * inOutColor1,	// color image 1 INPUT (BACK)  and/or OUTPUT
					VLIDepthBuffer * inOutDepth1	// depth image 1 INPUT (FAR)   and/or OUTPUT
					);
	
	VLIStatus	RenderMPR (
					const VLIContext * inContext,
					double inNegativeDistance,
					int inQuality,
					MPRMode inMode,
					VLIImageBuffer * inOutColor0
				);

	VLISyncEvent StartRenderMPR (
					const VLIContext * inContext,
					double inNegativeDistance,
					int inQuality,
					MPRMode inMode,
					VLIImageBuffer * inOutColor0
				);

	VLISyncEvent DoStartRenderAndMPR (					// Start to render a volume to a color image
					const VLIContext *	inContext,		// context (state)
					VLIImageBuffer *	inOutColor0,	// color image 0 INPUT (FRONT) and/or OUTPUT
					VLIDepthBuffer *	inOutDepth0,	// depth image 0 INPUT (NEAR)  and/or OUTPUT
					VLIImageBuffer *	inOutColor1,	// color image 1 INPUT (BACK)  and/or OUTPUT
					VLIDepthBuffer *	inOutDepth1,	// depth image 1 INPUT (FAR)   and/or OUTPUT
					double				inNegativeDistance = 0,
					int					inQuality = 1,
					MPRMode				inMode = kMPRAlpha,
					VLIbool				inIsMPRRender = VLIfalse
				);

	// Added for 3.1

	VLIStatus	ResampleBuffer (
					VLIVolume * pDestination,
					const VLIVolumeRange & inSourceRange,
					const VLIVolumeRange & inDestinationRange,
					const VLIClassifier & inClassifier
				);

	VLISyncEvent StartResampleBuffer (
									VLIVolume * pDestination,
									const VLIVolumeRange & inSourceRange,
									const VLIVolumeRange & inDestinationRange,
									const VLIClassifier &inClassifier
									);
	

	// Mipmap support

	VLIStatus		SetMipmapAutoGenerate ( 			// Enable or disable auto mipmap level generation
						VLIbool inEnabled				// VLItrue for enabled, VLIfalse for disabled
					);
	
	VLIbool 		GetMipmapAutoGenerate (void) const;	// Return VLItrue if auto generate enabled

	VLIStatus		SetMipmapMinDimension (				// Set the minimum size automatic mode will create
						int inMinDimension
					);

	int 			GetMipmapMinDimension (void) const;	// Return the minimum size

	VLIStatus		SetMipmapShrinkFactors (			// Set shrink factors
						double inShrinkX,				// X dimension shrink factor: 0.5 to 0.90
						double inShrinkY,				// Y dimension shrink factor: 0.5 to 0.90
						double inShrinkZ				// Z dimension shrink factor: 0.5 to 0.90
					);

	void			GetMipmapShrinkFactors (			// Return shrink factors
						double & outShrinkX,			// RETURNED X dimension shrink factor
						double & outShrinkY,			// RETURNED Y dimension shrink factor
						double & outShrinkZ 			// RETURNED Z dimension shrink factor
					) const;
	// Note -- normally we would also add GetMipmapShrinkFactorX(void), etc, but
	// we also want to limit the number of methods added.

	VLIStatus		SetMipmapInterpolationMode (		// Set interpolation mode for a field
						VLIFieldNumber inField, 		// Field number: kVLIField0 through 3
						VLIInterpolationMode inMode 	// mode: kVLINearestNeighbor or kVLITrilinear
					);

	VLIInterpolationMode GetMipmapInterpolationMode (	// Return interpolation mode for a field
							VLIFieldNumber inField		// Field number: kVLIField0 through 3
						 ) const;

	VLIStatus		GenerateMipmapLevel (				// Explicitly generate a mipmap level
						int inLevelToGenerate,			// Level to generate, 1 to N - 1
						int inSourceLevel = -1, 		// Level to use as source: 0 to inLevelGenerate - 1;
														// -1 means use inLevelToGenerate - 1.
						double inShrinkX = 0.0, 		// X dimension Shrink factor: 0.5 to 0.90
						double inShrinkY = 0.0, 		// Y dimension Shrink factor: 0.5 to 0.90
						double inShrinkZ = 0.0			// Z dimension Shrink factor: 0.5 to 0.90
					);

	VLISyncEvent	StartGenerateMipmapLevel (			// Explicitly generate a mipmap level
						int inLevelToGenerate,			// Level to generate, 1 to N - 1
						int inSourceLevel = -1, 		// Level to use as source: 0 to inLevelGenerate - 1;
														// -1 means use inLevelToGenerate - 1.
						double inShrinkX = 0.0, 		// X dimension Shrink factor: 0.5 to 0.90
						double inShrinkY = 0.0, 		// Y dimension Shrink factor: 0.5 to 0.90
						double inShrinkZ = 0.0			// Z dimension Shrink factor: 0.5 to 0.90
					);

	VLIStatus		SetMipmapRange (					// Set range of mipmap levels to use when rendering
						int inMinLevel, 				// first mipmap level to use: 0 to N - 1
						int inMaxLevel					// last mipmap level to use: inMinLevel to N - 1
					);
	
	void			GetMipmapRange (					// Return mipmap level range
						int & outMinLevel,				// RETURNED first mipmap level to use
						int & outMaxLevel				// RETURNED last mipmap level to use
					) const;

	// The single argument form of ChooseMipmapLevel uses the current MipmapRange
	int 			ChooseMipmapLevel ( 				// Return the first level that will render,
														// or -1 to indicate none will render
						const VLIContext * inContext	// Using this context (and camera)
					) const;

	int 			ChooseMipmapLevel ( 				// Return the first level that will render,
														// or -1 to indicate none will render
						const VLIContext * inContext,	// Using this context (and camera)
						int inMinLevel, 				// first mipmap level to test
						int inMaxLevel = 9999			// last mipmap level to test
					) const;

	// Space leaping -- 3.2

	VLIStatus		SetSpaceLeapingParameters (
						SpaceLeapingMode inMode,
						double inThresholdRed	= -1,
						double inThresholdGreen = -1,
						double inThresholdBlue	= -1,
						double inThresholdAlpha = -1
					);

	void			GetSpaceLeapingParameters (
						SpaceLeapingMode & outMode,
						double & outThresholdRed,
						double & outThresholdGreen,
						double & outThresholdBlue,
						double & outThresholdAlpha
					) const;

	// Render to volume -- 3.3

	VLIStatus		RenderToVolume (					// ASYNCHRONOUS Start to peform a volume-to-volume render
						const VLIContext * inContext,	// Context (state) to use (INPUT)
						VLIVolume * inOutVolume,		// volume OUTPUT
						RenderToVolumeMode inMode		// special rendering mode
					);

	VLISyncEvent	StartRenderToVolume (				// ASYNCHRONOUS Start to peform a volume-to-volume render
						const VLIContext * inContext,	// Context (state) to use (INPUT)
						VLIVolume * inOutVolume,		// volume OUTPUT
						RenderToVolumeMode inMode		// special rendering mode
					);

	// Mipmap level access -- 3.3

	VLIVolume *		GetMipmapLevel (					// Return VLIVolume object for requested mipmap level
								int inLevel							// mipmap level, 0 to maximum
							);

	VLIStatus		CreateMipmapLevel (						// Create mipmap level without generating data
								int inLevel,						// mipmap level, 0 to maximum
								VLILocation inLocation,				// where to create this mipmap level
								VLIVolumeRange inRange				// volume range to create
							);

	// Specific to multiboard phase 1

	static VLIVolume * Create (
						VLIVolume*			inTopVolume,	// Original volume
						VLIVolumeSource*	inVolumeSource, // Volume source
						int 				inNumberSubvolumes
					);

	int				GetNumberOfVolumes (void) { return m_numberSubVolumes; }



private:

	~VLIMultiboardVolumePhase1 ();
	VLIMultiboardVolumePhase1 (
					VLIVolume *		inTopVolume,	// Original volume
					VLIVolumeSource * inVolumeSource,	// Volume source
					int				inNumberSubvolumes
					);

	class SubvolumeInfo
	{
	public:
		SubvolumeInfo (void)
			: m_vol (0), m_range(), m_location (kVLINoBufferAttached), m_locked (false)
		{}


		~SubvolumeInfo (void)
		{
			if (m_vol) m_vol->Release();
		}

		void SetVolume (VLIVolume * inVol)
		{
			if (inVol) inVol->AddRef();
			if (m_vol) m_vol->Release();
			m_vol = inVol;
		}

		VLIVolume * GetVolume(void) {return m_vol;}
		VLIVolume * operator -> (void) { return m_vol; }
		const VLIVolume * operator -> (void) const { return m_vol; }


		VLIVolumeRange		m_range;
		VLILocation			m_location;	// Board on which the subvolume is located
		VLIbool				m_locked;

	private:
		SubvolumeInfo (const SubvolumeInfo & inCopy);
		SubvolumeInfo & operator = (const SubvolumeInfo & inSource);

		VLIVolume*			m_vol;
	};

	// Private data
	// ------------
	VLIVolume *				m_baseVolume;
	VLIMipmapVolume *		m_baseMipmapVolume;		// Base volume as a mipmap, if it is
	int						m_numberRealVolumes;	// The real # of volumes
	int						m_numberSubVolumes;		// The # of volumes to render
	mutable int				m_lastUnloadBoard;		// last board we used for unload

	VLIVolumeSource *		m_volumeSource;
	int						m_voxelSize;

	// Array, allocated at construction time
	SubvolumeInfo *			m_subvolume;

	VLISerialNumber			m_volumeSerial;
	VLISerialNumber			m_stateSerial;

	enum MapType
	{
		eSimpleMap,
		eSimulatedMap,
		eNotImplementedMap
	};
	VLIbool				m_mapped;				// true while source is mapped. buffer cannot be mapped.
	VLIVolumeRange		m_mappedVolumeRange;
	VLISource			m_mappedSource;
	char *				m_tmpBuff;
	VLIAccessType		m_mappedAccess;
	MapType				m_mapType;
	int					m_numberMappedVolumes;	

};

#define	INCREMENT_VOLUME_SERIAL	++m_volumeSerial
#define INCREMENT_STATE_SERIAL	++m_stateSerial


#endif // VLIMULTIBOARDVOLUMEPHASE1_H_

