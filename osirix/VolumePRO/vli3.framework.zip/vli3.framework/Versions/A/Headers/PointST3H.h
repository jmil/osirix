/*
 * $Id: PointST3H.h,v 1.4 2002/10/23 15:38:06 vesper Exp $
 *
 *    Copyright 2002 by Real Time Visualization, TeraRecon, Inc.
 *    All Rights Reserved.
 *
 */  
// PointST3H.h - Point Object with x,y,z,h, and s,t values
#ifndef POINTST3H_H
#define POINTST3H_H

#ifdef NEVER
// Forward Declaration of Class BoxST3H, since both
//  PointST3H and BoxST3H refer to each other...!!!
class BoxST3H;
#endif

// Declaration of PointST3H Class
class PointST3H {
public:

  // Constructors
  PointST3H ();
  PointST3H (double inX, double inY, double inZ, double inW,
             double inS, double inT);

  PointST3H (double inX, double inY, double inZ, double inS, double inT);

  PointST3H (double inX, double inY, double inZ);


  // Operate on the Point

  // Scale the S,T components only
  // <<<Define a Vect3, and use it instead of Point3D>>>
  void ScaleST (const Point3D &inSampMult);

  // Transform
  void Transform (const Mat44 &inMat);

  // DivideW
  void DivideW (void);

  // Vector operations - such as difference between two points
  //  <<<Implement a new VectorST3H Class, or VectorST3D>>>

  // Vector difference between two points, returned as a Point
  PointST3H operator -( const PointST3H &) const ;

  // Avoid using BoxST3H, since this Class referinces PointST3H
  // <<<Check into this later, can we fix this???>>>
#ifdef NEVER

  // Get initial surrounding XYZ Box, from this Point
  BoxST3H GetBoxXYZ (void);

  // Updates surrounding XYZ Box, given an Initial XYZ Box
  void UpdBoxXYZ (BoxST3H &inBox);
#endif

  // Get/Set
  void GetXYZWST (double &outX, double &outY, double &outZ, double &outW, double &outS, double &outT) const ;
  void GetXYZST  (double &outX, double &outY, double &outZ, double &outS, double &outT) const ;
  void GetXYZW   (double &outX, double &outY, double &outZ, double &outW) const ;
  void GetXYZ    (double &outX, double &outY, double &outZ) const ;
  void GetST     (double &outS, double &outT) const ;
  double GetX (void) const;
  double GetY (void) const;
  double GetZ (void) const;
  double GetW (void) const;
  double GetS (void) const;
  double GetT (void) const;

  void SetXYZWST (double &inX, double &inY, double &inZ, double &inW, double &inS, double &inT);
  void SetXYZST  (double &inX, double &inY, double &inZ, double &inS, double &inT);
  void SetXYZW   (double &inX, double &inY, double &inZ, double &inW);
  void SetXYZ    (double &inX, double &inY, double &inZ);
  void SetST     (double &inS, double &inT);
  void SetX (double &inX);
  void SetY (double &inY);
  void SetZ (double &inZ);
  void SetW (double &inH);
  void SetS (double &inS);
  void SetT (double &inT);

  // Print
  // Print the Point
  void Print (void) const ;

  // The following is temporarily put in "Public" to save time

  // 3D Vertex with homogenous component, and s,t component
  // double m_x, m_y, m_z, m_w, m_s, m_t;
  double x, y, z, w, s, t;

private:

};
#endif
