/*
 * $Id: ClipSampleSpace.h,v 1.7 2003/01/09 18:42:58 ford Exp $
 *
 *    Copyright 2002 by Real Time Visualization, TeraRecon, Inc.
 *    All Rights Reserved.
 *
 */  
// ClipSampleSpace - Clip version of SampleSpace Object
//  Uses the ClipCubeST3H Object
#ifndef CLIPSAMPLESPACE_H
#define CLIPSAMPLESPACE_H


class ClipSampleSpace: public SampleSpace {
public:

  // Constructors

  // Includes Volume Dimensions, Matrix, and initializes Volume Cube
  ClipSampleSpace (Point3D &inVolMin, Point3D &inVolMax, Mat44 &inPmvMat, Mat44 &inInvPmvMat,
				   Clipper3H &inClipper);

  // Operate on the ClipSampleSpace

  // Calculate the Viewpoint from the Inverse Transformation Matrix
  PointST3H CalcViewpoint (void);

  // Get, Set

  // Set the Current Viewpoint into the ClipCube Structure
  void SetViewpoint (PointST3H &inViewpoint);

  // Get the Clip Distance, considering only one Side of the Volume Cube
  double GetClipDist (int inNearSide, double inMinDist);

  // Get the Clip Distance, considering all 6 sides to process
  double GetClipDist (double inMinDist);

  // Get the far Clip Distance, considering all 6 sides to process
  double GetFarClipDist (double inMaxDist);

  // Update a Dimension of the Internal ClipCube
  //   Return whether anything's visible
  bool SetClipCube (int inNearSide, double inMinDist, double inMaxDist);

  // Get Near DualHyperbolic
  DualHyper GetNearHyper (int inNearSide);

  // Get Far DualHyperbolic
  DualHyper GetFarHyper (int inNearSide);

  // Get Clipped ST Box
  BoxST3H GetClipSTBox  (void);

  void GetClipSTBox  (BoxST3H &OutSTBox);

  // Old version of Get Clipped ST Box
  BoxST3H OldGetClipSTBox (void);

  // Get the ClipCube (two Points)
  void GetClipCube (PointST3H &outClipMin, PointST3H &outClipMax);

  // Get the ClipCube Dimensions
  PointST3H GetClipMin (void);
  PointST3H GetClipMax (void);

private:

  // Calculate Sample Space Representative ClipCube
  void CalcSampSpaceClipCube (void);

  // ClipCubeST3H is a cube with functionality to support "pushing" a
  //  side of the Cube back away from the Viewer a certain distance.
  // Support is given to determine this distance.  A modified technique
  //  is used to represent the Cube to aid this "push back" operation
  ClipCubeST3H mClipCube;

  // A Homogeneous coordinates 3-Space Clipper Object.  This can clip
  //  polygons to lie within the View Frustum (clipping against left,
  //  right, top, and bottom planes).
  Clipper3H &mClipper3H;

  // Transformed Near and Far Polygons (used in GetClipSTBox)
  PolygonST3H mTranNearPoly, mTranFarPoly;

  // Clipped Near and Far Polygons
  PolygonST3H mNearClipPoly, mFarClipPoly;

  // Status of the Clipped Near and Far Polygons (valid = non null)
  bool mNearValid, mFarValid;
};
#endif
