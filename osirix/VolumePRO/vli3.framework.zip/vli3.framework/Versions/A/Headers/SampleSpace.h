/*
 * $Id: SampleSpace.h,v 1.5 2004/04/13 20:36:34 ford Exp $
 *
 *    Copyright 2002 by Real Time Visualization, TeraRecon, Inc.
 *    All Rights Reserved.
 *
 */  
// SampleSpace.h - Object for Sample Space related calculations
#ifndef SAMPLESPACE_H
#define SAMPLESPACE_H


// Sample Space related calculation Object Definition
class SampleSpace {
public:

  // Constructors
  // No argument version
  SampleSpace (void);

  // Includes Volume Dimensions, Matrix, and initializes Volume Cube
  SampleSpace (Point3D &inVolMin, Point3D &inVolMax, Mat44 &inPmvMat, Mat44 &inInvPmvMat);


  // Operate on SampleSpace

  // Get/Set

  // Set Volume Dimensions
  void SetVolDimen (Point3D &inVolMin, Point3D &inVolMax);

  // Set Projection-Model-View Matrix
  void SetPmvMat (Mat44 &inPmvMat);

  // Set Inverse Projection-Model-View Matrix
  void SetInvPmvMat (Mat44 &inInvPmvMat);

  // Set Sample Space, given an input Orientation (Vector)
  // An alternative to the above technique
  bool SetSpaceNumb (Vector3D &inVect3D);

  // Get Near DualHyperbolic
  DualHyper GetNearHyper (void);

  void GetNearHyper (DualHyper &OutNearHyper);

  // Get Far DualHyperbolic
  DualHyper GetFarHyper (void);

  void GetFarHyper (DualHyper &OutFarHyper);

  // Get Full ST Box
  BoxST3H GetFullSTBox (void);

  void GetFullSTBox (BoxST3H &OutSTBox);

protected:

  // Calculate Sample Space Representative Cube
  void CalcSampSpaceCube (void);

  // Verbose Display Control
  int mVerbose;

  // Sample Space Working Storage
  Point3D mVolMin;
  Point3D mVolMax;

  // Projection-Model-View Matrix
  Mat44 mPmvMat;

  // Inverse of Projection-Model-View Matrix
  Mat44 mInvPmvMat;

  // Sample Space Representative Cube
  CubeST3H mVolCube;

  // Vector used to control which sides of Volume Cube is visible
  Vector3D mViewVect;

  // Current Near Side, Far Side
  int mNearSide, mFarSide;

  // Near and Far Polygons
  PolygonST3H mNearPoly, mFarPoly;

  // Next Nearest, and Last Near Polygon
  PolygonST3H mN1Poly, mN2Poly;

  // Near and Far Dual Hyperbolic Functions
  DualHyper mNearHyper, mFarHyper;

private:

};
#endif
