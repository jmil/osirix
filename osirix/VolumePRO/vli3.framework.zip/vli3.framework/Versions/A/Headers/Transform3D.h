/*
 * $Id: Transform3D.h,v 1.3 2002/10/14 21:03:39 vesper Exp $
 *
 *    Copyright 2002 by Real Time Visualization, TeraRecon, Inc.
 *    All Rights Reserved.
 *
 */  
// Transform3D.h
#ifndef TRANSFORM3D_H
#define TRANSFORM3D_H

#define  PI      3.1415926535
#define  EPSILON 0.0001
#define  EPS     0.00001

#define  ROUND0(x)  ((x) > (-EPS) && (x) < (EPS)) ? 0.0f : x

// Put the following here because we're looking for a problem.
// Somewhere "Transform3D.h" is included, but not "PSTtypes.h"

// Switch to Double instead of Float for Matrix and Vector operations
#define MAT_VECT_DOUBLE 1

// Allow the use of Float or Double
#if MAT_VECT_DOUBLE
#define FL_DB double
#else
#define FL_DB float
#endif

// Vector, 3D Transformation Matrix structures

//  x'    a  e  i  m     x
//  y' =  b  f  j  n  *  y
//  z'    c  g  k  o     z
//  w'    d  h  l  p     w

// Transformation Matrix
typedef struct {
  FL_DB a, e, i, m;
  FL_DB b, f, j, n;
  FL_DB c, g, k, o;
  FL_DB d, h, l, p;
} Mat44;

// Three component Vectors
typedef struct { FL_DB x, y, z; } Vect3;
typedef struct { int   x, y, z; } Vect3int;

// Four component Vectors
typedef struct { FL_DB x, y, z, w; } Vect4;
typedef struct { int   x, y, z, w; } Vect4int;

// Function Prototypes for Vect4, and Mat44 routines
extern void MatInit      (Mat44 *mat);
extern void MatRound0    (Mat44 *mat);
extern void MatTrans     (Mat44 *mat, FL_DB tx, FL_DB ty, FL_DB tz);
extern void MatScale     (Mat44 *mat, FL_DB sx, FL_DB sy, FL_DB sz);
extern void MatRotate    (Mat44 *mat, char axis, FL_DB theta);
extern void MatMultiply  (Mat44 *mat3, Mat44 *mat1, Mat44 *mat2);
extern void MatMultRound (Mat44 *mat3, Mat44 *mat1, Mat44 *mat2);
extern void MatCopy      (Mat44 *mat2, Mat44 *mat1);
extern int  MatInvert    (Mat44 *mat2, Mat44 *mat1);
extern int  GaussElim    (double *a, double *x, long n);

extern void MatPrint (Mat44 *mat);

extern void VectNormalize (Vect4 *vect);
extern void VectHomNorm   (Vect4 *vect);
extern void VectSubtract  (Vect4 *vect, Vect4 *vect1);
extern void VectAdd       (Vect4 *vect, Vect4 *vect1);
extern void VectRound0    (Vect4 *vect);
extern void VectMultiply  (Vect4 *vect2, Mat44 *mat, Vect4 *vect1);
extern void VectMultRound (Vect4 *vect2, Mat44 *mat, Vect4 *vect1);
extern void TransVectHom  (Vect4 *vect2, Mat44 *mat, Vect4 *vect1);

#endif
