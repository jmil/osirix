/*
 *	$Id: vlidepthbuffer.h,v 1.3 2004/04/19 21:11:15 vesper Exp $
 *
 *    Copyright 2004 by Real Time Visualization, TeraRecon, Inc.
 *    All Rights Reserved.
 *
 * Omnipotent depth buffers
 */


#ifndef VLIDEPTHBUFFER_H_
#define VLIDEPTHBUFFER_H_

#include "vli.h"


class VLIOmniDepthBuffer : public VLIDepthBuffer
{
public:

	typedef VLIuint32		DepthValue;


	// Location and size access

	virtual VLILocation 	GetLocation (void					// Return location of buffer
							) const;

	virtual void			GetSize (							// Return the size of the depth buffer
								unsigned int& outWidth, 		// RETURNED width in depth elements
								unsigned int& outHeight 		// RETURNED height in depth elements
							) const;

	virtual unsigned int	GetWidth (void						// Return the width of the depth buffer
							) const;

	virtual unsigned int	GetHeight (void 					// Return the height of the depth buffer
							) const;

	// Updating the data in the depth buffer

	virtual VLIStatus		Update (							// Update a depth buffer with new values
								const void * inData,			// location of input data
								const VLIImageRange & inRange,	// range of depth buffer to update
								unsigned int inWidth,		// width of application buffer (0 means use range)
								DepthFormat inFormat	// format of this data
							);

	virtual VLISyncEvent	StartUpdate (						// ASYNCHRONOUS Start to update a depth buffer with new values
								const void * inData,			// location of input data
								const VLIImageRange & inRange,	// range of depth buffer to update
								unsigned int inWidth,		// width of application buffer (0 means use range)
								DepthFormat inFormat	// format of this data
							);

	virtual VLIStatus		Clear ( 							// Clear a range of this buffer
								const VLIImageRange & inRange,	// range to clear
								VLIuint32 inValue				// clear value
							);

	// Reading the data in the depth buffer

	virtual VLIStatus		Unload (							// Unload a depth buffer to application storage
								void * outData, 				// RETURNED depth data
								const VLIImageRange & inRange,	// range of depth buffer to return
								unsigned int inWidth,		// width of application buffer (0 means use range)
								DepthFormat inFormat	// format to be used for this data
							) const;

	virtual VLISyncEvent	StartUnload (						// ASYNCHRONOUS Start to unload a depth buffer to application storage
								void * outData, 				// RETURNED depth data
								const VLIImageRange & inRange,	// range of depth buffer to return
								unsigned int inWidth,		// width of application buffer (0 means use range)
								DepthFormat inFormat	// format to be used for this data
							) const;

	// Accessing the data in the image

	virtual VLIStatus		Map (								// Map a 32-bit depth buffer into application memory space
								VLIuint32 *& outData,			// RETURNED pointer to depth buffer data
								const VLIImageRange & inRange,	// range of depth buffer to map in
								unsigned int & outWidth,		// RETURNED width of application buffer
								DepthFormat inFormat	// format to be used for this data
							);

	virtual VLIStatus		Map (								// Map a depth buffer into application memory space
								void *& outData,				// RETURNED pointer to depth buffer data
								const VLIImageRange & inRange,	// range of depth buffer to map in
								unsigned int & outWidth,		// RETURNED width of application buffer
								DepthFormat inFormat	// format to be used for this data
							);

	virtual VLIStatus		Unmap ( 							// Release a depth buffer mapping
								void * inData					// mapped depth pointer to be released
							);

	// Addressing modes

	virtual VLIStatus		SetOffset ( 						// Set addressing mode to kVLIOffsetAddress and set the offset values
								int inOffsetX,					// Offset for X (must be even)
								int inOffsetY					// Offset for Y (must be even)
							);

	virtual VLIStatus		SetWrap (							// Set addressing mode to kVLIWrapAddress and set the modulus values
								int inWrapX,					// Wrap modulus for X (must be a power of 2)
								int inWrapY 					// Wrap modulus for Y (must be a power of 2)
							);

	virtual VLIStatus		SetAddressParameters (				// Set the addressing parameters
								VLIAddressMode inMode,			// kVLIOffsetAddress or kVLIWrapAddress
								int inAddressParameterX,		// Offset or wrap modulus for X
								int inAddressParameterY 		// Offset or wrap modulus for Y
							);

	virtual void			GetAddressParameters (				// Return the addressing parameters
								VLIAddressMode &outMode,		// RETURNED kVLIOffsetAddress or kVLIWrapAddress
								int& outAddressParameterX,		// RETURNED Offset or wrap modulus for X
								int& outAddressParameterY		// RETURNED Offset or wrap modulus for Y
							) const;

	virtual int 			GetAddressParameterX (void) const;	// Return buffer offset or wrap X value

	virtual int 			GetAddressParameterY (void) const;	// Return buffer offset or wrap Y value

	virtual VLIAddressMode	GetAddressMode (void) const;	// Return kVLIOffsetAddress or kVLIWrapAddress

	// Ranges of interest, input and output

	virtual VLIImageRange	GetInputLimits (void				// Return the input limits (initial range)
							) const;

	virtual VLIStatus		SetInputLimits (					// Set the input limits (initial range)
								const VLIImageRange & inLimits	// input limits
							);

	virtual VLIImageRange	GetOutputLimits (void				// Return the output limits (view frustum?)
							) const;

	virtual VLIStatus		SetOutputLimits (					// Set the output limits (view frustum?)
								const VLIImageRange & inLimits	// output limits
							);

	// The border value is used outside the input limits

	virtual VLIuint32		GetBorderValue (void				// Return the border value (VLIuint32)
							) const;

	virtual VLIStatus		SetBorderValue (					// Set the border value (VLIuint32)
								VLIuint32 inBorderValue 		// border value (kVLIDepth24Low)
							);
    virtual VLIStatus       SetMigrationMode (                  // Set migration mode
                                VLIMigrationMode inMode         // mode
                            );

    virtual VLIMigrationMode    GetMigrationMode (              // Return migration mode
                            ) const;

    virtual VLIStatus       Migrate (                           // Migrate buffer to particular location (board)
                                VLILocation inLocation          // board
                            );

    virtual VLISyncEvent    StartMigrate (                      // ASYNCHRONOUS Start to migrate buffer to particular location (board)
                                VLILocation inLocation          // board
                            );

	// Object factory

	static VLIOmniDepthBuffer*	Create (							// Create a VLIOmniDepthBuffer object
								VLILocation inLocation, 		// location -- cannot be kVLIAnyBoard
								unsigned int inWidth,			// width in depth elements (32 bits each)
								unsigned int inHeight,			// height in depth elements
								int inNumberSubvolumes = 0
							);

	VLISerialNumber	GetLastVolumeRendered (				// Return ID of last volume rendered to this buffer
							) const;


	// Public, but not part of the VLIDepthBuffer interface

	int GetNumberBuffers (void) const { return m_numberSubBuffers; }

	VLIDepthBufferInternal * GetDepthBuffer (void)
	{
		VLI_ASSERT (m_numberSubBuffers == 1);
		return m_subBuffers.GetBuffer (0);
	}

	VLIDepthBufferInternal * GetSubDepthBuffer (int b)
	{
		VLI_ASSERT (b >= 0 && b < m_numberSubBuffers);
		return m_subBuffers.GetBuffer(b);
	}

	VLIImageRange GetSubImageRange (int b)
	{
		VLI_ASSERT (b >= 0 && b < m_numberSubBuffers);
		return m_subBuffers.Range(b);
	}

	VLISyncEvent DoStartMigrate (VLILocation inDestination, const VLIImageRange & copyRange);

	void				SetLastVolumeRendered (VLISerialNumber inVolume) { m_lastVolume = inVolume; }

private:
	friend VLIDepthBuffer* VLIDepthBuffer::Create (
								VLILocation					m_location,				// Where to create buffer (must be specific)
								unsigned int				inWidth,				// width in pixels
								unsigned int				inHeight				// height in pixels
							);

	VLIOmniDepthBuffer (
							VLILocation inLocation, 		// location -- cannot be kVLIAnyBoard
							unsigned int inWidth,			// width in pixels
							unsigned int inHeight			// height in pixels
							);

	virtual ~VLIOmniDepthBuffer (void);

	VLIStatus CreateSubBuffers (VLILocation inLocation, int & outNumberCreated);
	void ReleaseSubBuffers (void);

	// Data

	class SubBufferInfo
	{
	public:
		SubBufferInfo (void)
		{
			for (int b = 0; b < kMultiboardMaxVolumes; ++b)
			{
				m_buffer[b] = NULL;
			}
		}

		SubBufferInfo (const SubBufferInfo & inCopy);

		~SubBufferInfo (void)
		{
			ReleaseAll ();
		}

		void Set (int b, VLIDepthBufferInternal * inBuffer, const VLIImageRange & inRange)
		{
			if (inBuffer) inBuffer->AddRef();
			if (m_buffer[b]) m_buffer[b]->Release();
			m_buffer[b] = inBuffer;
			m_range[b] = inRange;
		}

		void Release (int b)
		{
			if (m_buffer[b]) 
			{
				m_buffer[b]->Release();
				m_buffer[b] = NULL;
			}
		}

		void ReleaseAll (void)
		{
			for (int b = 0; b < kMultiboardMaxVolumes; ++b)
			{
				if (m_buffer[b]) 
				{
					m_buffer[b]->Release();
					m_buffer[b] = NULL;
				}
			}
		}

		VLIDepthBufferInternal *	GetBuffer(int b) { return m_buffer[b]; }
		const VLIDepthBufferInternal *	GetBuffer(int b) const { return m_buffer[b]; }
		VLIImageRange &				Range (int b) { return m_range[b]; }
		const VLIImageRange &		Range (int b) const { return m_range[b]; }

	private:
		VLIDepthBufferInternal *	m_buffer[kMultiboardMaxVolumes];
		VLIImageRange				m_range[kMultiboardMaxVolumes];
	};

	VLILocation			m_location;							// location of this buffer
	VLIImageRange		m_wholeRange;
	unsigned int		m_pixelSize;						// size of pixel in bits (16, 32, or 64)
	VLIImageRange		m_inputLimits;						// input limits (initial range)
	VLIImageRange		m_outputLimits;						// output limits (view frustum?)
	VLIAddressMode		m_addressMode;						// wrap mode flag
	int					m_addressParameterX;				// offset or modulus for X
	int					m_addressParameterY;				// offset or modulus for Y
	DepthValue			m_borderValue;						// border depth value
	VLIMigrationMode	m_migrationMode;					// can we migrate to another board?

	int					m_numberSubBuffers;
	SubBufferInfo		m_subBuffers;
	DepthValue *		m_systemBuffer;
	VLISyncEvent		m_systemBufferEvent;

	void *				m_mapAddress;
	DepthValue *		m_mapBuffer;						// Used for MB1 and MB2 map buffer
	VLIImageRange		m_mapRange;

	VLISerialNumber		m_lastVolume;

};

#endif // VLIDEPTHBUFFER_H_
