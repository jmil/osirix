/*
 * $Id: PSTtypes.h,v 1.4 2002/10/14 21:03:37 vesper Exp $
 *
 *    Copyright 2002 by Real Time Visualization, TeraRecon, Inc.
 *    All Rights Reserved.
 *
 */  
// PSTtypes.h - Basic Types for the Perspective Sampling Testbed 
#ifndef PSTTYPES_H
#define PSTTYPES_H

// VLI interface
#include "vli.h"
extern void	VLIOutputMessage (const char * inFormatString, ...);

// Define Signed and Unsigned 64 bit Integer types
/*#if defined (_INTEGRAL_MAX_BITS) && _INTEGRAL_MAX_BITS >= 64
typedef signed   __int64 int64;
typedef unsigned __int64 uint64;
#else
#error __int64 type not supported
#endif
*/

// Experimental Settings
#define CALC_NEAR_POLY_FLOAT  1

// Common Defines
#ifndef OK
#define OK 0
#endif

#ifndef ERR
#define ERR 1
#endif

#ifndef TRUE
#define TRUE 1
#endif

#ifndef FALSE
#define FALSE 0
#endif

#ifndef BYTES_PER_PIXEL
#define BYTES_PER_PIXEL 4
#endif

// Offset from base pixel to the Alpha Value
#define ALPHA_OFFSET 3

// Magnitude
#ifndef MAGN
#define MAGN(x)  ( ((x) >= 0.0) ? (x) : (-x) )
#endif

// Clamp and Floor are used for Bilinear Image sampling, etc.
#ifndef CLAMP
#define CLAMP(min,var,max) ((var<min) ? (min) : ((var>max) ? (max) : (var)))
#endif

#ifndef FLOOR
#define FLOOR(x) (((x)>0) ? (int)(x) : ((int)(x)-1))
#endif

// Epsilon used to test if a Polygon is "Edge-on"
#define EDGE_ON_EPS  0.2

// Definition of standard types

// Eight bit unsigned storage
#define INDBITS8 (1 << 8)
#define MAXBITS8 (INDBITS8 - 1)
typedef unsigned char Bits8;

// Structure of 8 bit components for storing Color and Alpha
typedef struct { Bits8 red, grn, blu, alp; } ColBits8;

// Linear types, with a constant term
typedef struct { double x, y,    c; } Linear2D;
typedef struct { double x, y, z, c; } Plane3D;

// Points, H = version with homogeneous component
typedef struct { double x, y      ; } Point2D;
typedef struct { double x, y,    h; } Point2H;
typedef struct { double x, y, z   ; } Point3D;
typedef struct { double x, y, z, h; } Point3H;

// Vectors
#ifdef NEVER
typedef struct { double x, y      ; } Vector2D;
typedef struct { double x, y,    h; } Vector2H;
typedef struct { double x, y, z   ; } Vector3D;
typedef struct { double x, y, z, h; } Vector3H;
#endif

// Specialized Points
typedef struct { double             s, t; } PointST;
typedef struct { double x, y,       s, t; } PointST2D;
typedef struct { double x, y,    h, s, t; } PointST2H;
typedef struct { double x, y, z,    s, t; } PointST3D;

// Integer Version, for pixel coordinates, etc..
typedef struct { int x, y; } Point2Di;

// Length of string for storing Database Name
#define DATABASE_NAME_LEN 128

// View Window Size and Position
struct ViewWindow {
  int width, height;
  int hintX, hintY, hintScreen;
};
typedef struct ViewWindow ViewWindow;

// ViewPort for rendering within a View Window
struct ViewPort {
  int minX, minY, maxX, maxY;
  int width, height;  // Calculated
};
typedef struct ViewPort ViewPort;

// Rendering intermediate Tile Dimensions
struct Tile {
  int width, height;
  int x, y;
};
typedef struct Tile Tile;

// Eye Point
struct Eye   { float x,y,z; };
typedef struct Eye Eye;

// Sight Point
struct Sight { float x,y,z; };
typedef struct Sight Sight;

// Field-of-View
struct FOV { float left, right, top, bot; };
typedef struct FOV FOV;

// Type of View
enum ViewType { Perspective, Orthographic };
typedef enum ViewType ViewType;

// Current View Structure
struct View {
  struct Eye   eye;     // Eye   Point
  struct Sight sight;   // Sight Point
  struct FOV   fov;     // Field-Of-View
  float  roll, focus;   // Roll along View Vector, Focus distance
  float  hither, yon;   // Distance to Hither and Yon planes
  enum ViewType type;   // Type of View: Perspective or Orthographic
};
typedef struct View View;

// Float Color
struct rgbColor {
  float r,g,b;
};
typedef struct rgbColor RgbColor;

// Display Program Control
struct DispContr {
  unsigned int init:1, resize:1, clear:1, flash:1, done:1;
};
typedef struct DispContr DispContr;

// Render Program Control
#define MAX_USER_INDEX  32
struct RendContr {
  unsigned database:1, classify:1, init:1, render:1, clear:1, done:1;
  unsigned condor:1,   xyImageOrder:1, xyzOrder:1;
  unsigned hardware:1, software:1;
  unsigned int user [MAX_USER_INDEX];
};
typedef struct RendContr RendContr;

// Volume Rendering Control
typedef struct VolContr {
  Point3D  sampMult;               // Volume SuperSampling Controls
  Point3D  lightVect;              // Light Vector
  float    ambient,  diffuse;      // Shading Ambient and Diffuse values
  float    specular, emissive;     // Specular Emissive shading components
  float    specExponent;           // Specular exponent shading component
  float    specRed, specGrn, specBlu;  // Specular Color
  float    levThresh, levWidth;    // Levoy tent controls for Classification
  int      zSamples;               // Math approach Z Samples between min and max
  unsigned colorCondor:1, colorPerm:1;               // Colorize
  unsigned classColor:1, classLook:1, classLevoy:1;  // Classifier Mode
  ColBits8 classLookup [INDBITS8];                   // Classification Lookup Table
} VolContr;

#endif
