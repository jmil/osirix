/*
 * $Id: Clipper3H.h,v 1.4 2002/11/06 15:56:34 ford Exp $
 *
 *    Copyright 2002 by Real Time Visualization, TeraRecon, Inc.
 *    All Rights Reserved.
 *
 */  
// Geometry Clipper for 3D Homogeneous Coordinates
#ifndef CLIPPER3H_H
#define CLIPPER3H_H

#define MAX_CLIP_PLANES  6

class Clipper3H {
public:

  // Construct Clipper for Normalized Device Coordinates

  // Constructors
  Clipper3H ();

  // Use Geometry Clipper Object

  // Reset back to no clip planes
  void Reset ();

  // Add Clipping Plane (Plane Equation) - return (ERR, or OK)
  bool AddClipPlane (const Plane3H &inClipPlane);

  // Clip Polygon (Polygon) - return (Non-null Polygon created)
  bool ClipPolyST3H (PolygonST3H &inOutPoly);

  // Clip Cube (Cube) - Optional


private:

  // Clipper Internal Storage

  // Number of Clipping Planes
  int mNumClip;

  // Clipping Planes
  Plane3H mClipPlane [MAX_CLIP_PLANES];

};
#endif
