/*
 * Threads.h
 *
 * $Id: Threads.h,v 1.6 2004/10/19 17:06:59 vesper Exp $
 *
 * Platform-independent interface to the module that provides thread
 * functionality on the current platform. There are multiple implementations
 * of these routines.
 *
 * Copyright, Mitsubishi Electric Information Technology Center 
 * America, Inc., 1998, 1999, 2000. All rights reserved.
 *
 *    Copyright 2001,2002,2003,2004 by Real Time Visualization, TeraRecon, Inc.
 *    All Rights Reserved.
 */


#ifndef THREADS_H
#define THREADS_H

/* data types that we export */

#if   defined(_WIN32)
typedef unsigned (_stdcall *ThreadMainProc) (void *);	/* main procedure for our thread */
#elif defined (sun)
extern "C"
{
	typedef void * (*ThreadMainProc) (void *);	/* main procedure for our thread */
}
#else
typedef void * (*ThreadMainProc) (void *);	/* main procedure for our thread */
#endif

struct CriticalSection;						/* a critical section - opaque */
struct Semaphore;							/* a semaphore - opaque */
struct Thread;								/* a thread - opaque */

/* routines that we export */
											/* thread routines */
extern	Thread*				THRCreateThread (ThreadMainProc	inMainProc, void *inData);
extern	void				THRDestroyThread (Thread* inThread);
extern	void				THRSleep (unsigned int inMilliseconds);

											/* semaphore routines (interthread communications) */
extern	void				THRDestroySemaphore (Semaphore* inSemaphore);
extern	Semaphore*			THRInitializeSemaphore (unsigned initialCount = 0);
extern	void				THRPostSemaphore (Semaphore* inSemaphore);
extern	int					THRTestSemaphore (Semaphore* inSemaphore);
extern	int					THRWaitSemaphore (Semaphore* inSemaphore, long inTimeoutMilliseconds = -1);

											/* critical section routines */
extern	CriticalSection*	THRCreateCriticalSection (void);
extern	void				THRDestroyCriticalSection (CriticalSection* inCriticalSection);
extern	void				THREnterCriticalSection (CriticalSection* inCriticalSection);
extern	void				THRLeaveCriticalSection (CriticalSection* inCriticalSection);

#endif /* ndef THREADS_H */

