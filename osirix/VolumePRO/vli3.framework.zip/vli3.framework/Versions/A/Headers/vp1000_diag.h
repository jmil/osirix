/************************************************************************
 *
 *  Copyright 2000  Mitsubishi Electric Information Technology Center
 *  America, Inc.  All Rights Reserved.
 *
 *  $Id: vp1000_diag.h,v 1.13 2001/10/18 20:21:06 hazel Exp $
 *
 *  Author - Mark Yeager
 *
 *  Purpose - 
 *      Header file for use with VP1000 diagnostics.
 *
 ************************************************************************/
#ifndef VP1000_DIAG_H_INCLUDED
#define VP1000_DIAG_H_INCLUDED

#if defined (__cplusplus)
extern "C" {
#endif

/************************************************************************
 *
 *                             Macros
 *
 ************************************************************************/
#define VP1000_DIAG_KIND_PCI_CONFIG_READ     1
#define VP1000_DIAG_KIND_PCI_CONFIG_WRITE    2
#define VP1000_DIAG_KIND_PCI_CONFIG_RESET    3

#define	VP1000_DIAG_DEV_NEXT				-1
#define	VP1000_DIAG_DEV_SPECIFIED			 0
#define	VP1000_DIAG_DEV_CONDOR				 1
#define	VP1000_DIAG_DEV_BRIDGE				 2

#define	VP1000_DIAG_QSTATE_MAX_EVENTS		128		/* VP1000_EVENT_RECORD_MAX from events.h */
#define	VP1000_DIAG_SYNC_MAX_WAITING		((VP1000_OPEN_MAX -1) * (VP1000_DEVICE_MAX -1))

#define	VP1000_DIAG_QUEUE_RUNNING			0
#define	VP1000_DIAG_QUEUE_EMPTY				1
#define	VP1000_DIAG_QUEUE_PAUSED			2
#define	VP1000_DIAG_QUEUE_HALTED			3
#define	VP1000_DIAG_QUEUE_RESET				4
#define	VP1000_DIAG_QUEUE_INVALID			5

/************************************************************************
 *
 *                          Data Structures
 *
 ************************************************************************/
typedef struct _Vp1000_diag_pci_config_access
                                    Vp1000_diag_pci_config_access;
typedef struct _Vp1000_diag_hw_map  Vp1000_diag_hw_map;
typedef struct _Vp1000_diag_buffer_hw_address
                                    Vp1000_diag_buffer_hw_address;
typedef struct _Vp1000_diag_scatter_gather 
                                    Vp1000_diag_scatter_gather;
typedef struct _Vp1000_diag_kernel_buffer_phys_address 
                                    Vp1000_diag_kernel_buffer_phys_address;
typedef struct _Vp1000_diag_interrupt_wait
                                    Vp1000_diag_interrupt_wait;

typedef struct _Vp1000_diag_queue_event		Vp1000_diag_queue_event;
typedef struct _Vp1000_diag_queue_state		Vp1000_diag_queue_state;
typedef struct _Vp1000_diag_queue_status	Vp1000_diag_queue_status;

typedef struct _Vp1000_diag_sync_client		Vp1000_diag_sync_client;
typedef struct _Vp1000_diag_sync_sleeping	Vp1000_diag_sync_sleeping;
typedef struct _Vp1000_diag_sync_wakeup		Vp1000_diag_sync_wakeup;


struct _Vp1000_diag_pci_config_access
{
    int     status;                 /* Results of the IOCTL.
                                     */
    int     kind;                   /* Either VP1000_DIAG_KIND_PCI_CONFIG_READ
                                     *  or VP1000_DIAG_KIND_PCI_CONFIG_WRITE; */
	short	dev_no;					/* input VP1000_DIAG_DEV_CONDOR,
									 * VP1000_DIAG_DEV_NEXT, or 0 = use bus_no, slot_no */
	short	bus_no;					/* output unless dev_no = 0 */

	short	slot_no;				/* output unless dev_no = 0 */

	short	funct;					/* output unless dev_no = 0 */

    uint32  offset;                 /* Offset in bytes in PCI config space,
                                     *  must be 32 bit aligned */
    uint32  value;                  /* Value read from or written to the 
                                     *  PCI config register. */
}; /* struct _Vp1000_diag_pci_config_access */

struct _Vp1000_diag_hw_map
{
    int     status;                 /* Results of the IOCTL.
                                     */
    Vp1000_dr_ptr memory_user_address;     /* Address in host user virtual 
                                     *  memory space of the HW memory 
                                     *  (PCI BAR 0).
                                     */
    int     memory_user_size;       /* Size in bytes of the virtual mapping in
                                     *  host user address space of the mapped
                                     *  HW memory (PCI BAR 0).
                                     */
    Vp1000_dr_ptr  register_user_address; /* Address in host user virtual 
                                     *  memory space of the registers
                                     *  (PCI BAR 1).
                                     */
    int     register_user_size;     /* Size in bytes of the virtual mapping in
                                     *  host user address space of the mapped
                                     *  registers (PCI BAR 1).
                                     */
}; /* struct _Vp1000_diag_hw_map */

struct _Vp1000_diag_buffer_hw_address
{
    int     status;                 /* Results of the IOCTL.
                                     */
    uint32  buffer_id;              /* ID of the allocated buffer in 
                                     *  HW memory.
                                     */
    uint32	hw_address;             /* Address (offset) in VP1000 HW memory
                                     *  of the buffer.
                                     */
    uint32	hw_size;				/* Size of the buffer in bytes in VP1000 HW memory
                                     */
}; /* struct _Vp1000_diag_buffer_hw_address */

struct _Vp1000_diag_scatter_gather
{
    uint64  pci_address;            /* PCI address of a portion of host memory.
                                     */
    uint32  size;                   /* Size in bytes of the contiguous memory
                                     *  that pci_address refers to.
                                     */
    uint32  padding;                /* For alignment.
                                     */
}; /* struct _Vp1000_diag_scatter_gather */

struct _Vp1000_diag_kernel_buffer_phys_address
{
    int     status;                 /* Results of the IOCTL.
                                     */
    uint32  kernel_buffer_id;       /* ID of the allocated buffer in 
                                     *  kernel memory.
                                     */
    int     sg_length;              /* Length of the sg_list array.
                                     */
    int     sg_count;               /* Number of elements in the sg_list
                                     *  array that contain valid information.
                                     */
    Vp1000_diag_scatter_gather   sg_list[1];
                                    /* Array of scatter_gather entries.
                                     */
}; /* struct _Vp1000_diag_kernel_buffer_phys_address */

struct _Vp1000_diag_interrupt_wait
{
    int     status;                 /* Results of the IOCTL.
                                     */
    int     wait_status;            /* Results of the wait, either 
                                     *  VP1000_DR_SYNC_WAIT_STATUS_OCCURRED or
                                     *  VP1000_DR_SYNC_WAIT_STATUS_TIMEOUT.
                                     */
    int     timeout;                /* Maximum block time in milleseconds, or
                                     *  VP1000_DR_SYNC_TIMEOUT_POLL, or
                                     *  VP1000_DR_SYNC_TIMEOUT_MAX.
                                     */
    int     register_address;       /* Offset in bytes to a HW register to
                                     *  write the value to.
                                     */
    uint32  value;                  /* 32 bit value to be written to the
                                     *  HW register.
                                     */
    uint32  interrupt_status;       /* Interrupt bits from the HW.
                                     */
}; /* struct _Vp1000_diag_interrupt_wait */


struct _Vp1000_diag_queue_event
{
	uint32		event_id;

	uint16		initiating_client_index;	/* 0 based */

	uint8		client_sync_count;	/* how many clients are
									 * syncing on this event */
}; /* struct _Vp1000_diag_queue_event */

struct _Vp1000_diag_queue_state
{
	int		state;					/* VP1000_DIAG_QUEUE_xxxxx
									 */
	uint32	size;					/* queue size in quadwords */

	uint32	full;					/* queue entries used in quadwords */

	uint32	scratch_endp;			/* value used for synchronizing events */

	uint16	queue_full_count;		/* any clients waiting on queue full ? */

	uint16	active_events;			/* how may entries in the following array
									 * are used */
	Vp1000_diag_queue_event		events[VP1000_DIAG_QSTATE_MAX_EVENTS];

}; /* struct _Vp1000_diag_queue_state */


struct _Vp1000_diag_queue_status
{
	int		status;					/* Results of the IOCTL.
									 */
	Vp1000_diag_queue_state	DMAin;	/* 
									 */
	Vp1000_diag_queue_state	render;	/* 
									 */
	Vp1000_diag_queue_state	DMAout;	/* 
									 */
}; /* struct _Vp1000_diag_queue_status */


/* client_index and board_index uniquely identify a client */

struct _Vp1000_diag_sync_client
{
	uint16		client_index;		/* 0 based */

	uint8		board_index;		/* 0 based */

	uint8		pending_sync_count;	/* how many events handed to sync()
									 * are still pending */
}; /* struct _Vp1000_diag_sync_client */

struct _Vp1000_diag_sync_sleeping
{
	int		status;					/* Results of the IOCTL.
									 */
	int		client_count;			/* how many elements are filled in
									 */
	Vp1000_diag_sync_client	sleeping_clients[VP1000_DIAG_SYNC_MAX_WAITING];
}; /* struct _Vp1000_diag_sync_sleeping */

struct _Vp1000_diag_sync_wakeup
{
	int		status;					/* Results of the IOCTL.
									 */
	uint16		client_index;		/* 0 based */

	uint16		board_index;		/* 0 based */
}; /* struct _Vp1000_diag_sync_wakeup */


/************************************************************************
 *
 *                            Functions
 *
 ************************************************************************/

#if defined (__cplusplus)
};
#endif


#endif /* VP1000_DIAG_H_INCLUDED */
/************************************************************************
 *
 *                           End of File vp1000_diag.h
 *
 ************************************************************************/
