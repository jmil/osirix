/*
 * $Id: asimcommandbuffer.h,v 1.3 2001/03/27 14:32:22 vesper Exp $
 *
 * User mode interface to the Volume Graphics Board device driver.
 *
 *    Copyright 2001 by Real Time Visualization, TeraRecon, Inc.
 *    All Rights Reserved.
 */

#ifndef ASIMCOMMANDBUFFER_H
#define ASIMCOMMANDBUFFER_H

#include "vgbcommandbuffer.h"


class ASIMCommandBuffer : public VGBCommandBuffer
{
public:

						ASIMCommandBuffer (VGBBoard * inBoard, int inSizeWanted);
	virtual				~ASIMCommandBuffer (void);

	virtual VLIuint64 *			GetBlockAddress (VGBCommandBlockID inID);

	// When the command block is re-usable, VGB wrapper needs to call

	virtual VLIStatus			ReleaseBlock (VGBCommandBlockID inID, unsigned int inSize);

private:	// methods
	virtual VGBCommandIndex		GetNextIndex (void);
	virtual VLIStatus			WriteNextWord (VLIuint64 inWord);
	virtual VLIStatus			WriteWordAt (VGBCommandIndex inOffset, VLIuint64 inWord);
	virtual VLIuint64			ReadWordAt  (VGBCommandIndex inOffset);
	virtual VLIStatus			CheckForFreeSpace (int inFreeSpaceNeeded);
	virtual VLIStatus			WaitForFreeSpace (int inFreeSpaceNeeded);

private:	// Data
public:
	// Buffer size and location
	VGBBoard *			m_board;			// Which board
	VLIuint64 *			m_bufferBase;		// in host memory
	unsigned int		m_bufferSize;		// in 64-bit words

	// Circular buffer state
//	VGBCommandIndex		m_HW_start;			// offset of first word that HW (actually, the driver) controls
//	VGBCommandIndex		m_SW_start;			// offset of first word that SW controls
	unsigned int		m_freeSize;			// available for SW; in 64-bit words

	VGBCommandIndex		m_nextFreeWord;		// offset of next word to write
};

#endif // ASIMCOMMANDBUFFER_H
