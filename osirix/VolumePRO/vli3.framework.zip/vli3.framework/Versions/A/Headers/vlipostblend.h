/*****************************************************************************
 *
 *	$Id: vlipostblend.h,v 1.4 2004/10/19 17:07:05 vesper Exp $
 *
 *	Purpose:
 *		This class combines the result of the perspective rendering operation
 *		with the two application-supplied image buffers to generate the final
 *		image buffer. This final image is then sent back to the VP1000.
 *
 *	Copyright 2002,2003,2004 by Real Time Visualization, TeraRecon, Inc.
 *	All Rights Reserved.
 *
 ****************************************************************************/

#ifndef VLIPOSTBLEND_H
#define VLIPOSTBLEND_H

#include "vliinternal.h"
#include "VLISoftwareBlendVolume.h"

class VLIPostBlend
{
public:
	VLIPostBlend(void);

	~VLIPostBlend(void);


	VLISyncEvent	Blend(
						void*					inFrameBuffer,
						VLIImageRange			inViewport,
						int						inElementSize,
						VLIFieldDescriptor		inFields[4],
						VLIContext*				inContext,
						VLIImageBuffer*			inImage0,
						VLIImageBuffer*			inImage1);

private:
	VLIImageBuffer*	m_image;
	VLISoftwareBlendVolume	m_softwBlendVolume;
	char *m_accumBuffer;
	int	m_accumBufferSize;	
};

#endif // VLIPOSTBLEND_H
