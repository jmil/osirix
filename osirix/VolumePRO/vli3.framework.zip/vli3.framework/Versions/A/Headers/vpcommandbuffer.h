/******************************************************************************
 *
 *	$Id: vpcommandbuffer.h,v 1.4 2004/10/19 17:07:10 vesper Exp $
 *
 *	User mode interface to the Volume Graphics Board device driver.
 *
 *    Copyright 2001,2002,2003,2004 by Real Time Visualization, TeraRecon, Inc.
 *    All Rights Reserved.
 *
 *****************************************************************************/

#ifndef VPCOMMANDBUFFER_H
#define VPCOMMANDBUFFER_H

#include "vgbcommandbuffer.h"


//##ModelId=3D2DABD70041
class VPCommandBuffer : public VGBCommandBuffer
{
public:

	//##ModelId=3D2DABD70043
						VPCommandBuffer (VGBBoard * inBoard, int inSizeWanted);
	//##ModelId=3D2DABD7004E
	virtual				~VPCommandBuffer (void);

	//##ModelId=3D2DABD70051
	virtual VLIuint64 *			GetBlockAddress (VGBCommandBlockID inID);

	// When the command block is re-usable, VGB wrapper needs to call

	//##ModelId=3D2DABD70054
	virtual VLIStatus			ReleaseBlock (VGBCommandBlockID inID, unsigned int inSize);

private:	// methods
	//##ModelId=3D2DABD7005D
	virtual VGBCommandIndex		GetNextIndex (void);
	//##ModelId=3D2DABD70060
	virtual VLIStatus			WriteNextWord (VLIuint64 inWord);
	//##ModelId=3D2DABD70063
	virtual VLIStatus			WriteWordAt (VGBCommandIndex inOffset, VLIuint64 inWord);
	//##ModelId=3D2DABD7006F
	virtual VLIuint64			ReadWordAt (VGBCommandIndex inOffset);
	//##ModelId=3D2DABD70072
	virtual VLIStatus			CheckForFreeSpace (int inFreeSpaceNeeded);
	//##ModelId=3D2DABD70075
	virtual VLIStatus			WaitForFreeSpace (int inFreeSpaceNeeded);

private:	// Data
public:
	// Buffer size and location
	//##ModelId=3D2DABD70080
	VGBBoard *			m_board;			// Which board
	//##ModelId=3D2DABD7008D
	VLIuint64 *			m_bufferBase;		// in host memory
	//##ModelId=3D2DABD70091
	unsigned int		m_bufferSize;		// in 64-bit words

	// Circular buffer state
//	VGBCommandIndex		m_HW_start;			// offset of first word that HW (actually, the driver) controls
//	VGBCommandIndex		m_SW_start;			// offset of first word that SW controls
	//##ModelId=3D2DABD700FA
	unsigned int		m_freeSize;			// available for SW; in 64-bit words

	//##ModelId=3D2DABD7010A
	VGBCommandIndex		m_nextFreeWord;		// offset of next word to write
};

#endif // VPCOMMANDBUFFER_H
