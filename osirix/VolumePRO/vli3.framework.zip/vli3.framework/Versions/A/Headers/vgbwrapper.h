/******************************************************************************
 *
 * $Id: vgbwrapper.h,v 1.61 2004/11/10 14:44:13 jch Exp $
 *
 * User mode interface to the Volume Graphics Board device driver.
 *
 * Copyright, Mitsubishi Electric Information Technology Center 
 * America, Inc., 1998, 1999, 2000. All rights reserved.
 *
 *    Copyright 2001,2002,2003,2004 by Real Time Visualization, TeraRecon, Inc.
 *    All Rights Reserved.
 *
 *****************************************************************************/


#ifndef VGBWRAPPER_H
#define VGBWRAPPER_H
//#include <windows.h>                      /* Windows API */
/* interfaces to modules that we reference */

#ifdef _MSC_VER
#pragma warning (disable : 4786)
#endif
                                            /* operating system interfaces */
#define qPciApi				1

#include "RTVIZTypes.h"
#include "vlisamplespace.h"

#if defined(sparc)
// D.M. 01/30/02 This driver is not used anymore
//#include "vgbsolaris.h"
#elif defined(WIN32)
#include <windows.h>
/* make it clear we are not in the driver */
#define NDRIVER
//#include "vgbnt.h"
#elif defined(sgi)
#include "vgbirix.h"
#elif defined(linux)
//#include "vgplinux.h"
#elif defined(hpux)
#elif defined(RTVIZ_OS_MACOSX)
#else
#error UNKNOWN OS
#endif


#include "vgbcommandbuffer.h"
#if 0
static const int kCommandBufferSizeDefault		= 200;		// 64-bit words
static const int kCommandBufferSizeMin			= 100;		// 64-bit words
static const int kCommandBufferSizeMax			= 400;		// 64-bit words

static const int kQueueSizeDefault				= 2048;
static const int kQueueSizeMin					= 256;		// 64-bit words
static const int kQueueSizeMax					= 8192;		// 64-bit words
#else
static const int kCommandBufferSizeDefault		= 20000;		// 64-bit words
static const int kCommandBufferSizeMin			= 1000;			// 64-bit words
static const int kCommandBufferSizeMax			= 40000;		// 64-bit words

static const int kQueueSizeDefault				= 204800;
static const int kQueueSizeMin					= 2560;			// 64-bit words
static const int kQueueSizeMax					= 819200;		// 64-bit words

#endif //RKP
/*static const int kCommandBufferSizeDefault		= 200;		// 64-bit words
static const int kCommandBufferSizeMin			= 100;		// 64-bit words
static const int kCommandBufferSizeMax			= 400;		// 64-bit words

static const int kQueueSizeDefault				= 2048;
static const int kQueueSizeMin					= 256;		// 64-bit words
static const int kQueueSizeMax					= 8192;		// 64-bit words*/

static const int kWriteToImage0					= 1;
static const int kWriteToImage1					= 2;
static const int kWriteToDepth0					= 4;
static const int kWriteToDepth1					= 8;

// The wrapper does not include vliinternal.h,
// so we may need to define dDebug

#ifndef dDebug
#ifdef _DEBUG
#define dDebug			1
#else
#define dDebug			0
#endif
#endif

#define dAssert			1

#if dAssert
void vgbAssert(char *, char *, unsigned int);

#define VGB_ASSERT(exp_) (void)( (exp_) || (vgbAssert(#exp_, __FILE__, __LINE__), 0) )

#else

#define VGB_ASSERT(exp_) ((void)0) /* nothing */

#endif

#define VGBAPI_MAJOR_VERSION 3
#define VGBAPI_MINOR_VERSION 0

typedef	uint64			VGBObjectID;

enum VGBDimension
{
	VGBDim1D				= 0,
	VGBDim2D				= 1,
	VGBDim3D				= 2
};

enum VGBElementSize
{
	VGBElementSizeInvalid	= -1,
	VGBElementSize8			= 0,
	VGBElementSize16		= 1,
	VGBElementSize32		= 3,
	VGBElementSize64		= 7
};

inline uint32 VGBRealElementSize (int codedSize) { return codedSize + 1; }

// Note: (x & x-1) clears the low order bit of x, which gives 0 if x is a power of 2
inline uint VGBIsPowerOf2 (uint x) { return (x & (x - 1)) == 0; }

// Check bit fields for validity
inline bool VGBBitFieldValid (uint size, uint position, uint elementSize)
{
	return VGBIsPowerOf2(size) && (position & 7) == 0 && size >= 8 && size <= 64 &&
		   size + position <= 64 && (size + position <= elementSize || position == 0);
}

struct VGBFieldFormat
{
	int8	position;
	int8	size;
	int8	control;
};

struct VGBFourFieldFormats
{
	int8	position0;
	int8	size0	;
	int8	control0;
	int8	position1;
	int8	size1	;
	int8	control1;
	int8	position2;
	int8	size2	;
	int8	control2;
	int8	position3;
	int8	size3	;
	int8	control3;
};

class VGBRange
{
public:
	int16		m_minU;
	int16		m_minV;
	int16		m_minW;
	int16		m_maxU;
	int16		m_maxV;
	int16		m_maxW;

	// Constructors
	VGBRange (int16 minU, int16 minV, int16 minW, int16 maxU, int16 maxV, int16 maxW) :
		m_minU (minU), m_minV (minV), m_minW (minW), m_maxU (maxU), m_maxV (maxV), m_maxW (maxW)
	{ }

	VGBRange (int16 minU, int16 minV, int16 maxU, int16 maxV) :
		m_minU (minU), m_minV (minV), m_minW (0), m_maxU (maxU), m_maxV (maxV), m_maxW (0)
	{ }

	VGBRange (int16 minU, int16 maxU) :
		m_minU (minU), m_minV (0), m_minW (0), m_maxU (maxU), m_maxV (0), m_maxW (0)
	{ }

	VGBRange () : m_minU (0), m_minV (0), m_minW (0), m_maxU (0), m_maxV (0), m_maxW (0)
	{ }

	// Validity testing
	bool		IsValid () const
	{
		return (m_minU >= 0 && m_maxU >= m_minU &&
				m_minV >= 0 && m_maxV >= m_minV &&
				m_minW >= 0 && m_maxW >= m_minW);
	}

	bool		IsValid (uint inDimensions, uint inSizeU, uint inSizeV, uint inSizeW) const
	{
		return (IsValid() && m_maxU < int16(inSizeU) &&
				(inDimensions <= 1 || m_maxV < int16(inSizeV) ) &&
				(inDimensions <= 2 || m_maxW < int16(inSizeW) ));
	}
};


class VGBBuffer
{
private:

public:

	VGBObjectID		m_id;

	int16			m_size_U;		// size values, set by user,
	int16			m_size_V;		// re-computed by driver
	int16			m_size_W;

	int16			m_offset_U;		// offset/modulus values
	int16			m_offset_V;
	int16			m_offset_W;

	int8			m_elementSize;
	int8			m_dimension;
	int8			m_wrap;
	int8			m_swizzles;		// Set by driver
	int8			m_alignment;
	int8			m_hostSize;

	int16			m_min_U;		// min values
	int16			m_min_V;
	int16			m_min_W;

	int16			m_max_U;		// max values
	int16			m_max_V;
	int16			m_max_W;

	uint			m_sequenceNumber;// Number to indicate when buffer changes

	VLISyncEvent	m_loadEvent;	// Last buffer load
	mutable VLISyncEvent	m_unloadEvent;	// Last buffer unload
	VLISyncEvent	m_renderEvent;	// Last render using this buffer
	bool			m_isRenderOutput;	// This buffer was an output to last render

	VLIPermission	m_permission_share;

VGBBuffer ()
	:	m_id ( 0 ), 
		m_size_U ( 0 ),
		m_size_V ( 0 ),
		m_size_W ( 0 ),
		m_offset_U ( 0 ),
		m_offset_V ( 0 ),
		m_offset_W ( 0 ),
		m_elementSize ( 0 ),
		m_dimension ( 0 ),
		m_wrap ( 0 ),
		m_swizzles ( 0 ), 
		m_alignment ( 0 ),
		m_hostSize ( 0 ),
		m_min_U ( 0 ),
		m_min_V ( 0 ),
		m_min_W ( 0 ),
		m_max_U ( 0 ), 
		m_max_V ( 0 ),
		m_max_W ( 0 ),
		m_sequenceNumber (0), 
		m_loadEvent (),
		m_unloadEvent (),
		m_renderEvent (),
		m_isRenderOutput (false),
		m_permission_share (kVLIPermissionNotShared)
	{
		// No code needed
	}

public:
	VGBBuffer (uint inSizeU, uint inSizeV, uint inSizeW,
			   uint inElementSize, VLIStatus& outStatus);


	void		SetID (VGBObjectID inID)		{ m_id = inID; }

	VGBObjectID	GetID () const					{ return m_id; }

	void		SetSizes (uint inSizeU, uint inSizeV, uint inSizeW, uint inElementSize)
	{
		m_dimension = inSizeV == 0 ? 0 : inSizeW == 0 ? 1 : 2;
		m_size_U = inSizeU - 1;
		m_size_V = m_dimension > 0 ? inSizeV - 1 : 0;
		m_size_W = m_dimension > 1 ? inSizeW - 1 : 0;
		m_elementSize = (inElementSize >> 3) - 1;
	}

	uint		GetSizes (uint& outSizeU, uint& outSizeV, uint& outSizeW, uint& outElementSize) const
	{
		outSizeU = m_size_U + 1;
		outSizeV = m_dimension > 0 ? m_size_V + 1 : 0;
		outSizeW = m_dimension > 1 ? m_size_W + 1 : 0;
		outElementSize = (m_elementSize + 1) << 3;
		return m_dimension + 1;
	}

	uint32		GetTotalSize () const
	{ return (m_size_U+1) * (m_size_V+1) * (m_size_W+1) * (m_elementSize+1); }

	VLIStatus	SetOffsetOrWrap (bool inWrapFlag, int inOffsetU, int inOffsetV, int inOffsetW)
	{
		if (inWrapFlag)
		{
			if (! VGBIsPowerOf2(inOffsetU) || ! VGBIsPowerOf2(inOffsetV) || ! VGBIsPowerOf2(inOffsetW))
				return kVLIErrArgument;		// Each modulus must be a power of two
			m_wrap = 1;
			m_offset_U = inOffsetU - 1;
			m_offset_V = inOffsetV - 1;
			m_offset_W = inOffsetW - 1;
		}
		else
		{
			if ((inOffsetU | inOffsetV | inOffsetW) & 1)
				return kVLIErrArgument;		// Offsets must be even
			m_wrap = 0;
			m_offset_U = inOffsetU;
			m_offset_V = inOffsetV;
			m_offset_W = inOffsetW;
		}
		return kVLIOK;
	}

	void		GetOffsetOrWrap (bool& outWrapFlag, int& outOffsetU, int& outOffsetV, int& outOffsetW) const
	{
		outOffsetU = m_offset_U + m_wrap;
		outOffsetV = m_offset_V + m_wrap;
		outOffsetW = m_offset_W + m_wrap;
		outWrapFlag = m_wrap != 0;
	}

	// Do not include methods for setting and getting the swizzle bits, since they
	// are only set internally by the driver

	void	SetAlignment (uint inAlignment)	{ m_alignment = inAlignment; }
	uint	GetAlignment () const		{ return m_alignment; }
	void	SetHostSize (uint inHostSize)	{ m_hostSize = inHostSize; }
	uint	GetHostSize () const		{ return m_hostSize; }

	void		SetRange (const VGBRange& inRange)
	{
		m_min_U = inRange.m_minU;
		m_min_V = inRange.m_minV;
		m_min_W = inRange.m_minW;
		m_max_U = inRange.m_maxU;
		m_max_V = inRange.m_maxV;
		m_max_W = inRange.m_maxW;
	}

	void		GetRange (VGBRange& outRange) const
	{
		outRange.m_minU = m_min_U;
		outRange.m_minV = m_min_V;
		outRange.m_minW = m_min_W;
		outRange.m_maxU = m_max_U;
		outRange.m_maxV = m_max_V;
		outRange.m_maxW = m_max_W;
	}

	void		GetAdjustedRange (VGBRange& outRange) const
	{
		// If the buffer range is empty (defined as all zeros) and is
		// using offset mode, adjust it to be the one element at the
		// offset position. This is used when rendering to a buffer
		// that could be only an output. If it is an input, presumably
		// the range would be set to something else.
		if (m_min_U == 0 && m_min_V == 0 && m_min_W == 0 &&
			m_max_U == 0 && m_max_V == 0 && m_max_W == 0 && !m_wrap)
		{	
			outRange.m_minU = outRange.m_maxU = m_offset_U;
			outRange.m_minV = outRange.m_maxV = m_offset_V;
			outRange.m_minW = outRange.m_maxW = m_offset_W;
		}
		else
			GetRange(outRange);
	}

	void			SetSequenceNumber (uint inSeq)	{ m_sequenceNumber = inSeq; }
	void			IncrementSequenceNumber ()	{ ++m_sequenceNumber; }
	uint			GetSequenceNumber () const	{ return m_sequenceNumber; }

#if dDebug
	void			SetLoadEvent (VLISyncEvent inEvent);
	void			SetUnloadEvent (VLISyncEvent inEvent) const;
	void			SetRenderEvent (VLISyncEvent inEvent, bool inIsOutput);
#else
	void			SetLoadEvent (VLISyncEvent inEvent) { m_loadEvent = inEvent; }
	void			SetUnloadEvent (VLISyncEvent inEvent) const { m_unloadEvent = inEvent; }
	void			SetRenderEvent (VLISyncEvent inEvent, bool inIsOutput)
	{
		m_renderEvent = inEvent;
		m_isRenderOutput = inIsOutput;
	}
#endif

	void			SetLoadOrRenderEvent (VLISyncEvent inEvent);

	VLISyncEvent	GetLoadEvent () const	{ return m_loadEvent; }

	VLISyncEvent	GetUnloadEvent () const	{ return m_unloadEvent; }

	// Reading from this buffer can happen in parallel with rendering from this buffer
	VLISyncEvent	GetRenderEvent (bool inIsOutput) const
	{
		return (inIsOutput || m_isRenderOutput) ? m_renderEvent : VLISyncEvent(kVLIOK);
	}
};

struct VGBKernelMemory
{
	uint32		dwStatus;
	uint32		dwKernelMemoryId;		// Returned ID of kernel memory. 
	void		* lpvMappedAddr;		// Address in user space of mapping to 
										// the kernel memory.
	uint32		dwRequestedAmount;		// Amount in bytes of requested allocation.
	uint32		dwAllocatedAmount;		// Amount in bytes of allocated memory.
};


class VGBCommand 
{
public:
	VGBCommand () : 
		diffuseMap(0), 
		specularMap(0) 
	{ 
		lLut[0] = 0; lLut[1] = 0; lLut[2] = 0; lLut[3] = 0; 
		iTarget.buffer = 0;
		
	        iTarget.format.position0 = 0;
        	iTarget.format.size0  =0 ;
        	iTarget.format.control0 =0;
        	iTarget.format.position1=0;
        	iTarget.format.size1   =0;
        	iTarget.format.control1=0;
        	iTarget.format.position2=0;
        	iTarget.format.size2   =0;
        	iTarget.format.control2=0;
        	iTarget.format.position3=0;
        	iTarget.format.size3   =0;
        	iTarget.format.control3=0;


		iTarget.border = 0x7f7f7f7f;
			vVolume.buffer = 0;

		vVolume.hwVoxelBorder = 0x0; // Why not?
	}

	uint32				dwStatus;

	struct
	{
		VGBBuffer *			buffer;
		uint32				strideW;				// stride from one w slice to the next (bytes)
		uint32				strideV;				// stride from one scan line to the next (bytes)
		uint32				totalSize;				// in bytes
		VGBFourFieldFormats	voxelFormat;
		uint32				hwVoxelBorder;
	}					vVolume;
	
	
	struct
	{
		VGBBuffer *			buffer;
		VGBFourFieldFormats	format;
		uint32				border;
		void *				hostAddress;
		uint32				endX;
		uint32				endY;
	}					iTarget;


	VGBBuffer *			lLut[4];
	int					lutSize[4];
	uint64 *			lutData[4];
	VGBFourFieldFormats	lutFormat[4];
	VGBBuffer *			diffuseMap;
	uint64 *			diffuseHost;
	VGBBuffer *			specularMap;
	uint64 *			specularHost;
};

extern void VLIOutputMessage (const char *inFormatString, ...);

static const long VGB_INVALID_ID = -1;
static const long VGB_WAIT_FOREVER = 0;

enum VGBPixelFormat
{
    kpfRGBA8888             = 0,            /* 32 bit pixels: 8 bits red, 8 bits green, 8 bits blue, 8 bits alpha */
    kpfBGRA8888             = 1,            /* 32 bit pixels: 8 bits blue, 8 bits green, 8 bits red, 8 bits alpha */
    kpfARGB8888             = 2,            /* 32 bit pixels: 8 bits alpha, 8 bits red, 8 bits green, 8 bits blue */
    kpfABGR8888             = 3,            /* 32 bit pixels: 8 bits alpha, 8 bits blue, 8 bits green, 8 bits red */
    kpfRGBA4444             = 4,            /* 16 bit pixels: 4 bits red, 4 bits green, 4 bits blue, 4 bits alpha */
    kpfBGRA4444             = 5,            /* 16 bit pixels: 4 bits blue, 4 bits green, 4 bits red, 4 bits alpha */
    kpfARGB4444             = 6,            /* 16 bit pixels: 4 bits alpha, 4 bits red, 4 bits green, 4 bits blue */
    kpfABGR4444             = 7,            /* 16 bit pixels: 4 bits alpha, 4 bits blue, 4 bits green, 4 bits red */

    kpfFirstPixelFormat     = kpfRGBA8888,
    kpfLastPixelFormat      = kpfABGR4444
};

struct VGBCropInfo
{
	uint32    m_minX;                 /* X position of minimum YZ crop plane S23.8 */
	uint32    m_minY;                 /* Y position of minimum XZ crop plane S23.8 */
	uint32    m_minZ;                 /* Z position of minimum XY crop plane S23.8 */

	uint32    m_maxX;                 /* X position of maximum YZ crop plane S23.8 */
	uint32    m_maxY;                 /* Y position of maximum XZ crop plane S23.8 */
	uint32    m_maxZ;                 /* Z position of maximum XY crop plane S23.8 */

	uint32    m_configuration;        /* how planes are combined to form crop volume */
};

struct VGBTrimInfo
{
	uint32    m_minX;                 /* X position of minimum YZ trim plane S23.8 */
	uint32    m_minY;                 /* Y position of minimum XZ trim plane S23.8 */
	uint32    m_minZ;                 /* Z position of minimum XY trim plane S23.8 */

	uint32    m_maxX;                 /* X position of maximum YZ trim plane S23.8 */
	uint32    m_maxY;                 /* Y position of maximum XZ trim plane S23.8 */
	uint32    m_maxZ;                 /* Z position of maximum XY trim plane S23.8 */
};

#define kccEnabled              0x00000008
#define kccDisabled             0x00000000

/* type that we export */
struct VGBCursor
{
	unsigned int    m_width;
	unsigned int    m_length;

	unsigned int    m_configuration;

	unsigned int    m_xRed;
	unsigned int    m_xGreen;
	unsigned int    m_xBlue;
	unsigned int    m_xAlpha;

	unsigned int    m_yRed;
	unsigned int    m_yGreen;
	unsigned int    m_yBlue;
	unsigned int    m_yAlpha;

	unsigned int    m_zRed;
	unsigned int    m_zGreen;
	unsigned int    m_zBlue;
	unsigned int    m_zAlpha;
};

struct VGBCutPlane
{
	double      m_normalX;                      /* X component of normal vector of plane */
	double      m_normalY;                      /* Y component of normal vector of plane */
	double      m_normalZ;                      /* Z component of normal vector of plane */

	double      m_dMin;                         /* minimum D value where plane begins w.r.t. origin */
	double      m_dMax;                         /* maximum D value where plane ends w.r.t. origin */

	double      m_falloff;                      /* opacity value to fall off to */

	bool        m_viewDataIsOutsideCutPlanes;   /* == true, the data to view is that outside the cut plane */
};

enum VGBExcludeEdgeFlags 
{
	VGBExcludeNone  = 0, 
	VGBExcludeEdgeX = 1, 
	VGBExcludeEdgeY = 2, 
	VGBExcludeEdgeZ = 4
};

static const int kVGBImageBufferSize = 512;
static const int kVGBMaxBoards = 8;

struct VGBConfiguration
{
	uint64   dwTotalMemory;          // total amount of memory available in bytes
	uint32   dwStatus;
	uint32   dwMajorVersion;         // major HW version number of this board
	uint32   dwMinorVersion;         // minor HW version number of this board
    uint32   dwCapsLevel;            // What capabilities can this driver support?
	uint32   dwActiveImageBuffers;
	uint32   dwPciRev;               // 0, 1 BoardA, 2 boardB
	bool	 dwSupportsPeer;
	bool	 dwSupportsAbort;
	bool	 dwSupportsDump;
};

struct VGBMemoryStats
{
	uint64		dwTotal;
	uint64		dwLocked;
	uint64		dwUnlocked;
	uint64		dwFree;

	VGBMemoryStats (uint64 total = 0, uint64 locked = 0, uint64 unlocked = 0, uint64 free = 0)
		: dwTotal (total), dwLocked (locked), dwUnlocked (unlocked), dwFree (free) {}
};

class VGBBoard;

class VGBQueue
{
public:
				VGBQueue (VGBBoard * inBoard, uint inBoardID, uint32 inProducerAddress, uint64 inBaseAddress, uint32 inSize);
				~VGBQueue (void);
	VLIStatus	ExecuteBlock (VGBCommandBuffer * pBuffer, VGBCommandBlockID inBlockID, unsigned int inSize);
	uint32		BumpSyncRegister (void);
	VLIStatus	InsertSyncWait (VLISyncEvent inSyncEvent);

	uint64		m_baseAddress;
	uint32		m_sizeMask;

	// Each queue has a VGBCommand buffer associated with it
	// It is public so that VGBBoard can use it.

	VGBCommandBuffer	* m_buffer;

private:
	VGBBoard *	m_board;
	uint		m_boardID;				// Which board is this queue on?
	uint32		m_producerAddress;
	uint32		m_freeWords;
	uint32		m_nextWord;
	uint32		m_nextSync;
};

#if defined(WIN32)
typedef HANDLE	VGBHandle;
#elif defined(RTVIZ_OS_MACOSX)
typedef uint64		VGBHandle;
#else
typedef int		VGBHandle;
#endif

class VGRenderData;
class VGBPciApi;

enum MapType
{
	eSimpleMap,
	eSimulatedMap,
	eNotImplementedMap
};

class VGBBoardFriend;	// Quiet compiler

class VGBBoard
{
	friend class VGBBoardFriend;

private:
	static VGBBoard*	gBoards[];			// All the boards in the system.

	int					m_id;				// Which board is this.
    int                 m_peer;             // ID of peer 'board' or -1 if none.
	bool				m_exclusive;		// Board was opened exclusive.
	VGBHandle			m_handle;			// This process's handle to the board.
	VGBConfiguration	m_configuration;	// Configuration of the board.
	char*				m_driverVersionString;
	uint64				m_lastAddr;
	VGBMemoryStats		m_memory;
	VGBQueue*			m_renderQueue;
	VGBQueue*			m_dmaInQueue;
	VGBQueue*			m_dmaOutQueue;
	VLISyncEvent		m_lastRenderEvent;
	VLISyncEvent		m_lastLoadEvent;	// Last buffer load
	VLISyncEvent		m_lastUnloadEvent;	// Last buffer unload
	mutable int			m_driverStatus;		// Latest driver return code
	MapType				m_mapType;			// Last map type
						VGBBoard (int inID, bool inIsExclusive, VLIStatus &outStatus);
											// Open a board and put it in gBoards.

						~VGBBoard ();		// Close a board.

	VGBHandle			GetHandle (void) { return m_handle; }

	VLIStatus			CreateQueues (void);

	VGBQueue*			CreateOneQueue (uint32 inProducerAddress, int inSizeWanted = kQueueSizeDefault);


public:
	VGBPciApi*			m_pci;

	int					GetPeer (void) const { return m_peer; }

	// Management
	// ----------

	static uint			VGBMaxCount(void);	// How many boards there are in the system.

	static VGBBoard*	Open (int inID, VLIStatus& outStatus, bool inIsExclusive = false);
											// Open a board with given exclusivity.

	static VLIStatus	Close (int inID);	// Close a board.

	
	static int			GetBoardNumberFromObjectID (VGBObjectID inObjectID);


	int					GetBoardNumber(void) { return m_id; }

	void				GetConfiguration(VGBConfiguration &outConfiguration);

	static const char*	GetCompiledVersionString ();	// Static; available without a board

	const char*			GetConnectedVersionString ();	// Not static; board specific

	VGBMemoryStats		GetMemoryStats (void);

	VLIStatus			UpdateBufferSize(VGBBuffer* ioBuffer);

	static VLIStatus	WaitForSync (VLISyncEvent& ioEvent, long timeoutInMS);

	static VLIStatus	commonAbort (VLISyncEvent ioEvent);

	VLIStatus			WaitForAny (int inNumEvents, VLISyncEvent ioEventArray[], long timeoutInMS);

	VLIStatus			WaitForAll (int inNumEvents, VLISyncEvent ioEventArray[], long timeoutInMS);

	VLIStatus			AbortEvent (VLISyncEvent ioEvent);

	void				SetDriverStatus (int inStatus) const	{ m_driverStatus = inStatus; }

	int					GetDriverStatus (void) const			{ return m_driverStatus; }

	VLIStatus			TranslateDriverStatus (int inStatus);

	void				DumpQueues (void);

	VLISyncEvent		GetLastLoadEvent (void) { return m_lastLoadEvent; }

	VLISyncEvent		GetLastUnloadEvent (void) { return m_lastUnloadEvent; }
	
	VLISyncEvent		GetLastRenderEvent (void) { return m_lastRenderEvent; }


	// Resource creation
	// -----------------

	VGBBuffer*			CreateBuffer(uint inSizeU, uint inSizeV, uint inSizeW,
									 uint inElementSize, VLIStatus& outStatus);

	VGBBuffer*			AttachBuffer(VGBObjectID inObjectID, VLIStatus& outStatus);

	VLIStatus			ReleaseBuffer(VGBBuffer* ioBuffer, bool inKeepObject = false);

	VLISyncEvent		StartCopyBuffer(const VGBBuffer* inBufferIn, VGBBuffer* ioBufferOut,
								   const VGBRange& inRangeIn, const VGBRange& inRangeOut);

	VLIStatus			ResizeBuffer(VGBBuffer* ioBuffer, uint inSizeU, uint inSizeV, uint inSizeW);

	VLIStatus			CreateKernelBuffer (uint inSizeWanted, uint& outSizeGot,
											void*& outBufferAddress, int& outBufferId);

	VGBCommandBuffer*	CreateCommandBuffer (int inSizeWanted = kCommandBufferSizeDefault);

	// Render operation
	// ----------------

	void				DumpBuffers (			// For debug - possibly write PNG files
							VGBBuffer*			inImage0,
							VGBBuffer*			inImage1,
							VGBBuffer*			inDepth0,
							VGBBuffer*			inDepth1,
							unsigned int		inWriteTo);

	VLISyncEvent		StartRender (
							VLISyncEvent		lastRenderEvent,
							VGBCommandBuffer*	renderBuffer, 
							VGBCommandBlockID	renderBlock, 
							unsigned int		renderBlockSize,
							VGBCommandBuffer*	stateBuffer, 
							VGBCommandBlockID	stateBlock,
							unsigned int		stateBlockSize,
							VGBBuffer*			inVolume,
							VGBBuffer*			inImage0,
							VGBBuffer*			inImage1,
							VGBBuffer*			inDepth0,
							VGBBuffer*			inDepth1,
							unsigned int		inWriteTo,
							VGBBuffer*			inLut[4],
							VGBBuffer*			diffuseMap,
							VGBBuffer*			specularMap,
							VGBBuffer*			GMLut,
							VGBBuffer*			ACLut);

	// Data transfer operations
	// ------------------------

	VLIStatus			LoadBuffer (
							VGBBuffer* inBuffer,		// Destination
							const void* inHostAddress,	// Source
							const VGBRange& inRange,	// Sub-buffer to load
							uint inSizeU = 0,			// Size of host buffer in elements
							uint inSizeV = 0,			//   (0 means use range)
							int inKernelBufferId = VGB_INVALID_ID);

	VLIStatus			LoadBufferField (
							VGBBuffer* inBuffer,		// Destination
							const void* inHostAddress,	// Source
							uint inSizeBits,			// Number of bits to load
							uint inPositionBits,		// Position of bits in element
							const VGBRange& inRange,	// Sub-buffer to load
							uint inSizeU = 0,			// Size of host buffer in elements
							uint inSizeV = 0,			//   (0 means use range)
							int inKernelBufferId = VGB_INVALID_ID);

	VLISyncEvent		StartLoadBuffer (
							VGBBuffer* inBuffer,		// Destination
							const void* inHostAddress,	// Source
							const VGBRange& inRange,	// Sub-buffer to load
							uint inSizeU = 0,			// Size of host buffer in elements
							uint inSizeV = 0,			//   (0 means use range)
							int inKernelBufferId = VGB_INVALID_ID);

	VLISyncEvent		StartLoadBufferField (
							VGBBuffer* inBuffer,		// Destination
							const void* inHostAddress,	// Source
							uint inSizeBits,			// Number of bits to load
							uint inPositionBits,		// Position of bits in element
							const VGBRange& inRange,	// Sub-buffer to load
							uint inSizeU = 0,			// Size of host buffer in elements
							uint inSizeV = 0,			//   (0 means use range)
							int inKernelBufferId = VGB_INVALID_ID);

	VLISyncEvent		DoStartLoadBufferField (
							VGBBuffer* inBuffer,		// Destination
							const void* inHostAddress,	// Source
							uint inSizeBits,			// Number of bits to load
							uint inPositionBits,		// Position of bits in element
							const VGBRange& inRange,	// Sub-buffer to load
							uint inSizeU = 0,			// Size of host buffer in elements
							uint inSizeV = 0,			//   (0 means use range)
							int inKernelBufferId = VGB_INVALID_ID);

	VLISyncEvent		StartClearBuffer (
							VGBBuffer* inBuffer,		// Destination
							VLIuint64 inValue,			// Value to clear to
							const VGBRange& inRange);	// Sub-buffer to clear

	VLIStatus			UnloadBuffer (
							const VGBBuffer* inBuffer,	// Source
							void* inHostAddress,		// Destination
							const VGBRange& inRange,	// Sub-buffer to unload
							uint inSizeU = 0,			// Size of host buffer in elements
							uint inSizeV = 0,			//   (0 means use range)
							int inKernelBufferId = VGB_INVALID_ID);

	VLIStatus			UnloadBufferField (
							const VGBBuffer* inBuffer,	// Source
							void* inHostAddress,		// Destination
							uint inSizeBits,			// Number of bits to unload
							uint inPositionBits,		// Position of bits in element
							const VGBRange& inRange,	// Sub-buffer to unload
							uint inSizeU = 0,			// Size of host buffer in elements
							uint inSizeV = 0,			//   (0 means use range)
							int inKernelBufferId = VGB_INVALID_ID);

	VLISyncEvent		StartUnloadBuffer (
							const VGBBuffer* inBuffer,	// Source
							void* inHostAddress,		// Destination
							const VGBRange& inRange,	// Sub-buffer to unload
							uint inSizeU = 0,			// Size of host buffer in elements
							uint inSizeV = 0,			//   (0 means use range)
							int inKernelBufferId = VGB_INVALID_ID);

	VLISyncEvent		StartUnloadBufferField (
							const VGBBuffer* inBuffer,	// Source
							void* inHostAddress,		// Destination
							uint inSizeBits,			// Number of bits to unload
							uint inPositionBits,		// Position of bits in element
							const VGBRange& inRange,	// Sub-buffer to unload
							uint inSizeU = 0,			// Size of host buffer in elements
							uint inSizeV = 0,			//   (0 means use range)
							int inKernelBufferId = VGB_INVALID_ID);

	VLISyncEvent		DoStartUnloadBufferField (
							const VGBBuffer* inBuffer,	// Source
							void* inHostAddress,		// Destination
							uint inSizeBits,			// Number of bits to unload
							uint inPositionBits,		// Position of bits in element
							const VGBRange& inRange,	// Sub-buffer to unload
							uint inSizeU = 0,			// Size of host buffer in elements
							uint inSizeV = 0,			//   (0 means use range)
							int inKernelBufferId = VGB_INVALID_ID);

	// Mapping buffers
	// ---------------

	VLIStatus			MapBuffer (
							VGBBuffer* ioBuffer,
							void*& outHostAddr,			// Will be set to a virtual address
							const VGBRange& inRange,	// Sub-buffer to map in
							VLIAccessType inAccess,		// Read and/or write
							uint& outSizeU,				// Size of host buffer in elements
							uint& outSizeV);

	VLIStatus			MapBufferField (
							VGBBuffer* ioBuffer,
							void*& outHostAddr,			// Will be set to a virtual address
							uint inSizeBits,			// Number of bits to map in
							uint inPositionBits,		// Position of bits in element
							const VGBRange& inRange,	// Sub-buffer to map in
							VLIAccessType inAccess,		// Read and/or write
							uint& outSizeU,				// Size of host buffer in elements
							uint& outSizeV);

	VLIStatus			UnmapBuffer (
							VGBBuffer* ioBuffer,
							void* ioHostAddr);			// Will be invalid after this call

	// Setting permissions
	// -------------------

	VLIStatus			SetBufferPermission (
							VGBBuffer * ioBuffer,
							VLIPermission inPermission);

	VLIPermission		GetBufferPermission (
							const VGBBuffer * inBuffer);
	
	// Resource deletion
	// -----------------

	void				DestroyKernelBuffer (
							int inBufferId,
							unsigned int inAllocatedSize,
							void* inBufferAddress);
};


#define kIdealNormalizedEyeMagnitude	1.0 /* ideal magnitude for the 
												normalized eye vector */
#define kEpsilonNormalizedEyeMagnitude	(1.0 / 128.0) /* acceptible epsilon 
												for normalized eye vector 
												from ideal magnitude */
#define kNormalizedEyeMagnitude 		127.0 /* the normalized eye magnitude 
												on the chip is 127 */




#endif /* ifndef VGBWRAPPER_H */
