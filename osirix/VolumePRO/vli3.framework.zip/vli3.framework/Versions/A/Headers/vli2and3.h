#ifndef VLI2AND3_H
#define VLI2AND3_H

/******************************************************************************
 *
 *  $Id: vli2and3.h,v 1.3 2004/10/19 17:07:01 vesper Exp $
 *
 *  Purpose:
 *      This header file includes both the old version 2 vli.h and the new
 *      version 3 vli3.h files. It is used to allow either or both of the
 *      VP500 and VP1000 boards to be used in one program. In order to do
 *      this, you must:
 *
 *      1. Remove the version 3 vli.h file from any directory that is in
 *         the include path
 *      2. Make sure that the version 2 vli.h file is in the include path
 *      3. Include this file in your application instead of vli.h and/or vli3.h
 *      4. Prefix all vli3 objects with "vli3::", for example:
 *             vli3::VLIStatus status = vli3::VLIOpen();
 *      5. Leave all version 2 names un-prefixed, or prefix them with "::"
 *      6. Do not mix version 2 and 3 objects
 *
 *      As an alternative to 1, 2 and 3 above, you can use a specific path to
 *      include the old vli.h before including this file, for example:
 *          #include "mydir/inc/vli.h"
 *          #include "vli2and3.h"
 *
 *  Copyright 2001, 2002, 2003, 2004 by Real Time Visualization, TeraRecon, Inc.
 *  All Rights Reserved.
 *
 *****************************************************************************/

// First include the version 2 vli definitions
#include "vli.h"

// We need to change some of the old definitions so as to not conflict with
// vli3. The preprocessor macros are converted into declarations in the
// current (most likely global) namespace.

// Create constants for the old version numbers
static const int kVLIOldMajorVersion    = kVLIMajorVersion;
static const int kVLIOldMinorVersion    = kVLIMinorVersion;
#undef kVLIMajorVersion
#undef kVLIMinorVersion

// Create an inline VLIOpen to replace the old macro
#undef VLIOpen
inline VLIStatus VLIOpen(void)
{
    return VLIOpenInternal(kVLIOldMajorVersion, kVLIOldMinorVersion);
}

// Replace boolean macros with constants
#undef VLIfalse
#undef VLItrue
static const int VLIfalse   = 0;
static const int VLItrue    = !VLIfalse;

// Replace color packing and unpacking macros with inline functions
#undef VLIPackRGBA
#undef VLIGetRed
#undef VLIGetGreen
#undef VLIGetBlue
#undef VLIGetAlpha
inline VLIRGBAPacked VLIPackRGBA(VLIuint32 r, VLIuint32 g, VLIuint32 b, VLIuint32 a)
{
    return (r<<24) | (g<<16) | (b<<8) | a;
}
inline VLIuint32 VLIGetRed(VLIRGBAPacked packed)
{
    return (packed >> 24) & 0xff;
}
inline VLIuint32 VLIGetGreen(VLIRGBAPacked packed)
{
    return (packed >> 16) & 0xff;
}
inline VLIuint32 VLIGetBlue(VLIRGBAPacked packed)
{
    return (packed >> 8) & 0xff;
}
inline VLIuint32 VLIGetAlpha(VLIRGBAPacked packed)
{
    return (packed >> 0) & 0xff;
}

// vli3 will define this macro
#undef VLIEXPORT

// Replace linear gradient ramp macro with a constant
#undef kVLILinearGradientRamp
static const double * kVLILinearGradientRamp = 0;

// Now include the vli3 definitions, without including them in the
// global namespace
#include "vli3.h"

#endif // VLI2AND3_H
