/************************************************************************
 *
 *	Copyright � 2001 TeraRecon, Inc.  All Rights Reserved.
 *  Copyright � 2000 Mitsubishi Electric Info Tech Center America, Inc.
 *
 *    Copyright 2001,2002,2003,2004 by Real Time Visualization, TeraRecon, Inc.
 *    All Rights Reserved.
 *
 *  $Id: vp1000_dr.h,v 1.50 2004/11/10 14:45:14 jch Exp $
 *
 *  Author - Mark Yeager
 *
 *  Purpose - 
 *      VP1000 Device Driver public header file.
 *
 *  Definitions of IOCTLs, macros, and data structures shared by
 *      the VP1000 device drivers and the VP1000 Wrapper.
 *
 *  If you want the IOCTL status strings compiled in, then define
 *      VP1000_DR_COMPILE_STATUS_STRINGS before including this file.
 *
 *  If you want the device driver version number compiled in, then define
 *      VP1000_DR_COMPILE_DRIVER_VERSION before including this file.  Also,
 *      you must define VP1000_DR_VERSION_OS as an integer at compile time
 *      before including this file.
 *
 *  To use this file you must first include RTVIZTypes.h.
 *
 ************************************************************************/
#ifndef VP1000_DR_H_INCLUDED
#define VP1000_DR_H_INCLUDED

#ifdef __KERNEL__
#define _KERNEL
#endif

#ifdef __KERNEL
#define _KERNEL
#endif

#include "RTVIZTypes.h"

#if defined (__cplusplus)
extern "C" {
#endif


/************************************************************************
 *
 *                             Macros
 *
 ************************************************************************/
/* Version information.
 */
#define VP1000_DR_VERSION_MAJOR_NUMBER          0
#define VP1000_DR_VERSION_MINOR_NUMBER          3

/* Maximum number of boards in one host.
 */
#define VP1000_DEVICE_NUM_BITS					3

#define VP1000_DEVICE_MAX					(1 << VP1000_DEVICE_NUM_BITS)

/* IOCTL and other definitions, for each OS.
 */
#if defined (WIN32)
    /*##################################################################
    #
    #                          Windows NT
    #
    ####################################################################*/
#ifdef _KERNEL
#include <ntddk.h>
#else
// #include <windef.h>
#include <windows.h>
#include <winbase.h>
#include <winioctl.h>
#endif /* _KERNEL */

/* Boolean, does the OS require unique file names for unique device 
 *  minor numbers? 
 */
#define VP1000_UNIQUE_MINOR_FILENAME            0      

/* Base name for multiple boards.   We will concatonate on "00" for the 1st,
 *  "01" for the 2nd, "02" for the 3rd, etc.
 */
#define VP1000_DEVICE_NAME_BASE                 "\\\\.\\vp10"

typedef HANDLE                                  Vp1000_dr_handle;
typedef uint64									Vp1000_dr_ptr;
typedef int										Vp1000_bool;
typedef int										Vp1000_def_int;

#define VP1000_DR_IOCTL_BASE                    0x00009000 
#define VP1000_DR_IOCTL_DECLARE(_index)                                     \
    CTL_CODE(VP1000_DR_IOCTL_BASE,_index,METHOD_NEITHER,FILE_ANY_ACCESS)

#if _WIN64
/* 64 bit pointers, 32 bit ints. */
#define VP1000_64_BIT_PTR 1
#endif

#elif defined (sparc)
    /*##################################################################
    #
    #                          Solaris
    #
    ####################################################################*/

#ifndef __KERNEL__
#include <unistd.h>
#endif

/* Boolean, does the OS require unique file names for unique device 
 *  minor numbers? 
 */
#define VP1000_UNIQUE_MINOR_FILENAME            1   

/* Base name for multiple boards.   We will concatonate on "00" for the 1st,
 *  "01" for the 2nd, "02" for the 3rd, etc.
 */
#define VP1000_DEVICE_NAME_BASE                 "/dev/vp10"

typedef int                                     Vp1000_dr_handle;
typedef uint64									Vp1000_dr_ptr;
typedef uint32									Vp1000_bool;
typedef uint32									Vp1000_def_int;

#define VP1000_DR_IOCTL_BASE                    ('C' << 8)
#define VP1000_DR_IOCTL_DECLARE(_index) (int)(VP1000_DR_IOCTL_BASE | _index)

#if defined (_LP64)
/* 64 bit pointers, 64 bit ints. */
#define VP1000_64_BIT_PTR 1
#endif

#elif defined (hpux)
    /*##################################################################
    #
    #                          H.P. ux
    #
    ####################################################################*/

#ifndef __KERNEL__
#include <sys/ioctl.h>
#endif

/* Boolean, does the OS require unique file names for unique device 
 *  minor numbers? 
 */
#define VP1000_UNIQUE_MINOR_FILENAME            1   

/* Base name for multiple boards.   We will concatonate on "00" for the 1st,
 *  "01" for the 2nd, "02" for the 3rd, etc.
 */
#define VP1000_DEVICE_NAME_BASE                 "/dev/vp10"

typedef int                                     Vp1000_dr_handle;
typedef uint64									Vp1000_dr_ptr;
typedef uint32									Vp1000_bool;
typedef uint32									Vp1000_def_int;

#define VP1000_DR_IOCTL_BASE                    ('V' << 8)
#define VP1000_DR_IOCTL_DECLARE(_index) (int)(IOC_INOUT | VP1000_DR_IOCTL_BASE | _index)

#elif defined (sgi)
    /*##################################################################
    #
    #                          IRIX
    #
    ####################################################################*/

/* Boolean, does the OS require unique file names for unique device 
 *  minor numbers? 
 */
#define VP1000_UNIQUE_MINOR_FILENAME            1      

/* Base name for multiple boards.   We will concatonate on "00" for the 1st,
 *  "01" for the 2nd, "02" for the 3rd, etc.
 */
#define VP1000_DEVICE_NAME_BASE                 "/hw/vp10"

typedef int                                     Vp1000_dr_handle;
typedef uint64									Vp1000_dr_ptr;
typedef int										Vp1000_bool;
typedef int										Vp1000_def_int;

#define VP1000_DR_IOCTL_BASE                    ('V'<<24 | 'P'<<16 | '1'<<8)
#define VP1000_DR_IOCTL_DECLARE(_index) (int)(VP1000_DR_IOCTL_BASE | _index)

#elif defined (linux)
    /*##################################################################
    #
    #                          Linux
    #
    ####################################################################*/

#ifdef __KERNEL__
#include <linux/ioctl.h>
#else
#include <sys/ioctl.h>
#endif

/* Boolean, does the OS require unique file names for unique device 
 *  minor numbers? 
 */
#define VP1000_UNIQUE_MINOR_FILENAME            1      

/* Base name for multiple boards.   We will concatonate on "00" for the 1st,
 *  "01" for the 2nd, "02" for the 3rd, etc.
 */
#define VP1000_DEVICE_NAME_BASE                 "/dev/vp10"

typedef int                                     Vp1000_dr_handle;
typedef uint64									Vp1000_dr_ptr;
typedef int										Vp1000_bool;
typedef int										Vp1000_def_int;


#define VP1000_DR_IOCTL_BASE                    'V'
#define VP1000_DR_IOCTL_DECLARE(_index) _IOWR(VP1000_DR_IOCTL_BASE,_index,long)

#elif defined (RTVIZ_OS_MACOSX)
    /*##################################################################
    #
    #                          Mac OS X
    #
    ####################################################################*/

#include <sys/ioctl.h>
#ifndef __KERNEL__
	#include <IOKit/IOKitLib.h>
#endif
enum
{
	kVP1000UserClientOpen = 0,
	kVP1000UserClientClose,
	kVP1000UserClientIoctl
};

/* Boolean, does the OS require unique file names for unique device 
 *  minor numbers? 
 */
#define VP1000_UNIQUE_MINOR_FILENAME            1      

/* Base name for multiple boards.   We will concatonate on "00" for the 1st,
 *  "01" for the 2nd, "02" for the 3rd, etc.
 */
#define VP1000_DEVICE_NAME_BASE                 "/dev/vp10"

#ifndef __KERNEL__
typedef struct
{
	io_connect_t		connection;
	long				openIndex;
} Vp1000_dr_handle_internal;
#endif

typedef uint64									Vp1000_dr_handle;
typedef uint32									Vp1000_dr_ptr;
typedef int										Vp1000_bool;
typedef int										Vp1000_def_int;

#define kIOKitDriverName						"VolumePro1000"

#define VP1000_DR_IOCTL_BASE                    'V'
#define VP1000_DR_IOCTL_DECLARE(_index) _IOWR(VP1000_DR_IOCTL_BASE,_index,long)

#else 
    /*##################################################################
    #
    #                          OS undefined
    #
    ####################################################################*/

#error HEY! What Operating System are you compiling for ? ;

#endif /* OS specific */

#ifdef VP1000_64_BIT_PTR

// Cast directly to and from Vp1000_dr_ptr
#define		VP1000_CAST_TO_POINTER(type_, var)		((type_ *)(var))
#define		VP1000_CAST_FROM_POINTER(ptr)		((Vp1000_dr_ptr)(ptr))

#else

// Cast through uint32
#define		VP1000_CAST_TO_POINTER(type_, var)		((type_ *)(uint32)(var))
#define		VP1000_CAST_FROM_POINTER(ptr)		((Vp1000_dr_ptr)(uint32)(ptr))

#endif


/* Maximum number of times that a single device can be open()'d.  MUST BE a 
 *  power of 2.
 */
#define VP1000_OPEN_MAX                         16      

/* IOCTL definitions.
 */
#define VP1000_DR_IOCTL_CONFIGURATION_GET       VP1000_DR_IOCTL_DECLARE(0x01)
#define VP1000_DR_IOCTL_BOARD_COUNT				VP1000_DR_IOCTL_DECLARE(0x02)
#define VP1000_DR_IOCTL_HW_RESET                VP1000_DR_IOCTL_DECLARE(0x03)
#define VP1000_DR_IOCTL_RENDER                  VP1000_DR_IOCTL_DECLARE(0x04)
#define VP1000_DR_IOCTL_SYNC                    VP1000_DR_IOCTL_DECLARE(0x05)
#define VP1000_DR_IOCTL_ABORT					VP1000_DR_IOCTL_DECLARE(0x08)

#define	VP1000_DR_IOCTL_START_DAEMON			VP1000_DR_IOCTL_DECLARE(0x06)
#define	VP1000_DR_IOCTL_STOP_DAEMON				VP1000_DR_IOCTL_DECLARE(0x07)

#define VP1000_DR_IOCTL_KERNEL_BUFFER_ALLOC     VP1000_DR_IOCTL_DECLARE(0x0A)
#define VP1000_DR_IOCTL_KERNEL_BUFFER_FREE      VP1000_DR_IOCTL_DECLARE(0x0B)
#define VP1000_DR_IOCTL_KERNEL_BUFFER_MAP       VP1000_DR_IOCTL_DECLARE(0x0C)
#define VP1000_DR_IOCTL_KERNEL_BUFFER_UNMAP     VP1000_DR_IOCTL_DECLARE(0x0D)
#define VP1000_DR_IOCTL_KERNEL_BUFFER_ALLOC_CONTIG	VP1000_DR_IOCTL_DECLARE(0x0E)
#define VP1000_DR_IOCTL_PEERS_GET               VP1000_DR_IOCTL_DECLARE(0x0F)

#define VP1000_DR_IOCTL_BUFFER_ALLOC			VP1000_DR_IOCTL_DECLARE(0x10)
#define VP1000_DR_IOCTL_BUFFER_ATTACH			VP1000_DR_IOCTL_DECLARE(0x11)
#define VP1000_DR_IOCTL_BUFFER_RESIZE			VP1000_DR_IOCTL_DECLARE(0x12)
#define VP1000_DR_IOCTL_BUFFER_DETACH           VP1000_DR_IOCTL_DECLARE(0x13)
#define VP1000_DR_IOCTL_BUFFER_LOAD             VP1000_DR_IOCTL_DECLARE(0x14)
#define VP1000_DR_IOCTL_BUFFER_UNLOAD           VP1000_DR_IOCTL_DECLARE(0x15)
#define VP1000_DR_IOCTL_BUFFER_MAP              VP1000_DR_IOCTL_DECLARE(0x16)
#define VP1000_DR_IOCTL_BUFFER_UNMAP            VP1000_DR_IOCTL_DECLARE(0x17)
#define VP1000_DR_IOCTL_BUFFER_BOARD2BOARD		VP1000_DR_IOCTL_DECLARE(0x18)

#define VP1000_DR_IOCTL_DIAG_CLIENTS_ASLEEP		VP1000_DR_IOCTL_DECLARE(0x1D)
#define VP1000_DR_IOCTL_DIAG_CLIENT_WAKEUP		VP1000_DR_IOCTL_DECLARE(0x1E)
#define VP1000_DR_IOCTL_DIAG_QUEUE_STATE		VP1000_DR_IOCTL_DECLARE(0x1F)

#define VP1000_DR_IOCTL_DEBUG_LEVEL_GET         VP1000_DR_IOCTL_DECLARE(0x20)
#define VP1000_DR_IOCTL_DEBUG_LEVEL_SET         VP1000_DR_IOCTL_DECLARE(0x21)
#define VP1000_DR_IOCTL_DEBUG_COUNTER_GET       VP1000_DR_IOCTL_DECLARE(0x22)
#define VP1000_DR_IOCTL_DEBUG_COUNTER_CLEAR     VP1000_DR_IOCTL_DECLARE(0x23)
#define VP1000_DR_IOCTL_DEBUG_BUFFER_DUMP       VP1000_DR_IOCTL_DECLARE(0x24)

#define VP1000_DR_IOCTL_SIM_INIT                VP1000_DR_IOCTL_DECLARE(0x25)
#define VP1000_DR_IOCTL_SIM_INTERRUPT           VP1000_DR_IOCTL_DECLARE(0x26)
#define VP1000_DR_IOCTL_SIM_COMMAND_BLOCK       VP1000_DR_IOCTL_DECLARE(0x27)
#define VP1000_DR_IOCTL_SIM_MEMORY_ACCESS       VP1000_DR_IOCTL_DECLARE(0x28)
#define VP1000_DR_IOCTL_SIM_REGISTER_ACCESS     VP1000_DR_IOCTL_DECLARE(0x29)
#define VP1000_DR_IOCTL_SIM_PHYS_MAPPING		VP1000_DR_IOCTL_DECLARE(0x2A)

#define VP1000_DR_IOCTL_DIAG_PCI_CONFIG_ACCESS  VP1000_DR_IOCTL_DECLARE(0x2B)
#define VP1000_DR_IOCTL_DIAG_HW_MAP             VP1000_DR_IOCTL_DECLARE(0x2C)
#define VP1000_DR_IOCTL_DIAG_BUFFER_HW_ADDRESS  VP1000_DR_IOCTL_DECLARE(0x2D)
#define VP1000_DR_IOCTL_DIAG_KERNEL_BUFFER_PHYS_ADDRESS						\
                                                VP1000_DR_IOCTL_DECLARE(0x2E)
#define VP1000_DR_IOCTL_DIAG_INTERRUPT_WAIT     VP1000_DR_IOCTL_DECLARE(0x2F)

#define VP1000_DR_IOCTL_DEBUG_CQUEUE_DUMP       VP1000_DR_IOCTL_DECLARE(0x30)
#define VP1000_DR_IOCTL_DEBUG_MISC_DUMP         VP1000_DR_IOCTL_DECLARE(0x31)
/* Status Codes, returned from IOCTL's.
 */
#define VP1000_DR_STATUS_SUCCESS                         0
#define VP1000_DR_STATUS_DEVICE_ACCESS_DENIED            1
#define VP1000_DR_STATUS_DEVICE_OPEN_MAX                 2
#define VP1000_DR_STATUS_DEVICE_SYSTEM_OPEN_MAX          3
#define VP1000_DR_STATUS_DEVICE_MISC_ERROR               4 
#define VP1000_DR_STATUS_MISC_ERROR                      5 
#define VP1000_DR_STATUS_HW_ERROR                        6
#define VP1000_DR_STATUS_INVALID_ID                      7
#define VP1000_DR_STATUS_NOT_OWNER                       8
#define VP1000_DR_STATUS_OUT_OF_HOST_RESOURCES           9
#define VP1000_DR_STATUS_OUT_OF_HW_MEMORY               10
#define VP1000_DR_STATUS_OUT_OF_KERNEL_MEMORY           11
#define VP1000_DR_STATUS_OUT_OF_BUFFER_DATA_STRUCTURES  12
#define VP1000_DR_STATUS_DATA_COPY_FAILED               13
#define VP1000_DR_STATUS_PHYSIO_FAILED                  14
#define VP1000_DR_STATUS_MAP_FAILED                     15
#define VP1000_DR_STATUS_SIGNAL                         16
#define VP1000_DR_STATUS_IOCTL_NOT_IMPLEMENTED          17
#define VP1000_DR_STATUS_OUT_OF_BUFFER_RECORDS          18
#define VP1000_DR_STATUS_MALLOC_FAILED                  19
#define VP1000_DR_STATUS_INCORRECT_ADDRESS_SPACE        20
#define VP1000_DR_STATUS_OUT_OF_MAP_DATA_STRUCTURES     21
#define VP1000_DR_STATUS_KERNEL_MAP_MAX                 22
#define VP1000_DR_STATUS_NOT_MAPPED                     23
#define VP1000_DR_STATUS_PERMISSION_BAD                 24
#define VP1000_DR_STATUS_KERNEL_BUFFER_ALREADY_FREED    25
#define VP1000_DR_STATUS_VERSION_MISMATCH               26
#define VP1000_DR_STATUS_SIM_SERVER_NOT_INITED          27
#define VP1000_DR_STATUS_ARG_BAD                        28
#define VP1000_DR_STATUS_HOST_RANGE_BAD					29
#define VP1000_DR_STATUS_HW_RANGE_BAD					30
#define VP1000_DR_STATUS_OUT_OF_MAP_PORTS               31
#define VP1000_DR_STATUS_OUT_OF_BUS_ADDRESS_SPACE       32
#define VP1000_DR_STATUS_HWMEM_MAP_MAX                  33
#define VP1000_DR_STATUS_COMPACT_DISABLED               34
#define VP1000_DR_STATUS_NOT_POWER_OF_2                 35
#define VP1000_DR_STATUS_COMMAND_QUEUE_FULL             36
#define VP1000_DR_STATUS_SUB_FUNCT_NOT_IMPLEMENTED		37
#define VP1000_DR_STATUS_HW_NOT_SUPPORTED				38
#define VP1000_DR_STATUS_PORTAL_BUSY					39
#define VP1000_DR_STATUS_ALREADY_COMPLETE				40

#define VP1000_DR_STATUS_MAX                            40


/* Status Strings, indexed by Status Codes above.
 *  When adding status values,
 *  THE ORDER MATTERS, STRINGS MUST MATCH CODES !!!
 *
 *  To use vp1000_dr_status_strings[][] incorporate this test:
 *
 *  if (status <= VP1000_DR_STATUS_MAX)
 *  {
 *      printf ("your_message_here %s (%d)\n",
 *          vp1000_dr_status_strings[status], status);
 *  }
 *  else
 *  {
 *      printf ("status value %d out of range \n", status);
 *  }
 */
#ifdef VP1000_DR_COMPILE_STATUS_STRINGS

char vp1000_dr_status_strings [VP1000_DR_STATUS_MAX + 1] [64] =
{
    "VP1000_DR_STATUS_SUCCESS",
    "VP1000_DR_STATUS_DEVICE_ACCESS_DENIED",
    "VP1000_DR_STATUS_DEVICE_OPEN_MAX",
    "VP1000_DR_STATUS_DEVICE_SYSTEM_OPEN_MAX",
    "VP1000_DR_STATUS_DEVICE_MISC_ERROR",
    "VP1000_DR_STATUS_MISC_ERROR",
    "VP1000_DR_STATUS_HW_ERROR",
    "VP1000_DR_STATUS_INVALID_ID",
    "VP1000_DR_STATUS_NOT_OWNER",
    "VP1000_DR_STATUS_OUT_OF_HOST_RESOURCES",
    "VP1000_DR_STATUS_OUT_OF_HW_MEMORY",
    "VP1000_DR_STATUS_OUT_OF_KERNEL_MEMORY",
    "VP1000_DR_STATUS_OUT_OF_BUFFER_DATA_STRUCTURES",
    "VP1000_DR_STATUS_DATA_COPY_FAILED",
    "VP1000_DR_STATUS_PHYSIO_FAILED",
    "VP1000_DR_STATUS_MAP_FAILED",
    "VP1000_DR_STATUS_SIGNAL",
    "VP1000_DR_STATUS_IOCTL_NOT_IMPLEMENTED",
    "VP1000_DR_STATUS_OUT_OF_BUFFER_RECORDS",
    "VP1000_DR_STATUS_MALLOC_FAILED",
    "VP1000_DR_STATUS_INCORRECT_ADDRESS_SPACE",
    "VP1000_DR_STATUS_OUT_OF_MAP_DATA_STRUCTURES",
    "VP1000_DR_STATUS_KERNEL_MAP_MAX",
    "VP1000_DR_STATUS_NOT_MAPPED",
    "VP1000_DR_STATUS_PERMISSION_BAD",
    "VP1000_DR_STATUS_KERNEL_BUFFER_ALREADY_FREED",
    "VP1000_DR_STATUS_VERSION_MISMATCH",
    "VP1000_DR_STATUS_SIM_SERVER_NOT_INITED",
    "VP1000_DR_STATUS_ARG_BAD",
    "VP1000_DR_STATUS_HOST_RANGE_BAD",
    "VP1000_DR_STATUS_HW_RANGE_BAD",
    "VP1000_DR_STATUS_OUT_OF_MAP_PORTS",
    "VP1000_DR_STATUS_OUT_OF_BUS_ADDRESS_SPACE",
    "VP1000_DR_STATUS_HWMEM_MAP_MAX",
    "VP1000_DR_STATUS_COMPACT_DISABLED",
    "VP1000_DR_STATUS_NOT_POWER_OF_2",
    "VP1000_DR_STATUS_COMMAND_QUEUE_FULL",
	"VP1000_DR_STATUS_SUB_FUNCT_NOT_IMPLEMENTED",
	"VP1000_DR_STATUS_HW_NOT_SUPPORTED",
	"VP1000_DR_STATUS_PORTAL_BUSY",
	"VP1000_DR_STATUS_ALREADY_COMPLETE"
};

#endif /* VP1000_DR_COMPILE_STATUS_STRINGS */

/* Invalid ID.
 */
#define VP1000_DR_INVALID_ID                   0xFFFFFFFFU

#define VP1000_DR_BUFFER_DIMENSION_1            0
#define VP1000_DR_BUFFER_DIMENSION_2            1
#define VP1000_DR_BUFFER_DIMENSION_3            2

/* Element size.  Labeled in bits, value is (size - 1) in bytes.
 */
#define VP1000_DR_BUFFER_ELEMENT_SIZE_8         0
#define VP1000_DR_BUFFER_ELEMENT_SIZE_16        1
#define VP1000_DR_BUFFER_ELEMENT_SIZE_32        3
#define VP1000_DR_BUFFER_ELEMENT_SIZE_64        7

/* Macros for permissions that allow separate processes to share access to
 *  HW buffers, bits that can be OR'd together
 */
#define VP1000_DR_BUFFER_ACCESS_TYPE_READ					(1 << 0)
#define VP1000_DR_BUFFER_ACCESS_TYPE_WRITE					(1 << 1)
#define VP1000_DR_BUFFER_ACCESS_SHARE						(1 << 2)

/* These are possible values for 'permission_share'
 */
#define VP1000_DR_BUFFER_PERMISSION_SHARE_NONE              0
#define VP1000_DR_BUFFER_PERMISSION_SHARE_READ				\
			(VP1000_DR_BUFFER_ACCESS_TYPE_READ |	VP1000_DR_BUFFER_ACCESS_SHARE)
#define VP1000_DR_BUFFER_PERMISSION_SHARE_WRITE				\
			(VP1000_DR_BUFFER_ACCESS_TYPE_WRITE |	VP1000_DR_BUFFER_ACCESS_SHARE)
#define VP1000_DR_BUFFER_PERMISSION_SHARE_RESIZE			(1 << 3)
/* #define VP1000_DR_BUFFER_PERMISSION_SHARE_SET_PERMISSION	(1 << 4) */

#define VP1000_DR_BUFFER_PERMISSION_SHARE_READWRITE						\
		(VP1000_DR_BUFFER_PERMISSION_SHARE_READ		|					\
		 VP1000_DR_BUFFER_PERMISSION_SHARE_WRITE)

#define VP1000_DR_BUFFER_PERMISSION_SHARE_ALL							\
		(VP1000_DR_BUFFER_PERMISSION_SHARE_READ		|					\
		 VP1000_DR_BUFFER_PERMISSION_SHARE_WRITE	|					\
		 VP1000_DR_BUFFER_PERMISSION_SHARE_RESIZE)

/* These are possible values for 'access_share'
 */
#define VP1000_DR_BUFFER_ACCESS_READ_SHARED			 VP1000_DR_BUFFER_PERMISSION_SHARE_READ
#define VP1000_DR_BUFFER_ACCESS_WRITE_SHARED		 VP1000_DR_BUFFER_PERMISSION_SHARE_READWRITE
#define VP1000_DR_BUFFER_ACCESS_READ_EXCLUSIVE		 VP1000_DR_BUFFER_ACCESS_TYPE_READ
#define VP1000_DR_BUFFER_ACCESS_WRITE_EXCLUSIVE		(VP1000_DR_BUFFER_ACCESS_TYPE_WRITE | VP1000_DR_BUFFER_ACCESS_TYPE_READ)

/* Macro for inspecting (otherwise opaque) buffer ID's.
 * the 4 Most Significant Bits are the per device index */
#define VP1000_HWMEM_ID_PER_DEVICE_SHIFT			28

#define	VP1000_BOARD_INDEX_FROM_BUFFER_ID(_buffer_id)					\
		((int)(_buffer_id >> VP1000_HWMEM_ID_PER_DEVICE_SHIFT))

/* The maximum number of events that can be waited on in one call.
 */
#define VP1000_DR_SYNC_EVENT_COUNT_MAX              8

/* Extreme times to wait.
 */
#define VP1000_DR_SYNC_TIMEOUT_FOREVER              -1
#define VP1000_DR_SYNC_TIMEOUT_LARGE                10000
#define VP1000_DR_SYNC_TIMEOUT_POLL                 0

/* how to wait */
#define	VP1000_DR_SYNC_SELECTION_ALL				1
#define	VP1000_DR_SYNC_SELECTION_ANY				2

/* Results of waiting.
 */
#define VP1000_DR_SYNC_WAIT_STATUS_OCCURRED         1
#define VP1000_DR_SYNC_WAIT_STATUS_TIMEOUT          2
#define VP1000_DR_SYNC_WAIT_STATUS_FAILURE			3

/* Printing formats for pointers.  If the OS specific macros above do not
 *  define a 64 bit pointer, we default to 32 bit pointers.
 */
#ifdef VP1000_64_BIT_PTR

#define VP1000_PTR_SIZE                             "016"
#define VP1000_PTR_FORMAT                           INT64FORMAT

#else

#define VP1000_PTR_SIZE                             "08"
#define VP1000_PTR_FORMAT                           "l"

#endif  /* VP1000_64_BIT_PTR */

#ifndef TRUE
#define TRUE 1
#endif

#ifndef FALSE
#define FALSE 0
#endif

#define VP1000_BUFFER_DESCRIPTOR_SIZE_CALCULATE(_buffer_descriptor,_size)   \
{                                                                           \
    int     _width   = 1;                                                   \
    int     _height  = 1;                                                   \
    int     _depth   = 1;                                                   \
    int     _element_size;                                                  \
                                                                            \
    _width = (_buffer_descriptor)->buffer_size.width;                       \
    if (((_buffer_descriptor)->dimension == VP1000_DR_BUFFER_DIMENSION_2) || \
        ((_buffer_descriptor)->dimension == VP1000_DR_BUFFER_DIMENSION_3))  \
    {                                                                       \
        _height = (_buffer_descriptor)->buffer_size.height;                 \
    }                                                                       \
    if ((_buffer_descriptor)->dimension == VP1000_DR_BUFFER_DIMENSION_3)    \
    {                                                                       \
        _depth = (_buffer_descriptor)->buffer_size.depth;                   \
    }                                                                       \
    switch((_buffer_descriptor)->element_size)                              \
    {                                                                       \
        case VP1000_DR_BUFFER_ELEMENT_SIZE_8:                               \
            _element_size = 1;                                              \
            break;                                                          \
        case VP1000_DR_BUFFER_ELEMENT_SIZE_16:                              \
            _element_size = 2;                                              \
            break;                                                          \
        case VP1000_DR_BUFFER_ELEMENT_SIZE_32:                              \
            _element_size = 4;                                              \
            break;                                                          \
        case VP1000_DR_BUFFER_ELEMENT_SIZE_64:                              \
            _element_size = 8;                                              \
            break;                                                          \
    }                                                                       \
    (_size) = _width * _height * _depth * _element_size;                    \
}


/************************************************************************
 *
 *                          Data Structures
 *
 ************************************************************************/

typedef struct _Vp1000_dr_lut_cache				Vp1000_dr_lut_cache;
typedef	struct _Vp1000_dr_volimgdepth_entry		Vp1000_dr_volimgdepth_entry;
typedef struct _Vp1000_dr_all_buffers_data		Vp1000_dr_all_buffers_data;
typedef struct _Vp1000_dr_buffer_size           Vp1000_dr_buffer_size;
typedef struct _Vp1000_dr_buffer_element        Vp1000_dr_buffer_element;
typedef struct _Vp1000_dr_buffer_descriptor     Vp1000_dr_buffer_descriptor;
typedef struct _Vp1000_dr_array_addressing		Vp1000_dr_array_addressing;
typedef struct _Vp1000_dr_buffer_attach			Vp1000_dr_buffer_attach;
typedef struct _Vp1000_dr_buffer_detach			Vp1000_dr_buffer_detach;
typedef struct _Vp1000_dr_buffer_load           Vp1000_dr_buffer_load;
typedef struct _Vp1000_dr_buffer_map            Vp1000_dr_buffer_map;
typedef struct _Vp1000_dr_buffer_unmap          Vp1000_dr_buffer_unmap;
typedef struct _Vp1000_dr_buffer_board2board    Vp1000_dr_buffer_board2board;
typedef struct _Vp1000_dr_hw_reset              Vp1000_dr_hw_reset;
typedef struct _Vp1000_dr_host_buffer_alloc     Vp1000_dr_host_buffer_alloc;
typedef struct _Vp1000_dr_host_buffer_free      Vp1000_dr_host_buffer_free;
typedef struct _Vp1000_dr_kernel_buffer_map     Vp1000_dr_kernel_buffer_map;
typedef struct _Vp1000_dr_kernel_buffer_unmap   Vp1000_dr_kernel_buffer_unmap;
typedef struct _Vp1000_dr_render                Vp1000_dr_render;
typedef struct _Vp1000_dr_event                 Vp1000_dr_event;
typedef struct _Vp1000_dr_sync                  Vp1000_dr_sync;
typedef struct _Vp1000_dr_abort					Vp1000_dr_abort;
typedef struct _Vp1000_dr_configuration         Vp1000_dr_configuration;
typedef	struct _Vp1000_dr_board_select			Vp1000_dr_board_select;
typedef struct _Vp1000_dr_board_peers           Vp1000_dr_board_peers;

/* All offsets are in units of 64 bits.
 */

struct _Vp1000_dr_buffer_size
{
	Vp1000_def_int	width;			/* Number of elements in a row (X or U),
									 *  used for 1D, 2D, 3D. */
	Vp1000_def_int	height;			/* Number of rows in a slice (Y or V),
									 *  used for 2D, 3D. */
	Vp1000_def_int	depth;			/* Number of slices in a volume (Z or W),
									 *  used for 3D. */
}; /* struct _Vp1000_dr_buffer_size */

struct _Vp1000_dr_buffer_element
{
	Vp1000_def_int	x;				/* Offset to an element in width (X or U),
									 *  used for 1D, 2D, 3D. */
	Vp1000_def_int	y;				/* Offset to an element in height (Y or V),
									 *  used for 2D, 3D. */
	Vp1000_def_int	z;				/* Offset to an element in depth (Z or W),
									 *  used for 3D. */
}; /* struct _Vp1000_dr_buffer_element */

struct _Vp1000_dr_buffer_descriptor
{
	Vp1000_def_int	dimension;		/* Number of dimensions, one of the
									 *  VP1000_DR_BUFFER_DIMENSION_X macros. */
	Vp1000_def_int	element_size;	/* One of the 
									 *  VP1000_DR_BUFFER_ELEMENT_SIZE_X macros. */
    Vp1000_dr_buffer_size buffer_size;
									/* Shape and size of needed buffer. */
}; /* struct _Vp1000_dr_buffer_descriptor */

struct _Vp1000_dr_array_addressing
{
    Vp1000_dr_buffer_element subbuffer_min;
    Vp1000_dr_buffer_element subbuffer_max;
									/* Start and end of subbuffer in HW memory.
									 */
    Vp1000_dr_buffer_element offset_modulus;
									/* Used to locate the first element in the 
									 *  buffer to be accessed. */
	Vp1000_bool		wrap;			/* Boolean, if TRUE then use the
									 *  wrap feature of HW memory addressing. */
}; /* struct _Vp1000_dr_array_addressing */

struct _Vp1000_dr_lut_cache
{
	uint32	buffer_id;				/* ID of the allocated buffer in 
									 *  HW memory. */
	uint32	sequence_no;			/* library-app's change count for 
									 * L.U.T. data */
	uint16	valid_entries;			/* how deep is this L.U.T. */
}; /* struct _Vp1000_dr_lut_cache */

struct _Vp1000_dr_volimgdepth_entry
{
	uint32	buffer_id;				/* ID of the allocated buffer in 
									 *  HW memory. */
	Vp1000_dr_array_addressing	addr;
									/* sub buffer addressing */
}; /* Vp1000_dr_volimgdepth_entry */

struct _Vp1000_dr_all_buffers_data
{
	Vp1000_dr_volimgdepth_entry	volume;

	Vp1000_dr_volimgdepth_entry	image0;

	Vp1000_dr_volimgdepth_entry	image1;

	Vp1000_dr_volimgdepth_entry	depth0;

	Vp1000_dr_volimgdepth_entry	depth1;

	Vp1000_dr_lut_cache			classification_0;

	Vp1000_dr_lut_cache			classification_1;

	Vp1000_dr_lut_cache			classification_2;

	Vp1000_dr_lut_cache			classification_3;

	Vp1000_dr_lut_cache			specular_reflectance;

	Vp1000_dr_lut_cache			diffuse_reflectance;

	Vp1000_dr_lut_cache			gradient_magnitude;

	Vp1000_dr_lut_cache			alpha_correction;

}; /* struct _Vp1000_dr_all_buffers_data */

struct _Vp1000_dr_buffer_attach
{
   	Vp1000_def_int	status;			/* Results of the IOCTL.
									 */
	uint32	buffer_id;				/* ID of the allocated buffer in 
                                     *  HW memory.
                                     */
    Vp1000_def_int  permission_share;/* One or more of the 
                                     *  VP1000_DR_BUFFER_PERMISSION_SHARE_X
                                     *  macros.
                                     */
    Vp1000_dr_buffer_descriptor buffer_descriptor;
                                    /* Size and shape of requested buffer.
                                     */
}; /* struct _Vp1000_dr_buffer_attach */

struct _Vp1000_dr_buffer_detach
{
   	Vp1000_def_int	status;			/* Results of the IOCTL.
									 */
    uint32  buffer_id;              /* ID of the allocated buffer in 
                                     *  HW memory.
                                     */
}; /* struct _Vp1000_dr_buffer_detach */

struct _Vp1000_dr_buffer_load
{
   	Vp1000_def_int	status;			/* Results of the IOCTL.
									 */
	uint32	ret_load_event_id;		/* Unique ID for this load/unload request.
                                     */
    uint32  render_event_id;		/* ID of a render that this load/unload
                                     *  should synchronize on.
                                     *  VP1000_DR_INVALID_ID means do not sync.
                                     */
    uint32  previous_load_event_id; /* ID of a load/unload that this unload/load
                                     *  should synchronize on.
                                     *  VP1000_DR_INVALID_ID means do not sync.
                                     */
    uint32  buffer_id;              /* ID of the allocated buffer in 
                                     *  HW memory.
                                     */
	Vp1000_dr_array_addressing	addr;

    uint32  host_buffer_id;         /* Identifies the host memory that contains
                                     *  the data to be loaded into HW memory,
                                     *  or will receive the data unloaded from
                                     *  HW memory.  VP1000_DR_INVALID_ID means 
                                     *  use the host_buffer_address instead.
                                     */
	Vp1000_dr_ptr	host_buffer_address;
									/* User memory address.  Only used if 
                                     *  host_buffer_id is VP1000_DR_INVALID_ID.
                                     */
    Vp1000_dr_buffer_descriptor host_descriptor;
									/* dimensions of the host data
									 */
	Vp1000_def_int		element_alignment;		/* Byte position of the data from the host
                                     *  element within the HW data element.
                                     */
    Vp1000_dr_buffer_element host_subbuffer_min;
                                    /* Start of subbuffer in host memory.
                                     */
}; /* struct _Vp1000_dr_buffer_load */

struct _Vp1000_dr_buffer_map
{
   	Vp1000_def_int	status;			/* Results of the IOCTL.
									 */
    uint32  buffer_id;              /* ID of the allocated buffer in 
                                     *  HW memory.
                                     */
    uint32  map_id;                 /* ID of the mapping to the subbuffer in 
                                     *  HW memory.
                                     */
	Vp1000_def_int	access_share;	/* VP1000_DR_BUFFER_ACCESS_XXXX
									 */
	Vp1000_dr_array_addressing	addr; /* the addressing mode and range
									 * for the array */
    Vp1000_def_int	host_element_size;/* One of the 
                                     *  VP1000_DR_BUFFER_ELEMENT_SIZE_X macros.
                                     */
	Vp1000_def_int	element_alignment;/* Byte position of the data from the host
                                     *  element within the HW data element.
                                     */
	Vp1000_dr_ptr	user_address;	/* Address in host user virtual 
                                     *  memory space of the mapped HW buffer.
                                     */
    Vp1000_def_int     user_size;	/* Size in bytes of the virtual mapping in
                                     *  host user address space of the mapped
									 *  HW buffer. */
}; /* struct _Vp1000_dr_buffer_map */

struct _Vp1000_dr_buffer_unmap
{
   	Vp1000_def_int	status;			/* Results of the IOCTL.
									 */
    uint32  map_id;                 /* ID of the mapping to the subbuffer in 
                                     *  HW memory.
                                     */
	Vp1000_dr_ptr	user_address;	/* Address in host user virtual 
                                     *  memory space of the mapped HW buffer.
                                     */
    Vp1000_def_int	user_size;		/* Size in bytes of the virtual mapping in
                                     *  host user address space of the mapped
                                     *  HW buffer. */
}; /* struct _Vp1000_dr_buffer_unmap */

struct _Vp1000_dr_buffer_board2board
{
   	Vp1000_def_int	status;			/* Results of the IOCTL.
									 */
	uint32	src_ret_unload_event_id;/* Unique ID for src unload event.
                                     */

    uint32  src_render_event_id;	/* ID of a render that this unload
                                     *  should synchronize on.
                                     *  VP1000_DR_INVALID_ID means do not sync.
                                     */
    uint32  src_load_event_id;		/* ID of a load that this unload
                                     *  should wait for.
                                     */
    uint32  src_buffer_id;			/* ID of the allocated buffer in 
                                     *  HW memory.
                                     */
	Vp1000_dr_array_addressing	src_addr; /* addressing of source buffer
									 */
	uint32	dest_ret_load_event_id;	/* Unique ID for dest load request.
                                     */
    uint32  dest_render_event_id;	/* ID of a render that this load
                                     *  should synchronize on.
                                     *  VP1000_DR_INVALID_ID means do not sync.
                                     */
    uint32  dest_unload_event_id;	/* ID of an unload that this load
                                     *  should wait for.
                                     */
    uint32  dest_buffer_id;			/* ID of the allocated buffer in 
                                     *  HW memory.
                                     */
    Vp1000_dr_array_addressing dest_addr;
									/* addressing of destination buffer
									 * subbuffer_max - subbuffer_min must be
									 * greater or equal to the source addressing
                                     */
}; /* struct _Vp1000_dr_buffer_board2board */


struct _Vp1000_dr_hw_reset
{
   	Vp1000_def_int	status;			/* Results of the IOCTL.
									 */
	Vp1000_bool		mem_reset;		/* Boolean, if TRUE then clear HW memory
    								 * this will reset everything */
	Vp1000_bool		ctrl_reset;		/* Boolean, if TRUE then reset the render pipelines
    								 * this will reset the queues */
	Vp1000_bool		dmaIn_reset;	/* Boolean, if TRUE then reset the
									 * DMA In Command Queue */
	Vp1000_bool		render_reset;	/* Boolean, if TRUE then reset the
									 * Render Command Queue */
	Vp1000_bool		dmaOut_reset;	/* Boolean, if TRUE then reset the
									 * DMA Out Command Queue */
}; /* struct _Vp1000_dr_hw_reset */

struct _Vp1000_dr_host_buffer_alloc
{
   	Vp1000_def_int	status;			/* Results of the IOCTL.
									 */
    uint32  host_buffer_id;         /* ID of the allocated buffer in 
                                     *  user or kernel memory.
                                     */
	Vp1000_dr_ptr	user_address;	/* Address in host user virtual memory 
                                     *  space of the buffer.
                                     */
    Vp1000_def_int	user_size;		/* Size in bytes of the buffer.
                                     */
    Vp1000_def_int  permission_share;/* One or more of the 
                                     *  VP1000_DR_BUFFER_PERMISSION_SHARE_X
                                     *  macros, only used for kernel buffers. */
}; /* struct _Vp1000_dr_host_buffer_alloc */

struct _Vp1000_dr_host_buffer_free
{
   	Vp1000_def_int	status;			/* Results of the IOCTL.
									 */
    uint32  host_buffer_id;         /* ID of the allocated buffer in 
                                     *  user or kernel memory.
                                     */
	Vp1000_dr_ptr	user_address;	/* Address in host user virtual memory 
                                     *  space of the buffer.
                                     */
    Vp1000_def_int	user_size;		/* Size in bytes of the buffer.
                                     */
}; /* struct _Vp1000_dr_host_buffer_free */

struct _Vp1000_dr_kernel_buffer_map
{
   	Vp1000_def_int	status;			/* Results of the IOCTL.
									 */
    uint32  host_buffer_id;         /* ID of the allocated buffer in 
                                     *  kernel memory.
                                     */
    uint32  map_id;                 /* ID of the mapping to the buffer in 
                                     *  kernel memory.
                                     */
	Vp1000_dr_ptr	user_address;	/* Address in host user virtual 
                                     *  memory space of the mapped HW buffer.
                                     */
	Vp1000_def_int	user_size;		/* Size in bytes of the virtual mapping in
                                     *  host user address space of the mapped
                                     *  kernel buffer. */
}; /* struct _Vp1000_dr_kernel_buffer_map */

struct _Vp1000_dr_kernel_buffer_unmap
{
   	Vp1000_def_int	status;			/* Results of the IOCTL.
									 */
    uint32  map_id;                 /* ID of the mapping to the buffer in 
                                     *  kernel memory.
                                     */
	Vp1000_dr_ptr	user_address;	/* Address in host user virtual memory
                                     *  space of the mapped kernel buffer.
                                     */
	Vp1000_def_int	user_size;		/* Size in bytes of the virtual mapping in
                                     *  host user address space of the mapped
                                     *  kernel buffer. */
}; /* struct _Vp1000_dr_kernel_buffer_unmap */

struct _Vp1000_dr_render
{
   	Vp1000_def_int	status;			/* Results of the IOCTL.
									 */
    uint32  ret_render_event_id;	/* Unique ID for this render request.
                                     */
    uint32  lut_load_event_id;		/* ID of a load that must complete
                                     *  before any LUT's are loaded. */
    uint32  load_event_id;			/* ID of a load that this render
                                     *  should synchronize on. */
    uint32  unload_event_id;		/* ID of an unload that this render
                                     *  should synchronize on. */

	Vp1000_dr_ptr	pBufferData;	/* pointer to a Vp1000_dr_all_buffers_data struct
									 * with buffer IDs for 2D or 3D sources,
                                     * destinations, and the 8 LUTs and Maps.
                                     */
    Vp1000_dr_ptr	p_render_load_cmds;
    								/* pointer to an array of uint64 -
    								 * the LoadRegister commands that will
                                     *  start the render on the VP1000. */
	Vp1000_def_int	render_count;	/* Number of 64 bit entries in the HW
                                     *  graphics state. */

    uint32  prev_render_event_id;	/* ID returned for last render
									 * used to check if "state"
									 * needs to be re-loaded */
    Vp1000_dr_ptr	p_state_load_cmds;
    								/* pointer to an array of uint64 -
    								 * the LoadRegister commands that will
                                     *  set the graphics state of the VP1000. */
	Vp1000_def_int	state_count;	/* Number of 64 bit entries in the HW
                                     *  graphics state. */
	uint8	image_depth_dest[4];	/* Boolean, which image/depth buffers 
									 * are written to */
}; /* struct _Vp1000_dr_render */

struct _Vp1000_dr_event
{
    uint32  event_id;               /* Either a render_id or load_id
                                     */
	Vp1000_bool	event_occurred;		/* Boolean, if TRUE then this event
                                     *  occurred, if FALSE then it did not.
                                     */
}; /* struct _Vp1000_dr_event */

struct _Vp1000_dr_sync
{
   	Vp1000_def_int	status;			/* Results of the IOCTL.
									 */
	Vp1000_def_int	wait_status;	/* Results of the wait, either 
                                     *  VP1000_DR_SYNC_WAIT_STATUS_OCCURRED or
                                     *  VP1000_DR_SYNC_WAIT_STATUS_TIMEOUT.
                                     */
	Vp1000_def_int	selection;		/* VP1000_DR_SYNC_SELECTION_ANY or
									 * VP1000_DR_SYNC_SELECTION_ALL */
    Vp1000_def_int	timeout;		/* Maximum block time in milleseconds, or
                                     *  VP1000_DR_SYNC_TIMEOUT_POLL, or
                                     *  VP1000_DR_SYNC_TIMEOUT_FOREVER.
                                     */
	Vp1000_def_int	event_count;	/* How many events are in the list, no more
                                     *  than VP1000_DR_SYNC_EVENT_COUNT_MAX.
                                     */
	Vp1000_def_int	event_occurred_count;
									/* How many events occurred. */
    Vp1000_dr_event event_list[VP1000_DR_SYNC_EVENT_COUNT_MAX];
                                    /* List of events to wait for.
                                     */
}; /* struct _Vp1000_dr_sync */

struct _Vp1000_dr_abort
{
   	Vp1000_def_int	status;			/* Results of the IOCTL.
									 */
    uint32  event_id;               /* a render id, load id, or unload id
                                     */
}; /* struct _Vp1000_dr_abort */

struct _Vp1000_dr_board_select
{
   	Vp1000_def_int	status;			/* Results of the IOCTL.
									 */
	Vp1000_def_int	num_boards;		/* total boards supported */
	Vp1000_def_int	prefered_board;	/* which board should the client
									 * load volumes onto next */
}; /* struct _Vp1000_dr_board_select */



/*  VP1000_DR_IOCTL_PEERS_GET
 *
 * Returns a list of 'peer' devices.
 * Peer devices can comminucate without crossing
 * a PCI to PCI bridge. (i.e. they are on the same board.)
 * each entry is either -1 (no peer or peer unknown) or the
 * peer number of that board.
 *
 * For example, say we have two VP1000D and two VP1000 cards installed.
 * The first VP1000D occupies 'board' 0 and 1 and the second 3 and 4.
 * The two VP1000 cards are at 2 and 5.
 * The peer array will look like this:
 *
 * peer[0]: 1
 * peer[1]: 0
 * peer[2]: -1
 * peer[3]: 4
 * peer[4]: 3
 * peer[5]: -1
 * peer[6]: -1
 * peer[7]: -1
 *
 * enabled[board] is 1 for boards that are currently enabled and 0 for
 * those that are not present or disabled.
 *
 * Can be called for any board (for the same information.)
 */
struct _Vp1000_dr_board_peers
{
   	Vp1000_def_int	status;			/* Results of the IOCTL.
									 */
    Vp1000_def_int  peer[VP1000_DEVICE_MAX];
    Vp1000_def_int  enabled[VP1000_DEVICE_MAX];
}; /* struct _Vp1000_dr_configuration*/


/*  The data structure Vp1000_dr_configuration returns both HW and SW 
 *  configuration info.  The caller can check the HW characteristics to
 *  make sure it is the appropriate version, and the caller can check SW 
 *  version to make sure that device driver is compatible (with the caller).
 *
 *  To check compatibility call the VP1000_DR_IOCTL_CONFIGURATION_GET IOCTL
 *  with a variable of type Vp1000_dr_configuration.  Compare the returned 
 *  major_number to the compiled in VP1000_DR_VERSION_MAJOR_NUMBER, and
 *  compare the returned os_version to the compiled in VP1000_DR_VERSION_OS.
 *
 *  The major_number and os_version MUST MATCH their respective comparisons,
 *  or the device driver and calling software are not compatible.
 *
 *  The minor_number is used to track changes of this file that are not 
 *  significant enough to require a recompile.  VP1000_DR_VERSION_MINOR_NUMBER
 *  should be reset to 0 when the VP1000_DR_VERSION_MAJOR_NUMBER is incremented.
 *
 *  The micro_number is private to each device driver and is used to track
 *  changes to the device driver that do not require a change to this file.
 */
struct _Vp1000_dr_configuration
{
   	Vp1000_def_int	status;			/* Results of the IOCTL.
									 */
	Vp1000_def_int	pci_rev;		/* the Revision number from the
	                                 *  PCI configuration header
	                                 */
	Vp1000_def_int	memory_size;	/* amount of HW memory, in MB
	                                 */
	Vp1000_def_int	memory_size_pci;/* amount of HW memory available on the
	                                 *  PCI bus, in KB
	                                 */
	Vp1000_def_int	major_number;	/* Major version number of the device
	                                 *  driver
	                                 */
	Vp1000_def_int	minor_number;	/* Minor version number of the device
	                                 *  driver
	                                 */
	Vp1000_def_int	micro_number;	/* Micro version number of the device
	                                 *  driver
	                                 */
	Vp1000_def_int	os_version;		/* Operating System version number
	                                 */
	Vp1000_def_int	free_memory;	/* amount of free HW memory, in MB
									 */
	Vp1000_def_int	locked_memory;	/* amount of HW memory in use, in MB
									 */
/*	Vp1000_def_int			stale_memory;		 * amount of free HW memory that
									 * can still be re-attached, in MB */
}; /* struct _Vp1000_dr_configuration */

#ifdef VP1000_DR_COMPILE_DRIVER_VERSION

/* This macro MUST be defined in the Makefile or compilation environment.
 */
#ifndef VP1000_DR_VERSION_OS

#error Must define VP1000_DR_VERSION_OS in Makefile or compilation environment!

#endif /* VP1000_DR_VERSION_OS */

/* Declaration of device driver version info.
 */
Vp1000_dr_configuration vp1000_dr_configuration_compiled =
{
    0,                                  /* status
                                         */
    0,                                  /* pci_rev
                                         */
    0,                                  /* memory_size
                                         */
    0,                                  /* memory_size_pci
                                         */
    VP1000_DR_VERSION_MAJOR_NUMBER,     /* major_number
                                         */
    VP1000_DR_VERSION_MINOR_NUMBER,     /* minor_number
                                         */
    0,                                  /* micro_number
                                         */
	VP1000_DR_VERSION_OS,				/* os_version
										 *  This *must* be defined at compile
										 *  time by the Makefile or environment
										 */
	0,
	0
};
#endif /* VP1000_DR_COMPILE_DRIVER_VERSION */

/************************************************************************
 *
 *                            Functions
 *
 ************************************************************************/
#ifndef _KERNEL

void
vp1000_dr_open(
    char *              device_name,
    Vp1000_dr_handle *  dr_handle,
    int *               status );

void
vp1000_dr_ioctl(
    Vp1000_dr_handle    dr_handle,
    int                 command,
    void *              data );

void
vp1000_dr_close(
    Vp1000_dr_handle    dr_handle );

int
vp1000_dr_get_os_error( );

void
vp1000_app_open(
    char *                      device_name,
    int                         app_micro,
    Vp1000_dr_handle *          dr_handle,
    Vp1000_dr_configuration *   driver_configuration,
    int *                       status );

void
vp1000_reg_size_get(
    int     offset,
    int *   size );

uint64
atoi_hex(char * str);

void
vp1000_print_version(
    Vp1000_dr_configuration *   configuration,
    int     full_print,
    const char *  message );

void
vp1000_print_errors(
    int     status,
    const char *  message );

void
vp1000_print_debug_level(
    uint64  debug_level );

void
vp1000_print_buffer_lock(
    Vp1000_dr_buffer_attach * buffer_lock );

void
vp1000_print_host_buffer_alloc(
    Vp1000_dr_host_buffer_alloc * host_buffer_alloc );

void
vp1000_print_buffer_descriptor(
    Vp1000_dr_buffer_descriptor * buffer_descriptor );

void
vp1000_print_buffer_size(
    Vp1000_dr_buffer_size * buffer_size );

void
vp1000_print_kernel_buffer_map(
    Vp1000_dr_kernel_buffer_map * kernel_buffer_map );

void
vp1000_print_permission(
	Vp1000_def_int			permission_share );

#endif /* _KERNEL */

#if defined (__cplusplus)
};
#endif

#endif /* VP1000_DR_H_INCLUDED */
/************************************************************************
 *
 *                           End of File vp1000_dr.h
 *
 ************************************************************************/
