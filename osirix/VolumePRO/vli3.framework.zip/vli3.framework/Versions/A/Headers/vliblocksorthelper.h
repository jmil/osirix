#ifndef VLI_BLOCK_SORT_HELPER_H
#define VLI_BLOCK_SORT_HELPER_H

/******************************************************************************
 *
 * $Id: vliblocksorthelper.h,v 1.4 2004/10/19 17:07:02 vesper Exp $
 *
 *
 *	  BlockSortHelper class -- used by space leaping code
 *
 *    Copyright 2002,2003,2004 by Real Time Visualization, TeraRecon, Inc.
 *    All Rights Reserved.  
 *****************************************************************************/

#define dDebugSizes 0
#define dDebugOrderArraySet	0

enum DumpFlags
{
	eDumpRenderOrderMatrix	= 1,
	eDumpSortedGroup		= 2,
	eDumpCycles				= 4,
	eDumpAncestors			= 8,
	eDumpVisited			= 16,
	eDumpBeforeCounts		= 32,
	eDumpContainingCycles	= 64,

	eDumpDefault			= (eDumpVisited | eDumpBeforeCounts),
	eDumpAll				= 127
};

enum VGRenderOrder
{
	kNoneDefine=0,
	kBeforeNoConflict = -5,
	kBeforeXConflict = -4,
	kBeforeYConflict =-3,
	kBeforeZConflict =-2,
	kContaining = -1,
	kOverlapping =1,  
	kAfterZConflict = -kBeforeZConflict,
	kAfterYConflict = -kBeforeYConflict,
	kAfterXConflict = -kBeforeXConflict,
	kAfterNoConflict= -kBeforeNoConflict
	
#if dDebugOrderArraySet
	, 	kClear = 1000
#endif
};

typedef std::vector<TVectorInt> TCycleList;

class PerBlockInfo
{
public:
	bool		visited;
	int			blocksBeforeThis;
	TVectorInt	containingCycles;		// on which m_cycles is this block contained
};

static const int kBlockHasBeenSorted = -100;

// m_orderMatrix is a matrix of M x M, but it is symmetric about
// the major axis, so we only need to store the upper right matrix. 
// Also, the major axis (i == j) does not need to be
// stored, since it is always kNoneDefine. 

// The total size needed for m_orderMatrix is M*(M-1)/2

// The size for row i is (M - i - 1). 
// The index of the first element of row i (which is element i, i+1) is
// the sum of the elements of rows 0 to i - 1: 
//		 sum(k=0 to i-1) (M - k - 1)
// or	{sum(k=0 to i-1) (M - 1)} - {sum(k=0 to i-1) (k)}
// or	(M-1)*(i-1+1)             - {sum(k=0 to i) (k)}
// or   (M-1)*(i)                 - (i-1)(i)/2


class BlockSortHelper
{
public:
	BlockSortHelper (int inMaxRenderBlock);
	~BlockSortHelper ();

	void			Reset (int inNumberBlocks);
	int &			CurrentNumberBlocks (void) { return m_numberBlocks; }	// note - read/write!
	int 			MaxBlocks (void) { return m_maxBlocks; }

	void			DumpInfo (const char * condition, const char * where, int dumpFlags, int lineNumber, const char * fileName) const;

	// Order Matrix operations

	VGRenderOrder	RenderOrder (int i, int j) const;	// order of i and j
	bool			IsBefore (int i, int j) const;	// true if i must come before j
	bool			IsAfter  (int i, int j) const;	// true if i must come after j
	bool			IsConflict ( int inBlockI, int inBlockJ, int inBlockK, VGRenderOrder IJCompare) const;
	bool			IsPossibleConflict (int inBlockI, int inBlockJ, VGRenderOrder & outIJCompare) const;
	bool			FindConflict( int &blockI, int &blockJ, int &blockK) const;
	void			ClearOrderMatrix (void);

	friend void VLIVolumeInternal::ComputeRenderOrderMatrix(int option, BlockSortHelper & helper);
	friend void VLIVolumeInternal::RecomputeRenderOrderMatrix(int splitBlock, int newBlock, int option, BlockSortHelper & helper);

	// Per block information handling

	//     How many blocks must be rendered before this block?

	void			ComputeAllBeforeCounts (void);
	void			ComputeGroupBeforeCounts (const TVectorInt & group);
	int				BlocksBeforeThis (int inBlock) const
					{
					#if dDebugSizes
						VLI_ASSERT (inBlock >= 0 && inBlock < m_maxBlocks);
					#endif
						return m_blockInfo[inBlock].blocksBeforeThis;
					}

	void			MarkBlockSorted (int inBlock);	// Decrements other blocks' before counts
	void			MarkBlockSorted (int inBlock, const TVectorInt & group);	// Decrements before counts for the blocks in group
	void			DecrementBeforeCounts (const TVectorInt & group);

	//     Has this block been visited?

	bool			BlockVisited (int inBlock) const
					{
					#if dDebugSizes
						VLI_ASSERT (inBlock >= 0 && inBlock < m_maxBlocks);
					#endif
						return m_blockInfo[inBlock].visited;
					}
	void			SetBlockVisited (int inBlock)
					{
					#if dDebugSizes
						VLI_ASSERT (inBlock >= 0 && inBlock < m_maxBlocks);
					#endif
						m_blockInfo[inBlock].visited = true;
					}

	//		Which m_cycles contain a block?

	int				NumberCyclesContaining (int inBlock) const
					{
					#if dDebugSizes
						VLI_ASSERT (inBlock >= 0 && inBlock < m_maxBlocks);
					#endif
						return (int) m_blockInfo[inBlock].containingCycles.size();
					}

	const TVectorInt & CyclesContaining (int inBlock) const
					{
					#if dDebugSizes
						VLI_ASSERT (inBlock >= 0 && inBlock < m_maxBlocks);
					#endif
						return m_blockInfo[inBlock].containingCycles;
					}

	void			AddCycleToBlock (int inBlock, int inCycle);

	int				NumberCycles (void) const
					{
						return (int) m_cycles.size();
					}

	// Sorted group operations

	void			StartGroup (void);
	void			AddToSortedGroup (int inBlock);
	const TVectorInt & SortedGroup (void) const { return m_sortedGroup; }
	void			EraseBlockCycleFlag (int cycle);
	void			MarkGroupSorted (void);

	void			CreateCycleFromAncestors (int inBlock);
	void			AddCrossCycles (int inBlock);

	const TVectorInt & Cycle (int inCycleIndex) const
					{
					#if dDebugSizes
						VLI_ASSERT (inCycleIndex >= 0 && inCycleIndex < NumberCycles() );
					#endif
						return m_cycles[inCycleIndex];
					}

	bool			BlockSortHelper::IsAnAncestor (int inBlock) const
					{ 
						return std::find(m_ancestors.begin(), m_ancestors.end(), inBlock) != m_ancestors.end() ; 
					}

	void			AddToAncestors (int inBlock)
					{
						m_ancestors.push_back(inBlock);
					}

	void			PopAncestor (void)
					{
						m_ancestors.pop_back ();
					}

private:

	// Per above, the index of the start of row i is the index of (i,i+1), which is (M-1)*i - (i-1)(i)/2
	// m_orderMatrixMultiplier is (M-1).
	// index of (i,j) for i+1 <= j < M is the above + j - (i+1)
	int				OrderMatrixIndex (int i, int j)	const	// i < j !
	{
		VLI_ASSERT (i < j);
		int index = m_orderMatrixMultiplier * i - (i-1)*i/2 + j - i - 1;
#if dDebugSizes
		VLI_ASSERT (index >= 0 && index < m_orderMatrixSize);
#endif
		return index;
	}
	VGRenderOrder	SetRenderOrder (VGRenderOrder inValue, int i, int j);
	VGRenderOrder	ComputeRenderOrder (int index1Start[3], int index1End[3], int index2Start[3], int index2End[3]);

	int				m_orderMatrixMultiplier;
	int				m_orderMatrixSize;
	int				m_maxBlocks;

	int				m_numberBlocks;

	VGRenderOrder *	m_orderMatrix;

	PerBlockInfo *	m_blockInfo;
	TVectorInt		m_sortedGroup;
	TCycleList		m_cycles;
	TVectorInt		m_ancestors;

};


#endif // VLI_BLOCK_SORT_HELPER_H
