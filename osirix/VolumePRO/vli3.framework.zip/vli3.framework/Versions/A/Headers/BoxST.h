/*
 * $Id: BoxST.h,v 1.3 2002/10/23 15:38:05 vesper Exp $
 *
 *    Copyright 2002 by Real Time Visualization, TeraRecon, Inc.
 *    All Rights Reserved.
 *
 */  
// BoxST.h - Box in s, t
// After calculating BoxST3H, create a BoxST, then proceed
#ifndef BOXST_H
#define BOXST_H

class BoxST {
public:

  // Constructor
  BoxST ();
  BoxST (const PointST &inPoint);
  BoxST (const PointST &inMin, const PointST &inMax);
  BoxST (double inMinS, double inMinT, double inMaxS, double inMaxT);
  BoxST (const Box2D &inBox);

  // Operate on the Box
  void Update (double &inS, double &inT);
  void Update (const PointST &inPt);

  // Return whether a point is outside the box
  bool OutSide (float  inX, float  inY) const;
  bool OutSide (double inX, double inY) const;

  // Get/Put
  PointST GetMin (void) const;
  PointST GetMax (void) const;
  double GetMinS (void) const;
  double GetMinT (void) const;
  double GetMaxS (void) const;
  double GetMaxT (void) const;

  void SetMin (const PointST &inPoint);
  void SetMax (const PointST &inPoint);
  void SetMinS (double &inS);
  void SetMinT (double &inT);
  void SetMaxS (double &inS);
  void SetMaxT (double &inT);

  // Return a Box2D version of the Object
  Box2D GetBox2D (void) const;


  // Print
  // Print the BoxST
  void Print (void) const;

private:

  // One Point stores the Min, one stores the Max
  PointST m_min, m_max;
};
#endif
