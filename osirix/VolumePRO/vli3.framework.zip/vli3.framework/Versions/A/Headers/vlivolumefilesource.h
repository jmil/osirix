/*
 * $Id: vlivolumefilesource.h,v 1.2 2001/05/14 13:06:20 vesper Exp $
 *
 *	This file describes two related classes, VLIVolumeFileSource
 *	and VLIVolumeFile. The latter is derived from the former, and
 *	adds routines to write a file.
 *
 *  The VLIVolumeFileSource class is an pure abstract class that defines
 *  a plug-in architecture that would ultimately allow the application 
 *  (and VLI) to handle infinite volumes stored in files. There is
 *  no assumption made about how the volume is stored, but it is
 *	expected that the volume is stored in some sort of random-access
 *	storage---simply called a file below.
 *
 *  Each file can contain header information plus multiple volumes.
 *	Each volume can have descriptive information, plus multiple
 *	data sets. One data set must be the voxel data, which can have
 *	multiple fields. The fields are described in the per-volume
 *	descriptive information.
 *
 *	The term 'implementation' is used below to mean the derived
 *	class that implements this interface.
 */

enum VLIFieldType
{
	kVLIUnsigned,		// field is an index; expand by filling in on the left with zeros
	kVLIFloat,			// field is floating point (width must be 32 or 64)
	kVLIFraction		// field represents a fraction from 0 to 1, inclusive.
						// the value is v/((1<<width) - 1)
};

struct VLIFieldInfo
{
	int				position;	// from the least significant bit, in bits
	int				width;		// in bits
	VLIFieldType	type;
	char			* name;		// one word name---required
	char			* description;	// longer string---may be 0 (NULL)
	double			offset;
	double			scale;
};

class VLIVolumeFileSource : public VLIVolumeSource
{
public:

	// No constructor, this is an abstract class

	// virtual destructor
	virtual ~VLIVolumeFileSource (void) = 0;

	// File open and close routines

	virtual VLIStatus OpenFile(char * inFileName, VLIVolume::ReadMode inReadMode) = 0;
	virtual VLIStatus CloseFile (void) = 0;

	// File information.

	virtual int GetNumberOfVolumes (void) = 0;	// If this returns 0, the number is not available
												// If this returns -1, there was an error

	// Volume information. Volume numbers start at 0. 

	// These routines return -1 to report an error.
	virtual int GetVolumeSize (int &outSizeX, int &outSizeY, int &outSizeZ) = 0;
	virtual int GetVolumeVoxelSize (int inVolume) = 0;
	virtual int GetNumberOfFields (int inVolume) = 0;	
	virtual int GetFieldNumber (int inVolume, char * name) = 0;

	// This routine returns 0 to report an error.
	virtual VLIFieldInfo *GetFieldInfo (int inVolume, int inFieldNumber) = 0;

	// These routines report optional information. They return -1
	// to report an error. This data is not used by VLI.
	virtual int GetVolumePosition (int inVolume, double &outPositionX, double &outPositionY, double &outPositionZ) = 0; 
	virtual int GetVolumeOffset (int inVolume, double &outOffsetX, double &outOffsetY, double &outOffsetZ) = 0; 

	// This routine returns an identity matrix if there is no data in the file
	virtual VLIMatrix & GetVolumeModelMatrix (int inVolume) = 0;

	// File or Volume information. If inVolume == -1, return
	// information applicable to the entire file, else return
	// information applicable to the specified volume. If the
	// requested information is not available, these routines
	// return 0. Attribute and dataset names are case sensitive,
	// and should consist of ASCII printable text only, no blanks.
	// Underscores and hyphens may be used, for example, Channel_0
	// and Frequence-range-10.

	// It is up to the implementation to decide if multiple attributes
	// with the same name are combined or not, and what value
	// should be returned when the 'by name' version of GetAttribute
	// is called.

	// Dataset 0 is always the voxel dataset, with name "Voxel".
	// No other dataset is permitted to have the same name.
	// Datasets are never combined, even when they have the same
	// name. It is up to the implementation to decide what should be
	// returned when the 'by name' version of GetData is called.0

	virtual char * GetAttributeName (int inVolume, int inAttributeNumber) = 0;
	virtual char * GetDatasetName (int inVolume, int inDatasetNumber) = 0;
	virtual char * GetAttribute (int inVolume, int inAttributeNumber) = 0;
	virtual char * GetAttribute (int inVolume, char * inAttributeName) = 0;
	virtual void * GetDataset (int inVolume, int inDatasetNumber, int &outDatasetSizeInBytes) = 0;
	virtual void * GetDataset (int inVolume, char * inDatasetName, int &outDatasetSizeInBytes) = 0;

	// Specialized GetAttribute routines (needed?)
	// Or, static const char * kVLIAttributeCopyright = "Copyright";
	//     static const char * kVLIAttributeTitle = "Title";
	virtual char * GetCopyright (int inVolume) = 0;
	virtual char * GetTitle (int inVolume) = 0;

	// Select a volume to use. This resets the voxel mapping
	// to the identity mapping.

	virtual VLIStatus SelectVolume (int inVolume) = 0;

	// Describe the mapping from file voxel data to the volume
	// to be returned. This can be used to select which field(s)
	// need to be part of the voxel as delivered to the VLIVolumeSource
	// interface. SelectVoxelFile can be called multiple times to
	// build a multi-field delivered voxel.

	virtual VLIStatus SelectVoxelSize (int inSize) = 0; // How big the delivered voxels should be
	virtual VLIStatus SelectVoxelField (int inDeliveredField,
										int inDeliveredSize,
										int inDeliveredOffset,
										int inSourceField) = 0;

};

// The VLIVolumeFile class can write a new file

class VLIVolumeFile : public VLIVolumeFileSource
{

	enum EndianType
	{
		kVLIEndianHost,
		kVLIEndianLittle,
		kVLIEndianBig
	};

	virtual ~VLIVolumeFile(void) = 0;

	// Create a new file from scratch

	virtual VLIStatus CreateNewFile (const char * inNewFileName) = 0;

	// Modify an existing file in place. Only Datasets can be modified.

	// New volumes may be appended. If the file header field
	// NumberOfVolumes is not zero, the file may not be usable.

	virtual VLIStatus ModifyExistingFile (const char * inExistingFileName) = 0;

	// Create a new file based on an existing file

	virtual VLIStatus CreateNewFileFromExisting (const char *inNewFileName, const char *inExistingFileName) = 0;

	// These routines must be called in the appropriate order
	// Begin/EndFileHeader must be called once, and before any
	// calls to Begin/EndVolumeDescriptor

	// If inNumberOfVolumes is 0, this implies the number is not known.

	virtual VLIStatus BeginFileHeader (int inNumberOfVolumes) = 0;
	virtual VLIStatus EndFileHeader (void) = 0;

	virtual VLIStatus BeginVolumeDescriptor (EndianType inEndian) = 0;
	virtual VLIStatus EndVolumeDescriptor (void) = 0;

	// The following routines may be called while writing
	// either the file header or any volume descriptor---i.e. between 
	// BeginFileHeader and EndFileHeader, or between BeginVolumeDescriptor
	// and EndVolumeDescriptor.

	// These may be called any number of times in the block.

	// Strings may consist of multiple catenated lines with newlines
	// separating the lines. These will be split apart into
	// multiple lines in the output file, suitably formatted.

	// Names must be one word.

	// PutDataset does NOT copy the data, but saves the pointer and size
	// until the end of the section (EndFileHeader or EndVolumeDescriptor).
	// The data is written out at that point.

	virtual VLIStatus PutCopyright (const char * inString) = 0;
	virtual VLIStatus PutTitle (const char * inString) = 0;
	virtual VLIStatus PutComment (const char * inString) = 0;
	virtual VLIStatus PutAttribute (const char * inName, const char * inString) = 0;
	virtual VLIStatus PutDataset (const char * inName, int inSizeInBytes, const void * inData) = 0;

	// The following routines must be called while writing a
	// volume descriptor---between BeginVolumeDescriptor and EndVolumeDescriptor.

	virtual VLIStatus PutVolumeSize (int inSizeX, int inSizeY, int inSizeZ) = 0;
	virtual VLIStatus PutVoxelSize (int inVoxelSizeInBits) = 0;
	virtual VLIStatus PutVolumePosition (double inPositionX, double inPositionY, double inPositionZ) = 0;
	virtual VLIStatus PutVolumeScale (double inScaleX, double inScaleY, double inScaleZ) = 0;
	virtual VLIStatus PutVolumeModelMatrix (VLIMatrix &inMatrix) = 0;

	// PutVoxelField will output offset if not 0.0, and scale if not 1.0
	virtual VLIStatus PutVoxelField (VLIFieldInfo &inField) = 0;

	// There must be exactly one call to the following routines
	// in a volume descriptor:
	//		PutVolumeSize
	//		PutVoxelSize
	//		PutDataset (kVLIDatasetVoxel...)

	// There may be zero or one calls to the following routines
	// in a volume descriptor:
	//		PutVolumePosition
	//		PutVolumeScale
	//		PutVolumeModelMatrix

	// There may be zero or more calls to PutVoxelField in a volume
	// descriptor. If there are now such calls, a single field with
	// size set to the voxel size, and position set to 0, will be
	// automatically generated.

	// These routines may be used to help generate a new file from 
	// an existing one. It will preserve the order of comments,
	// attributes, etc., but it does NOT copy the number of volumes
	// to the new file. It is called instead of BeginFileHeader().

	virtual VLIStatus CopyFileHeader (char * inSourceFile, int & outNumberOfSourceVolumes);
	virtual VLIStatus PutNumberOfVolumes (int inNumberOfVolumes);

	// 


};
