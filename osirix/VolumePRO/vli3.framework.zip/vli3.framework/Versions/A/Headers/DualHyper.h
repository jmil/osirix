/*
 * $Id: DualHyper.h,v 1.7 2003/03/01 00:32:11 fadden Exp $
 *
 *    Copyright 2002 by Real Time Visualization, TeraRecon, Inc.
 *    All Rights Reserved.
 *
 */  
// Dual Hyperbolic Class Definition

#ifndef DUALHYPER_H
#define DUALHYPER_H

#define HYPER_EPSILON 1e-9
#define HYPER_BIGNUM  1e9

class DualHyper {
public:

  // Constructors
  DualHyper ();

#ifdef NEVER
  DualHyper (Plane &inPlane, Vector3D &inS, Vector3D &inT);
  DualHyper (Plane &inPlane, PolygonST3H &inPoly);
#endif

  // Normal DualHyper constructed using a Transformed Polygon with S,T at vertices
  DualHyper (PolygonST3H &inPoly);

  // DualHyper constructed from an Inverse Transformation Matrix, the side from
  //  which we are viewing, and the Slice "number" of the Plane of the DualHyper
  DualHyper (Mat44 &inInvPmvMat, int inNearSide, double inSlice);

#ifdef NEVER

  // Set partial state of the DualHyperbolic instance
  // Set Depth for the Denominator using a Normal Vector and a Point on the Plane
  void SetDepth (Vector3D &inNorm, Point3D &inVert);

  // Set Depth for the Denominator using the Plane of the surface
  void SetDepth (Plane3D &inPlane);
#endif

  // Conversion operators

  // Return the hyperbolic as a matrix
  operator VLIMatrix()
  {
	return VLIMatrix(S.x, S.y, 0, S.c,
					 T.x, T.y, 0, T.c,
					 0,   0,   1, 0,
					 D.x, D.y, 0, D.c);
  }

  // Evaluate

  // Given a VertexST3H, return a different VertexST3H (x,y,z,w,s,t)
  PointST3H EvalST (const PointST3H &inPoint);

  // Given a VertexST3H, return a PointST (s,t)
  PointST Eval (const PointST3H &inPt);

  // Given a Point2D (x,y), return a PointST (s,t)
  PointST Eval (const Point2D &inPt);

  // Given a Point, x, y, return a PointST (s,t)
  PointST Eval (double &x, double &y);

  // Given x,y, give s,t
  void Eval (double &x, double &y, double &s, double &t);

  // Given x,y, give s
  double EvalS (double &x, double &y);

  // Given x,y, give t
  double EvalT (double &x, double &y);

  // Calculate Gradient of the DualHyper S and T Functions at a point (x,y)
  //  Rate of change in the direction of maximum change for the functions S(x,y),
  //  and T(x,y), evaluated at a point (x,y)
  // Scale in X,Y accounts for screen scaling, up from NDC coordinates
  void GradST (double inX, double inY, double &outGradS, double &outGradT, 
               double inScaleX = 1.0, double inScaleY = 1.0);

private:
  
  // Flags indicating backfacing and edge-on condition (skip face)
  bool backFacing, skipFace;

  // Two Linear Numerators, one Linear Denominator
  Linear2D S, T, D;
};
#endif
