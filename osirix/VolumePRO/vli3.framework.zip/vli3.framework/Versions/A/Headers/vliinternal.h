#ifndef VLIINTERNAL_H
#define VLIINTERNAL_H

/******************************************************************************
 *
 * $Id: vliinternal.h,v 1.251 2004/10/22 15:36:08 vesper Exp $
 *
 *
 *	 Routines that are used by VLI that is not exposed to the user.
 *
 *    Copyright 1998, 1999, 2000 by Mitsubishi Electric Information Technology 
 *    Center America, Real Time Visualization. All Rights Reserved
 *
 *    Copyright 2001,2002,2003,2004 by Real Time Visualization, TeraRecon, Inc.
 *    All Rights Reserved.  
 *****************************************************************************/

// Disable the spurious "identifier was truncated to '255' characters" warning
#ifdef _MSC_VER
#pragma warning (disable : 4786)
#endif

// Standard header files needed

#include <math.h>
#include <string>

#include "vli.h"

#include "Threads.h"

#include "vgbwrapper.h"
#include "vlisamplespace.h"
#include "VLIAllRenderRegisters.h"
#include "VLIRational.h"
#include "vliperspective.h"
#include "vliversion.h"
#include <functional>

#ifndef NULL
#define NULL	0
#endif

#define START_NAMESPACE_VLI3	namespace vli3 {
#define END_NAMESPACE_VLI3		}


// Parameters to affect the way VLI is built or the way
// VLI runs. qNames can be defined as 0 or 1,
// or even with an expression.

#define qTracing				0	// Enable tracing code

#ifndef qUsePerformanceCounter
#ifdef _WIN32
#define qUsePerformanceCounter	1	// Use the Win32 performance counter
#else
#define qUsePerformanceCounter	0
#endif
#endif

#define qWorldSpaceOpacity		1

// If "new" throws bad_alloc or xalloc or something else,
// we want to catch that. Define qNewThrowsException as 1
// to compile in the try/catch code.

#define qNewThrowsException	0

// Currently defining qNewNoThrow does not work correctly;
// I guess we are not using the right header file.

#define qNewNoThrow			0

#define qSharedLUT			1

// define qEnablePerspective from vliversion.h

#define qEnablePerspective	VLI_VERSION_ADVANCED

// Do we want to separate registers based on what has changed
// since last time?

// AFV: disabled to avoid render hangs.

#define qSeparateStateAndRenderBlocks	0

// define qEnableDynamicCast to 0 by default, but allow compiler switch
// to override.

// AFV 7/16/03: default changed to 0 

#ifndef qEnableDynamicCast
#define qEnableDynamicCast		0
#endif

// Do we want to check VLIVolumeInternal host buffer usage?
#define dCheckHostBufferUsage	dDebug


#define qOptimizeTrimViewFrustum		1


// StartUpdateBuffer methods to try

enum UpdateMethod
{
	eMethodMap = 0,
	eMethodCopy,
	eMethodMapCopy,		// Map aligned, copy unaligned
	eMethodKernel,
	eMethodOneMap,
	eMethodOneCopy,

	eMethodMin = eMethodMap,
	eMethodMax = eMethodOneCopy
};

#define qCheckValidRange		1

// Debug flags. 
// dDebug is the basic debug/release switch, and
// other flags can be defined using it as needed.

#ifdef _DEBUG
#define		dDebug		1
#else
#define		dDebug		0
#endif

#define dAssert			1

#define dDebugErrTransform	0
#define dDebugErrors		dDebug		// Also set VLITraceErrors environment

#define dDebugMipmap		0
#define dDebugMultiboard	0
#define dDebugRenderHangFix	0

#ifndef dDebugDynamicCast
#define	dDebugDynamicCast	0
#endif

#define dDebugShareable		0

#if dDebugShareable > 1		// extra shareable debugging
#undef qEnableDynamicCast
#define qEnableDynamicCast	0
#endif

#define dDebugValidRange	dDebug

// Moved here from vgbwrapper.cpp
#define dDumpOnCommand		dDebug
#define dDebugDumpOnCommand 0

typedef size_t				VliAddress_t;	// arithmetic type large enough to hold an address

#include <vector>
typedef  std::vector<int> TVectorInt;

#if  ( defined(RTVIZ_COMPILER_GNU      ) && (RTVIZ_COMPILER_MAJOR== 3) && (RTVIZ_COMPILER_MINOR==0) ) \
	|| ( defined(RTVIZ_COMPILER_GNU      ) && (RTVIZ_COMPILER_MAJOR== 3) && (RTVIZ_COMPILER_MINOR==2) ) \
	|| ( defined(RTVIZ_COMPILER_MICROSOFT) && (RTVIZ_COMPILER_MAJOR== 7) && (RTVIZ_COMPILER_MINOR== 10) ) 


#define VLI_FUNCTION_NAME	__FUNCTION__
#endif

#if defined (VLI_FUNCTION_NAME)

#define VLI_SET_FUNCTION_NAME(name_) /* nothing */

#else

#define VLI_FUNCTION_NAME	0

#define VLI_SET_FUNCTION_NAME(name_) \
	const char VLI_FUNCTION_NAME[] = (name_);

#endif

#if dAssert
void VliAssert(const char *, const char *, unsigned int, const char *);

#define VLI_ASSERT(exp_) (void)( (exp_) || (VliAssert(#exp_, __FILE__, __LINE__, VLI_FUNCTION_NAME), 0) )

#else

#define VLI_ASSERT(exp_) ((void)0) /* nothing */

#endif

#if dAssert && dDebug
#define VLI_DEBUG_ASSERT(exp_) (void)( (exp_) || (VliAssert(#exp_, __FILE__, __LINE__, VLI_FUNCTION_NAME), 0) )
#else
#define VLI_DEBUG_ASSERT(exp_) ((void)0) /* nothing */
#endif

#if dDebugErrors
extern void VliTraceReturnError (VLIStatus status, const char * fileName, int line, const char * functionName);
extern void VliTraceReportMessage (const char * message, const char * fileName, int line, const char * functionName);
extern void VliTraceReportStatus (VLIStatus status, const char * fileName, int line, const char * functionName);
extern void VliTraceReportMessageStatus (const char * message, VLIStatus status, const char * fileName, int line, const char * functionName);
extern void VliTraceReturnEvent (VLISyncEvent ev, const char * fileName, int line, const char * functionName);
extern void VliTraceThrowError (VLIStatus status, const char * fileName, int line, const char * functionName);

// Note -- copy error status or event right away so that these macros can
// be used with an expression for an argument. For example:
// VLI_RETURN_ERROR ( StartUpdate (args...).Wait() );

// AFV -- the name should really be VLI_RETURN_STATUS.

#define VLI_RETURN_ERROR(err_) \
do { VLIStatus e_r_r_ = (err_);if (gVLIControl.m_traceErrors && VLIFailed(e_r_r_)) \
	VliTraceReturnError (e_r_r_, __FILE__, __LINE__, VLI_FUNCTION_NAME); \
	return (e_r_r_); } while (0)

#define VLI_REPORT_ERROR_MESSAGE(message_) \
do { if (gVLIControl.m_traceErrors) \
	VliTraceReportMessage (message_, __FILE__, __LINE__, VLI_FUNCTION_NAME); \
	} while (0)

#define VLI_REPORT_ERROR_STATUS(err_) \
do { VLIStatus e_r_r_ = (err_);if (gVLIControl.m_traceErrors && VLIFailed(e_r_r_)) \
	VliTraceReportStatus (e_r_r_, __FILE__, __LINE__, VLI_FUNCTION_NAME); \
	} while (0)

#define VLI_REPORT_ERROR_MESSAGE_STATUS(message_,err_) \
do { VLIStatus e_r_r_ = (err_);if (gVLIControl.m_traceErrors && VLIFailed(e_r_r_)) \
	VliTraceReportMessageStatus (message_, e_r_r_, __FILE__, __LINE__, VLI_FUNCTION_NAME); \
	} while (0)

#define VLI_RETURN_EVENT(ev_) \
do { VLISyncEvent e_v_ = (ev_); VLIStatus e_r_r_ = (e_v_).Status();if (gVLIControl.m_traceErrors && VLIFailed(e_r_r_)) \
	VliTraceReturnEvent (e_v_, __FILE__, __LINE__, VLI_FUNCTION_NAME); \
	return (e_v_); } while (0)

// Don't use VLI_THROW_ERROR unless you know it is an error
#define VLI_THROW_ERROR(err_) \
do { VLIStatus e_r_r_ = (err_); \
	if (gVLIControl.m_traceErrors) \
		VliTraceThrowError (e_r_r_, __FILE__, __LINE__, VLI_FUNCTION_NAME); \
	throw (e_r_r_); \
} while (0)

#else // Not tracing errors

#define VLI_RETURN_ERROR(err_) return (err_)
#define VLI_REPORT_ERROR_MESSAGE(message_) do { /* nothing */ ; } while (0)
#define VLI_REPORT_ERROR_STATUS(err_) do { /* nothing */ ; } while (0)
#define VLI_RETURN_EVENT(ev_) return (ev_)
#define VLI_REPORT_ERROR_MESSAGE_STATUS(message_,status_) do { /* nothing */ ; } while (0)
#define VLI_THROW_ERROR(err_) \
do { VLIStatus e_r_r_ = (err_); \
	throw (e_r_r_); } while (0)

#endif // not tracing errors


#define VLI_RETURN_IF_ERROR(err_) \
do {VLIStatus e_r_r_2_ = (err_); if (VLIFailed(e_r_r_2_)) VLI_RETURN_ERROR (e_r_r_2_); } while (0)

#define VLI_RETURN_EVENT_IF_ERROR(ev_) \
do {VLISyncEvent e_v_ = (ev_);VLIStatus e_r_r_ = (e_v_).Status(); \
    if (VLIFailed(e_r_r_)) VLI_RETURN_EVENT (e_v_); } while (0)

#define VLI_THROW_IF_ERROR(err_) \
do { VLIStatus e_r_r_3_ = (err_); \
	if (VLIFailed(e_r_r_3_)) VLI_THROW_ERROR (e_r_r_3_); \
} while (0)

#if qEnableDynamicCast	// Really using dynamic_cast

#if dDebugDynamicCast

template <class T, class S>
inline T * doDynamicCast (S * inSource, T * dummy, const char * sname, const char * dname)
{
	T * ret = dynamic_cast<T *> (inSource);
	VLIOutputMessage ("#DC# %p = dynamic_cast<%s>(%s %p)\n",
					(void *) ret, dname, sname, (void *) inSource);
	return ret;
}

#define DYNAMIC_CAST(type_, mods_, source_)				\
	doDynamicCast (source_, (type_ mods_) 0, # source_, # type_ ## # mods_)

#else // not debugging

#define DYNAMIC_CAST(type_, mods_, source_)	\
	dynamic_cast<type_ mods_> (source_)

#endif // end not debugging

#define SET_OBJECT_TYPE(object_, type_)	\
do { /* nothing */ ; } while (false)

#else // poor man's dynamic cast

static const int kObjectTypePosition = 56;
static const VLISerialNumber kObjectTypeMask = (VLISerialNumber(0xff) << kObjectTypePosition);

typedef enum
{
	kObjectTypeVLIContextInternal =	0x10,
	kObjectTypeVLICutPlaneInternal,
	kObjectTypeVLILightInternal,
	kObjectTypeVLILookupTableInternal,
	kObjectTypeVLISimpleLookupTable = kObjectTypeVLILookupTableInternal,
	kObjectTypeVLILinearLookupTable,
	kObjectTypeLightMap,
	kObjectTypeVLILookupTableCache,

	kObjectTypeVLIVolumeSourceMemory =	0x90,
	kObjectTypeVLIVoxFileReader,

	kObjectTypeVLIVolumeInternal =		0xa0,
	kObjectTypeVLIMipmapVolume,
	kObjectTypeVLIMultiboardVolumePhase1,
	kObjectTypeVLIMultiboardVolumePhase2,

	kObjectTypeVLIImageBufferInternal = 0xb0,
	kObjectTypeVLIOmniImageBuffer,

	kObjectTypeVLIDepthBufferInternal = 0xc0,
	kObjectTypeVLIOmniDepthBuffer
} VLIObjectType;


inline bool IsObjectType (const VLIShareable * inObject, VLIObjectType inType)
{
	VLISerialNumber test = inObject->GetObjectID() >> kObjectTypePosition;
	
	return VLIObjectType(test) == inType;
}

#if dDebugDynamicCast

template <class T, class S>
inline T * doDynamicCast (S * inSource, VLIObjectType inType, T * dummy, const char * sname, const char * dname)
{
	T * ret = (inSource == NULL) 
		? NULL
		: (IsObjectType(inSource, inType) 
				? static_cast<T *> (inSource) 
				: NULL );
	VLIOutputMessage ("#DC# %p = pseudo_dynamic_cast<%s>(%s %p)\n",
					(void *) ret, dname, sname, (void *) inSource);
	return ret;
}

#define DYNAMIC_CAST(type_, mods_, source_)				\
	doDynamicCast ((source_), kObjectType ## type_ , (type_ mods_) 0, # source_, # type_ ## # mods_)

#else // not debugging

#define DYNAMIC_CAST(type_, mods_, source_)				\
((source_ == NULL) ? NULL								\
    : IsObjectType((source_), kObjectType ## type_ )	\
		? static_cast<type_ mods_> (source_)			\
		: NULL)

#endif // end not debugging

extern void SetObjectType (VLIShareable * outObject, VLIObjectType inType);

#define SET_OBJECT_TYPE(object_, type_)	\
do {SetObjectType ((object_), (type_)); } while (false)

#endif // end poor man's dynamic cast

extern VLIbool Contains (const VLIImageRange &a, const VLIImageRange &b);

#if qCheckValidRange

static const int kVGBRangeMin	= -32768;
static const int kVGBRangeMax	=  32767;

#if dDebugValidRange
#define DUMP_VOLUME_RANGE(r_)								\
	VLIOutputMessage ("%d to %d, %d to %d, %d to %d",		\
		r_.XOrigin(), r_.XOrigin() + r_.XSize() - 1,		\
		r_.YOrigin(), r_.YOrigin() + r_.YSize() - 1,		\
		r_.ZOrigin(), r_.ZOrigin() + r_.ZSize() - 1)

inline void REPORT_VOLUME_RANGE_INVALID(
			VLIVolumeRange const & vol_r_, 
			VLIVolumeRange const & test_r_)
{
	VLIOutputMessage ("$$$ Volume Range invalid -- volume ");
	DUMP_VOLUME_RANGE(vol_r_);
	VLIOutputMessage ("; test ");
	DUMP_VOLUME_RANGE(test_r_); 
	VLIOutputMessage ("\n");
}

#define DUMP_IMAGE_RANGE(r_)								\
	VLIOutputMessage ("%d to %d, %d to %d",					\
		r_.XOrigin(), r_.XOrigin() + r_.XSize() - 1,		\
		r_.YOrigin(), r_.YOrigin() + r_.YSize() - 1)

inline void REPORT_IMAGE_RANGE_INVALID(
			VLIImageRange const & img_r_, 
			VLIImageRange const & test_r_)
{
	VLIOutputMessage ("$$$ Image Range invalid -- image ");
	DUMP_IMAGE_RANGE(img_r_);
	VLIOutputMessage ("; test ");
	DUMP_IMAGE_RANGE(test_r_); 
	VLIOutputMessage ("\n");
}

#else
#define REPORT_VOLUME_RANGE_INVALID(vol_r_, test_r_)	/* nothing */
#define REPORT_IMAGE_RANGE_INVALID(vol_r_, test_r_)	/* nothing */
#endif

#define CHECK_VALID_VOL_RANGE(vol_, r_)						\
do {if (! vol_->GetRange().Contains (r_) )					\
	{   REPORT_VOLUME_RANGE_INVALID(vol_->GetRange(), r_);	\
		VLI_RETURN_ERROR (kVLIErrArgument);					\
	}														\
	if (   r_.XSize() < 0 || r_.YSize() < 0 || r_.ZSize() < 0	\
		|| r_.XOrigin() < kVGBRangeMin						\
		|| r_.XOrigin() > kVGBRangeMax						\
		|| r_.XOrigin() + r_.XSize() - 1 < kVGBRangeMin		\
		|| r_.XOrigin() + r_.XSize() - 1 > kVGBRangeMax		\
		|| r_.YOrigin() < kVGBRangeMin						\
		|| r_.YOrigin() > kVGBRangeMax						\
		|| r_.YOrigin() + r_.YSize() - 1 < kVGBRangeMin		\
		|| r_.YOrigin() + r_.YSize() - 1 > kVGBRangeMax		\
		|| r_.ZOrigin() < kVGBRangeMin						\
		|| r_.ZOrigin() > kVGBRangeMax						\
		|| r_.ZOrigin() + r_.ZSize() - 1 < kVGBRangeMin		\
		|| r_.ZOrigin() + r_.ZSize() - 1 > kVGBRangeMax	)	\
	{   REPORT_VOLUME_RANGE_INVALID(vol_->GetRange(), r_);	\
		VLI_RETURN_ERROR (kVLIErrArgument);					\
	}														\
} while (0)

#define CHECK_VALID_VOL_BUFFER_RANGE(vol_, r_)				\
do {if (vol_->GetBufferAddressMode() != kVLIOffsetAddress	\
		&& ! vol_->GetBufferRange().Contains (r_) )			\
	{   REPORT_VOLUME_RANGE_INVALID(vol_->GetRange(), r_);	\
		VLI_RETURN_ERROR (kVLIErrArgument);					\
	}														\
	if (   r_.XSize() < 0 || r_.YSize() < 0 || r_.ZSize() < 0	\
		|| r_.XOrigin() < kVGBRangeMin						\
		|| r_.XOrigin() > kVGBRangeMax						\
		|| r_.XOrigin() + r_.XSize() - 1 < kVGBRangeMin		\
		|| r_.XOrigin() + r_.XSize() - 1 > kVGBRangeMax		\
		|| r_.YOrigin() < kVGBRangeMin						\
		|| r_.YOrigin() > kVGBRangeMax						\
		|| r_.YOrigin() + r_.YSize() - 1 < kVGBRangeMin		\
		|| r_.YOrigin() + r_.YSize() - 1 > kVGBRangeMax		\
		|| r_.ZOrigin() < kVGBRangeMin						\
		|| r_.ZOrigin() > kVGBRangeMax						\
		|| r_.ZOrigin() + r_.ZSize() - 1 < kVGBRangeMin		\
		|| r_.ZOrigin() + r_.ZSize() - 1 > kVGBRangeMax	)	\
	{   REPORT_VOLUME_RANGE_INVALID(vol_->GetRange(), r_);	\
		VLI_RETURN_ERROR (kVLIErrArgument);					\
	}														\
} while (0)

#define CHECK_VALID_2D_RANGE(buf_, r_)								\
do {VLIImageRange buf_r_ (buf_->GetWidth(), buf_->GetHeight(), \
		buf_->GetAddressParameterX(), buf_->GetAddressParameterY());	\
	if (   buf_->GetAddressMode() == kVLIOffsetAddress				\
		&& ! Contains (buf_r_, r_) )						\
	{       REPORT_IMAGE_RANGE_INVALID (buf_r_, r_);		\
			VLI_RETURN_ERROR (kVLIErrArgument);				\
	}														\
	if (   r_.XSize() < 0 || r_.YSize() < 0					\
        || r_.XOrigin() < kVGBRangeMin						\
		|| r_.XOrigin() > kVGBRangeMax						\
		|| r_.XOrigin() + r_.XSize() - 1 < kVGBRangeMin		\
		|| r_.XOrigin() + r_.XSize() - 1 > kVGBRangeMax		\
		|| r_.YOrigin() < kVGBRangeMin						\
		|| r_.YOrigin() > kVGBRangeMax						\
		|| r_.YOrigin() + r_.YSize() - 1 < kVGBRangeMin		\
		|| r_.YOrigin() + r_.YSize() - 1 > kVGBRangeMax	)	\
	{   REPORT_IMAGE_RANGE_INVALID(buf_r_, r_);				\
		VLI_RETURN_ERROR (kVLIErrArgument);					\
	}														\
} while (0)

#else	// qCheckValidRange is not set

#define CHECK_VALID_VOL_RANGE(vol_, r_)	\
do { /* nothing */ } while (0)

#define CHECK_VALID_2D_RANGE(buf_, r_)	\
do { /* nothing */ } while (0)

#endif

extern VLIImageRange Union (const VLIImageRange & inA, const VLIImageRange & inB);
extern VLIImageRange Intersect (const VLIImageRange & inA, const VLIImageRange & inB);


// VLIOutputMessage will send the message somewhere
// where it can be seen or collected. There are
// various destinations -- stderr, stdout, file,
// OuputDebugString. See vliinternal.cpp for
// possibilities.

extern void	VLIOutputMessage (const char * inFormatString, ...);

// Declare the 3D image resample routine so that
// others like perspective can use it

extern VLISyncEvent VLIResample3DImage (const VLIContext * inContext, 
				VLIImageBuffer * inOutColor0, VLIImageBuffer * inOutColor1,
				const VLIImageRange & inRange,
				const VLIImageBuffer * inSource,
				const VLIImageRange & inSourceRange);

extern VLISyncEvent Resample3DImage (const VLIContext * inRealContext,
								VLIImageBuffer * inOutColor0,		// original image 0
								VLIImageBuffer * inOutColor1,		// original image 1
								VLIContext * inTempContext,
								const VLIImageRange & inRange,
								VLIImageBuffer * in3DImage,
								bool inMPRSumAndcount = false);	// image to resize

extern VLISyncEvent	DoStartRenderAndResize (	// Render an image to a color buffer and resample
				VLIVolume * inVolume,			// volume to render
				const VLIContext * inContext,	// context (state)
				bool inEnableSumAndCount,
				double &inOutMPRScale,
				VLIImageBuffer * inOutColor0,	// color image buffer 0
				VLIDepthBuffer * inOutDepth0,	// depth image buffer 0
				VLIImageBuffer * inOutColor1,	// color image buffer 1
				VLIDepthBuffer * inOutDepth1);	// depth image buffer 1
		

// Internal constants

static const int kVLIMaxInternalBuffers = 0;
static const int kVLIMaxAllBuffers = kVLIMaxRenderBuffers + kVLIMaxInternalBuffers;
static const int kVLIMappingPorts = 4;

static const int kVLIMaxBoards = 8;
static const int kVLIMaxCutPlanes = 4;			// Condor value
static const int kVLIGradientTableLength = 8;	// Roadrunner value

//static const int kVLIGradientTableLength = 128;  // Condor value
static const int kVLILookupTableEntrySize = 36;

// Maximum falloff supported. Larger values are clamped to this.
static const double kMaxFallOff = 16.0;

// How many passes will we allow for XY supersampling? 
// 8*8 or 64 seems more than sufficient.

static const int kVLIMaxSamplingMultiple = 8;
static const double XVG500_UNITIZED_VIEW_FACTOR = (double (0x00080000));

// What values can we specify for Z supersampling?
#if qVG500
static const double kVLIMinZSuperSample = 1.0/8.0;
static const double kVLIMaxZSuperSample = 0.98196;
static const double kVLIZSuperSampleTest = (kVLIMaxZSuperSample + 1.0) * 0.5;
#else
static const double kVLIMinZSuperSample = 1.0/16.0;
static const double kVLIMaxZSuperSample = 2.0;
static const double kVLIZSuperSampleTest = 2.0;
#endif

////////////////////////////////////////////////
// Yin:9/19/01, deciding unit z sampling corresponding to 
//  XY sampling size
//
///////////////////////////////////////////////
static const double kVLIMinSamplingFactor = 1.0/16.0; 
static const double kVLIMaxSamplingFactor = 16.0;


//Internally, or when define Z sampling in baseplane, the
// Range of dZs_dZv

static const double kVLIMindZs_dZv = 0.5;
static const double kVLIMaxdZs_dZv = 8.0;

// X, Y and Z sampling limits

static const double kVLIMinHWSampleFactor = 0.5;	// Hardware limits
static const double kVLIMaxHWSampleFactor = 256.0;
static const double kVLIMinXYSampleFactor = 0.5;	// Application settable limits
static const double kVLIMaxXYSampleFactor = 16.0;
static const double kVLIMinZSampleFactor = 1.0 / kVLIMaxZSuperSample;
static const double kVLIMaxZSampleFactor = 1.0 / kVLIMinZSuperSample;
static const double kVLIDefaultMinXYSampleFactor = 1.0;
static const double kVLIDefaultMaxXYSampleFactor = 3.0;

// Camera to volume distance limits (in voxels)

static const double kVLIMinViewDistance = 1.0;
static const double kVLIMaxViewDistance = 4096.0;	// This is arbitrary
static const double kVLIDefaultViewDistance = 5.0;	// This avoids most possible rendering problems

// Mipmapping volumes

static const int kMipmapMinLevel			= 0;	// 0=root, 1=1/2, 2=1/4, 3=1/8, 4=1/16 (if shrink factor is 0.5)
static const int kMipmapMaxLevel			= 32;	// 0=root, 1=1/2, 2=1/4, 3=1/8, 4=1/16
static const int kMipmapDefaultMaxLevel		= 0;
static const int kMipmapDefaultMinLevel		= 0;
static const int kMipmapDefaultMinVolumeSize = 256;	// Don't create mipmap volumes for volumes smaller than this.
static const int kMipmapDefaultMinDimension = 12;	// Don't go below this size when creating mipmap levels
static const int kMipmapMinMinDimension		= 12;	// Don't allow minDimension to be smaller than this
static const int kMipmapDefaultShrinkFactor = 50;	// Shrink by this factor from level to level -- in percent!
static const int kMipmapMinShrinkFactor		= 50;	// 1/2
static const int kMipmapMaxShrinkFactor		= 99;
static const int kMipmapMaxNumberLevels		= 65;
static const int kMipmapMinNumberLevels		= 2;
static const int kMipmapDefaultNumberLevels	= 33;

static const int kMultiboardDefaultRenderMode = 1;		// Phase 1

static const int kMultiboardMaxVolumes		= 8;		// Limit # of subvolumes

// Overlap determines how many mipmap levels are produced accurately
// It is subject to revision based on the actual volume size
static const int kMultiboardMinOverlap		= 2;		// No support for mipmapping
static const int kMultiboardMaxOverlap		= 16384;	// Maximal overlap
static const int kMultiboardDefaultOverlap	= 64;		// Large enough for 5 mipmap levels

// Don't create multiboard volumes if all dimensions are smaller than MinVolumeSize
static const int kMultiboardMinMinVolumeSize		= 2;		// All volumes are multiboard
static const int kMultiboardMaxMinVolumeSize		= 16384;	// No volumes are multiboard
static const int kMultiboardDefaultMinVolumeSize	= 256;		// For testing -- this is pretty small

static const VLIContext::SpecularColorOpacityWeighting kSpecularWeightingDefault = VLIContext::kBasedOnBlendMode;

// number of different lookup tables that we save
static const int kVLIMaxLookupTablesWithDiffSampleDistance        = 16;

// Board revision numbers

enum BoardMajorVersion
{
	kBoardCondor = 0,
	kBoardFalcon = 1
};

enum BoardMinorVersion
{
	kBoardCondorRevA = 1,
	kBoardCondorRevB = 2
};


#if qNewThrowsException
#define VLI_SAFE_NEW(outVar, newExpr)	\
	do { try { outVar = new newExpr; } catch (...) { outVar = 0; } } while (0)
#elif qNewNoThrow
#define VLI_SAFE_NEW(outVar, newExpr)	\
	do { outVar = new (std::nothrow) newExpr; } while (0)
#else
#define VLI_SAFE_NEW(outVar, newExpr)	\
	do { outVar = new newExpr; } while (0)
#endif

// How many threads should we use internally for
// rendering?

static const int kVLIMaxRenderingThreads = 5;

// How many rendering requests can we queue up?

static const int kVLIRenderingQueueSize = 21;	// Actually, we can only queue 20

// How many events can we queue up?

static const int kVLIEventQueueSize = 256;		// Actually, only 255

// From VLIUtils.h - graphics math utility functions
//
// This is a pruned list of functions taken from the
// Graphics Gems Math library.
// Ferdi Scheepers and Stephen F May
// 15 June 1994

static double const kVLIDegToRad =  0.01745329251994329547;
static double const kVLIRadToDeg = 57.29577951308232286465;

//
// ONE-ARGUMENT UTILITY FUNCTIONS
//

// Function to round an integer up to the next higher power of two
inline VLIuint32 VLIPow2Round(VLIuint32 u)
{
	--u;
	u |= u >> 1;
	u |= u >> 2;
	u |= u >> 4;
	u |= u >> 8;
	u |= u >> 16;
	return u + 1;
}

inline bool VLIIsPowerOf2 (VLIuint32 u)
{
	return (u & (u - 1)) == 0;
}

inline double VLIAbs(double inF)
{
	return (inF >= 0) ? inF : -inF;
}

inline int VLIAbs(int inI)
{
	return (inI >= 0) ? inI : -inI;
}

inline double VLISquare(double inF)
{
	return inF * inF;
}

inline double VLICube(double inF)
{
	return inF * inF * inF;
}

inline double VLIInverse(double inF)
{
	if (inF == 0.0) return 1.0;
	return 1.0 / inF;
}

inline double VLISqrt(double inF)
{
	return sqrt(inF);
}

inline double VLIInverseSqrt(double inF)
{
	if (inF == 0.0) return 1.0;
	return 1.0 / sqrt(inF);
}

// VLIFraction returns a number from 0.0 to just under 1.0

inline double VLIFraction (double f)
{
	double integerPart;	// not used.

	if (f < 0.0)
	{
		double ff = 1.0 - modf (-f, &integerPart);
		if (ff == 1.0) return 0.0;
		return ff;
	}
	else
	{
		return modf (f, &integerPart);
	}
}

inline long VLIRound (double f)	// Round to nearest int
{
	if (f < 0.0) return long(f - 0.5);
	else return long (f + 0.5);
}

// TWO-ARGUMENT UTILITY FUNCTIONS

template <class T> 
	inline T VLIClampTo (T val, T high)
	{
		if (val >= high) return high;
		else return val;
	}

template <class T> 
	inline T VLIMax (T inA, T inB)
	{
	  return (inA > inB) ? inA : inB;
	}

template <class T> 
	inline T VLIMin (T inA, T inB)
	{
	  return (inA < inB) ? inA : inB;
	}

template <class T> 
	inline void VLISwap(T & inA, T & inB)
	{
		T tmp = inA; 
		inA = inB; 
		inB = tmp;
	}


// MULTI-ARGUMENT UTILITY FUNCTIONS
//
//

template <class T> 
	inline T VLIClampTo (T val, T low, T high)
	{
		if (val <= low) return low;
		else if (val >= high) return high;
		else return val;
	}

template <class T> 
	inline T VLIMax (T inA, T inB, T inC)
	{
	  return (inA > inB) ? VLIMax (inA, inC) : VLIMax (inB, inC);
	}

template <class T> 
	inline T VLIMin (T inA, T inB, T inC)
	{
	  return (inA < inB) ? VLIMin (inA, inC) : VLIMin (inB, inC);
	}



inline double VLIRadians(double inF)
{
	return inF * kVLIDegToRad;
}

inline double VLIDegrees(double inF)
{
	return inF * kVLIRadToDeg;
}

inline bool VLIIsTrue(VLIbool inTest) { return inTest != VLIfalse; }
inline bool VLIIsFalse(VLIbool inTest) { return inTest == VLIfalse; }

// TODO AFV 11/28/2000 -- do we want to support kVLIUnsignedBitfield?

inline bool IsValidVoxelFieldNumber(VLIFieldNumber inNumber)
{
	return inNumber >= kVLIField0 && inNumber < VLIFieldNumber(kVLIField0 + kVLIMaxVoxelFields);
}

#define CHECK_VOXEL_FIELD_NUMBER(number_)		\
	do { if (! IsValidVoxelFieldNumber(number_)) VLI_RETURN_ERROR (kVLIErrArgument); } while (0)

inline bool IsValidFieldFormat(VLIFieldFormat inFormat)
{
	return (   inFormat == kVLIUnsignedFraction 
			|| inFormat == kVLISignedFraction
			|| inFormat == kVLIUnsignedInteger);
}

inline bool IsValidFieldDescriptor (const VLIFieldDescriptor &inFD, int inMaxSizeBits, int inMaxSizeField = 16)
{
	// Sometimes we want to allow a null field descriptor
	if (inFD.m_format == kVLIUnknownFormat
		&& inFD.m_position == 0
		&& inFD.m_size == 0
		) return true;

	if ( ! IsValidFieldFormat (inFD.m_format) ) return false;
	if ( (inFD.m_position & 3) != 0) return false;
	if ( (inFD.m_size     & 3) != 0) return false;
	if ( (inFD.m_size < 4) || (inFD.m_size > inMaxSizeField) ) return false;
	if ( (inFD.m_position < 0 || inFD.m_position > inMaxSizeBits) ) return false;
	if ( (inFD.m_position + inFD.m_size > inMaxSizeBits) ) return false;
	return true;
}

inline bool IsValidFieldDescriptorDMA (const VLIFieldDescriptor &inFD, int inElementSizeBits)
{
	if ( ! IsValidFieldFormat (inFD.m_format) ) return false;
	if ( (inFD.m_position & 7) != 0) return false;
	if ( (inFD.m_size != 8) && (inFD.m_size != 16) && (inFD.m_size != 32) && (inFD.m_size != 64) ) return false;
	if ( (inFD.m_position < 0 || inFD.m_position > inElementSizeBits) ) return false;

	if ( (inFD.m_position + inFD.m_size > inElementSizeBits) ) return false;
	return true;
}

inline bool operator == (VLIFieldDescriptor const & lhs, VLIFieldDescriptor const & rhs)
{
	if (lhs.m_format != rhs.m_format) return false;
	return lhs.m_position == rhs.m_position && lhs.m_size == rhs.m_size;
}

inline bool operator != (VLIFieldDescriptor const & lhs, VLIFieldDescriptor const & rhs)
{
	return ! (lhs == rhs);
}

// Field format is described in the Condor Functional Spec
// in table 3-7, page 3-10 (Version 0.95, June 5, 2000)

// Bits 7:6 control
// Bits 5:4 size		(1 less than the field size in nibbles)
// Bits 3:0 position	(in nibbles)

// HWFieldFormat converts from VLIFieldDescriptor to the hardware
// format. If the field descriptor has kVLIUnknownFormat, it returns
// unsigned fraction, position 60, size 4, which is outside the
// valid bounds of everything for VP1000.

// TODO AFV 10/6/01 -- when the VolumePro line supports 64-bit data
// types, we need to have some way of ignoring a field

static VLIuint32 sIgnoredField =
		(kVLIUnsignedFraction << 6) | ((4 - 4) << 2) | (60 >> 2);

// D.M. 10/23/2001 - Added 'const' qualifier to the argument.
inline VLIuint32 HWFieldFormat (const VLIFieldDescriptor & inFD)
{
	if (inFD.m_format == kVLIUnknownFormat) return sIgnoredField;

	return ((inFD.m_format & 3) << 6) | ((inFD.m_size - 4) << 2) | (inFD.m_position >> 2);
}

// The following conversion factors and routines are to 
// be used solely for RGBA values -- floats are expected
// to be between 0.0 and 1.0, VLIuint8's between 0 and 255,
// etc.

static const double kVLIConversion8To12 = (4095.0/255.0);
static const double kVLIConversion12To8 = (255.0/4095.0);
static const double kVLIConversion8ToFloat = (1.0/255.0);
static const double kVLIConversion12ToFloat = (1.0/4095.0);
static const double kVLIConversionFloatTo8 = (255.0);
static const double kVLIConversionFloatTo12 = (4095.0);
static const unsigned int   kVLIMax8 = 255;
static const unsigned int   kVLIMax12 = 4095;

inline VLIuint16 VLIConvert8To12 (VLIuint8 in)
{
	if (in >= kVLIMax8) return kVLIMax12;
	else return (VLIuint16) ( (double) in * kVLIConversion8To12);
}

inline VLIuint16 VLIConvertFloatTo12 (double in)
{
	if (in <= 0.0) return 0;
	else if (in >= 1.0) return kVLIMax12;
	else return (VLIuint16) ( 0.5 + in * kVLIConversionFloatTo12 );
}

inline VLIuint8 VLIConvert12To8 (VLIuint16 in)
{
	if (in >= kVLIMax12) return kVLIMax8;
	else return (VLIuint8) ( 0.5 + in * kVLIConversion12To8);
}

inline VLIuint8 VLIConvertFloatTo8 (double in)
{
	if (in <= 0.0) return 0;
	else if (in >= 1.0) return kVLIMax8;
	else return (VLIuint8) ( 0.5 + (double) in * kVLIConversionFloatTo8);
}

inline double VLIConvert12ToFloat (VLIuint16 in)
{
	if (in >= kVLIMax12) return 1.0;
	else return (double) in * kVLIConversion12ToFloat;
}

inline double VLIConvert8ToFloat (VLIuint8 in)
{
	if (in >= kVLIMax8) return 1.0;
	return (double) in * kVLIConversion8ToFloat;
}

inline VLIuint64 ConvertDoubleToField (double inValue, const VLIFieldDescriptor & inFD, int inMaxSize)
{
	if (! IsValidFieldDescriptor (inFD, inMaxSize) ) return 0;

	// Assume unsigned fraction format

	unsigned int max = (1U << inFD.m_size) - 1U;
	unsigned int val = (unsigned int) (inValue * double(max));
	val = VLIClampTo (val, 0U, max);

	return VLIuint64(val) << inFD.m_position;
}

// End of color conversion stuff


inline bool ValidInterpolationMode (VLIInterpolationMode inMode)
{
	return (inMode == kVLINearestNeighbor || inMode == kVLITrilinear);
}

inline bool ValidExtendMode (VLIVolume::ExtendMode inMode)
{ return (inMode == VLIVolume::kExtendWithBorder) || (inMode == VLIVolume::kExtendWithEdge) ; }

inline bool ValidMigrationMode (VLIMigrationMode inMode)
{
	return (inMode >= kVLIMigrationNone && inMode <= kVLIMigrationFullCopy);
}

// kDefaultMaxTrimValue is used to set the default values
// for trim planes and crop planes.

static const double kDefaultMinTrimValue =  -16384.0;
static const double kDefaultMaxTrimValue =  16384.0;

// Test a projection matrix for perspective

inline bool IsPerspectiveMatrix (VLIMatrix inMatrix)
{
	return (inMatrix[3][0] != 0.0 ||
			inMatrix[3][1] != 0.0 ||
			inMatrix[3][2] != 0.0 ||
			inMatrix[3][3] != 1.0);
}

// Test a context for a depth test that always passes or always fails

inline bool IsDepthTestPass (const VLIContext* inContext)
{
	return (inContext->GetDepthCombineFunction() == VLIContext::kDepthCombineAll ||
			(inContext->GetDepthCombineFunction() == VLIContext::kDepthCombineAnd &&
			 (inContext->GetDepthTest(VLIContext::kDepthBuffer0) == VLIContext::kDepthTestPass &&
			  inContext->GetDepthTest(VLIContext::kDepthBuffer1) == VLIContext::kDepthTestPass)) ||
			(inContext->GetDepthCombineFunction() == VLIContext::kDepthCombineOr &&
			 (inContext->GetDepthTest(VLIContext::kDepthBuffer0) == VLIContext::kDepthTestPass ||
			  inContext->GetDepthTest(VLIContext::kDepthBuffer1) == VLIContext::kDepthTestPass)) ||
			(inContext->GetDepthCombineFunction() == VLIContext::kDepthCombineXor &&
			 ((inContext->GetDepthTest(VLIContext::kDepthBuffer0) == VLIContext::kDepthTestPass &&
			   inContext->GetDepthTest(VLIContext::kDepthBuffer1) == VLIContext::kDepthTestFail) ||
			  (inContext->GetDepthTest(VLIContext::kDepthBuffer0) == VLIContext::kDepthTestFail &&
			   inContext->GetDepthTest(VLIContext::kDepthBuffer1) == VLIContext::kDepthTestPass))));
}

inline bool IsDepthTestFail (const VLIContext* inContext)
{
	return ((inContext->GetDepthCombineFunction() == VLIContext::kDepthCombineAnd &&
			 (inContext->GetDepthTest(VLIContext::kDepthBuffer0) == VLIContext::kDepthTestFail ||
			  inContext->GetDepthTest(VLIContext::kDepthBuffer1) == VLIContext::kDepthTestFail)) ||
			(inContext->GetDepthCombineFunction() == VLIContext::kDepthCombineOr &&
			 (inContext->GetDepthTest(VLIContext::kDepthBuffer0) == VLIContext::kDepthTestFail &&
			  inContext->GetDepthTest(VLIContext::kDepthBuffer1) == VLIContext::kDepthTestFail)) ||
			(inContext->GetDepthCombineFunction() == VLIContext::kDepthCombineXor &&
			 ((inContext->GetDepthTest(VLIContext::kDepthBuffer0) == VLIContext::kDepthTestPass &&
			   inContext->GetDepthTest(VLIContext::kDepthBuffer1) == VLIContext::kDepthTestPass) ||
			  (inContext->GetDepthTest(VLIContext::kDepthBuffer0) == VLIContext::kDepthTestFail &&
			   inContext->GetDepthTest(VLIContext::kDepthBuffer1) == VLIContext::kDepthTestFail))));
}

// Works for all VLIImageBuffer types

template <class T> inline T * GetOutputImageBuffer (const VLIContext * inContext, T * inImage0, T * inImage1)
{
	VLIContext::ImageBufferNumber outBuffer = inContext->GetImageOutputBuffer();

	if (outBuffer == VLIContext::kImageBuffer0) return inImage0;
	if (outBuffer == VLIContext::kImageBuffer1) return inImage1;
	return NULL;
}

enum dFlags
{
	eDumpStateBlock	 =	0x0001,
	eDumpRenderBlock = 	0x0002,
	eDumpTableInfo	 =	0x0004,
	eDumpBufferInfo	 =	0x0008,
	eWriteImageOut	 =	0x0010,
	eWriteDepthOut	 =  0x0020,
	eWriteImage0	 =  0x0040,
	eWriteImage1	 =  0x0080,
	eWriteDepth0	 =  0x0100,
	eWriteDepth1	 =  0x0200,
	eDumpLookupTables = 0x0400
};

class VLIControlInternal
{
public:
	VLIControlInternal (void);
	~VLIControlInternal (void);
	void				IncrementObjectCount (void);
	void				DecrementObjectCount (void);
	VLIStatus			Open (int major, int minor);
	void				Close (void);

	// Currently all data is accessed globally.

	bool				m_initialized; 
	VLIErrorHandler		m_baseErrorHandler;
	VLIErrorHandler *	m_errorHandler;

	// Epsilon controls
	bool				m_ForceEpsilon;
	double				m_epsilon;

	int					m_compiletimeVLIMajor;				// Application compile time
	int					m_compiletimeVLIMinor;
	unsigned int		m_VGBBoardCount;					// Number of boards
	unsigned int		m_nextBoard;						// Next board to allocate a volume on
	int					m_VGBGradientLength;				// Same for all boards
	unsigned int		m_VGBCutPlaneCount;					// Same for all boards

	struct
	{
		VLIuint64			m_memorySize;
		int					m_major;
		int					m_minor;
		int					m_renderHangMaxZSlices;
		int					m_minZSupersample;
		int					m_maxZSupersample;
	}					m_board[kVLIMaxBoards];

	VGBBoard *			m_VGBBoard[kVLIMaxBoards];			// Pointers to board data

	CriticalSection *	m_globalCriticalSection;
	unsigned int		m_VGBMaxMap[3];
	unsigned int		m_VGBMaxLock[3];
	double				m_defaultGradientTable[kVLIGradientTableLength];

	long				m_objectCount;						// Num(Contexts)+Num(Volumes)

	long				m_shareableObjectsCreated;			// For debugging purposes
	long				m_shareableObjectsDestroyed;

	// Dump on command stuff
#if dDumpOnCommand
	std::string			m_debugFileName;
	int					m_dumpParam;

	void				ReadDumpParams (void);	// For debug - read VLIDebugFileName file

	std::string			m_imageDumpFileName;
	bool				m_imageDumpFileNameChanged;
	int					m_imageDumpFrame;
	std::string			m_depthDumpFileName;
	bool				m_depthDumpFileNameChanged;
	int					m_depthDumpFrame;
	std::string			m_lookupTableDumpFileName;
	bool				m_lookupTableDumpFileNameChanged;
	int					m_lookupTableDumpFrame;
#endif

	// Mipmap controls

	int					m_mipmapNumberLevels;
	int					m_mipmapMinLevel;
	int					m_mipmapMaxLevel;
	int					m_mipmapMinVolumeSize;
	int					m_mipmapMinDimension;
	int					m_mipmapShrink;						// Shrink factor, percent

	// Lighting control

	VLIContext::LightMode	m_lightMode;

	// Space leaping control
	VLIVolume::SpaceLeapingMode	m_spaceLeapingMode;

	// Multiboard controls

	bool				m_multiboardRenderEnableSwitch;
	bool				m_multiboardRenderEnable;
	int					m_multiboardRenderMode;
	int					m_multiboardSubvolumes;
	int					m_multiboardOverlap;
	int					m_multiboardMinVolumeSize;
	int					m_multiboard2ForceRender;

	// Resize Image control

	bool				m_resizeImage;

	// RenderArea control

	VLIContext::RenderArea	m_renderArea;

	// Debug output

	bool				m_traceErrors;

	// Force synchronous rendering

	bool				m_forceSynchRender;
	bool				m_forceSynchUpdate;
	bool				m_forceSynchUnload;

	// SpecularColorOpacityWeighting:
	// 0 means off
	// 1 means on
	// 2 means based on blend mode

	VLIContext::SpecularColorOpacityWeighting	m_specularColorOpacityWeighting;

	bool				m_perspectiveDoubleBuffer;
	bool				m_perspectiveSynchronousBlend;

	bool				m_renderToVolumeEnable;
	int					m_renderToVolumeZSlices;

	int					m_fixedXYSupersampleFactor;
	int					m_fixedZSupersampleFactor;

	bool				m_simulateMap;

	// Update methods for Volumes

	UpdateMethod		m_UpdateMethodMemory;
	long				m_MaxUpdateSizeMemory;
	UpdateMethod		m_UpdateMethodSource;
	long				m_MaxUpdateSizeSource;
	UpdateMethod		m_UpdateMethodFile;
	long				m_MaxUpdateSizeFile;

	// Temporary image buffer release

	bool				m_ReleaseTemporaryImageBuffers;

	// Do we want multiboard volumes containing mipmap volumes,
	// or mipmap volumes containing multiboard volumes?

	bool				m_MipmapMultiboard;

};

static const long kMinMaxUpdateSize =   1L * 1024L * 1024L;
static const long kMaxMaxUpdateSize = 128L * 1024L * 1024L;
static const long kDefaultMaxUpdateSize = 8L * 1024L * 1024L;

class CriticalSectionHandler
{
public:
	CriticalSectionHandler (CriticalSection * inCS)
		: m_criticalSection (inCS)
	{
		if (m_criticalSection) THREnterCriticalSection (m_criticalSection);
	}


	~CriticalSectionHandler (void)
	{
		if (m_criticalSection) THRLeaveCriticalSection (m_criticalSection);
	}


private:
	CriticalSection * m_criticalSection;

};

extern VLIControlInternal	gVLIControl;

inline bool VLIIsZero(double inF)
{
	return (VLIAbs(inF) < gVLIControl.m_epsilon);
}

extern void VLICloseInternal (void);

// A VLIListInternal will manage a list of pointers to an
// arbitrary class T. It will also manage serial numbers,
// maintaining an internal copy of these serial numbers
// for comparison against the serial numbers in the objects.
// The class supplied for the template must have a VLISerial
// member named m_serial and have AddRef and Release member
// functions. This is conveniently done by having it derive
// from VLIShareableInternal.

// HasNewData returns true if one or more of the serial number
// tests fail, and returns false only if all the tests pass.
// 

template <class T> class VLIListInternal
{

public:
	VLIListInternal (void);
	VLIListInternal (unsigned int maxElements, unsigned int defElements=0);

	~VLIListInternal (void);

	// Copy constructor
	VLIListInternal (const VLIListInternal & copyFrom);

	// Copy operator
	VLIListInternal & operator= (const VLIListInternal &copyFrom);

	VLIStatus Add (T *);
	VLIStatus Remove (T *);
	
	unsigned int Number (void) const {return m_curElements;}
	T * operator[] (int i) const
	{
		if (i < 0 || i >= m_curElements) return 0;
		else return m_array[i].pObject;
	}

	bool HasNewData(void);
	void ResetSerialNumbers (void);

private:

	void ReleaseAllObjects (void);

	struct Triplet
	{
		T				* pObject;		// pointer to reference counted object
		VLISerialNumber	objectNumber;	// object number last used
		VLISerialNumber	serialNumber;	// serial number last used
	};

	unsigned int			m_maxElements;
	unsigned int			m_allocElements;
	unsigned int			m_curElements;
	Triplet	*				m_array;
	bool					m_listChanged;
};

// VLISyncEvent constants and inlines

// At least some high order bits in the ID must be set
// At least some high order bits in the ID must be clear.
static const VLIuint64	kValidIDMask = UINT64_CONST (0xff00000000000000);

static const VLIuint64	kSyncIDStatus   = UINT64_CONST (0xf100000000000000);

inline bool IsValidSyncID (VLIuint64 inID)
{
	if ( (inID & kValidIDMask) == 0) return false;
	if ( (inID & kValidIDMask) == kValidIDMask) return false;
	return true;
}

inline VLIuint64 EnsureValidSyncID (VLIuint64 inID)
{
	return IsValidSyncID(inID)
				? inID
				: (kVLIErrArgument | kSyncIDStatus);
}

inline bool IsStatusCode (VLIuint64 inPrivate)
{
	return ( (inPrivate & kValidIDMask) == kSyncIDStatus );
}

extern VLISyncEvent CombineMultipleEvents (int activeCount, VLISyncEvent ev[]);
extern VLIStatus InitializeMultipleEventDatabase (void);
extern VLIStatus CleanupMultipleEventDatabase (void);

class VLICutPlaneData
{
public:
	
	double			m_planeA;
	double			m_planeB;
	double			m_planeC;
	double			m_distance;
	double			m_thickness;
	double			m_falloff;
	double			m_falloffHW;
	bool			m_renderOutside;

	VLIStatus ComputeVGBCutPlane(const VLIuint32 transform, const VLIMatrix &inModelPermuteInverse, VGBCutPlane &outCutPlane);
	
	inline void  GetPlaneData(double &A, double &B, double &C, double &D, double& T)
		{ A = m_planeA; B = m_planeB; C = m_planeC; D = m_distance; T = m_thickness;}

	inline void  SetPlaneData(double A, double B, double C, double D, double T)
		{ m_planeA = A; m_planeB = B; m_planeC = C; m_distance = D; m_thickness=T;}

};

class VLICutPlaneInternal : public VLICutPlane, public VLICutPlaneData
{
public:

	// constructor and destructor
	VLICutPlaneInternal (double inA, double inB, double inC, double inD,
		         double inOffset, 
		         double inFallOff, Flags inFlags);

	~VLICutPlaneInternal (void);
	// Get and set the cutplane coefficients
	void		GetPlane (double& outA, double& outB, double& outC, double& outD) const;
	double			GetPlaneA (void					// Return plane A value (world space)
							) const;

	double			GetPlaneB (void					// Return plane B value (world space)
							) const;

	double			GetPlaneC (void					// Return plane C value (world space)
							) const;

	double			GetPlaneD (void					// Return plane D value (world space)
							) const;

	VLIStatus	SetPlane (double inA, double inB, double inC, double inD);

	// Get and set the thickness
	double		GetThickness (void) const;
	VLIStatus	SetThickness (double inThickness );


	// Falloff region in which opacity ramps down to zero
	double		GetFallOff (void) const;
	VLIStatus	SetFallOff (double inFallOff);


	// Get and set flags
	Flags		GetFlags (void) const;
	VLIStatus	SetFlags (Flags inFlags);

};

class VLILightInternal : public VLILight
{

public:
	// constructor and destructor
	VLILightInternal(const VLIVector3D& inDirection, double inIntensity);
	~VLILightInternal (void) {};
	
	// Accessor functions for direction, and intensity.
	const VLIVector3D&	GetDirection  (void) const;
	double				GetIntensity  (void) const;

	VLIStatus			SetDirection  (const VLIVector3D &inDirection);
	VLIStatus			SetIntensity  (double inIntensity);

private:
	double		m_intensity;			// Intensity of the light source.
	VLIVector3D m_direction;			// Direction of the light source.
};

// This class exists only to convert the VLIVolumeRange and VLIImageRange
// classes into the VGBRange class for the buffer functions
class VLIRange : public VGBRange
{
public:
	VLIRange (VLIVolumeRange range) :
		VGBRange(range.XOrigin(),
				 range.YOrigin(),
				 range.ZOrigin(),
				 range.XOrigin() + range.XSize() - 1,
				 range.YOrigin() + range.YSize() - 1,
				 range.ZOrigin() + range.ZSize() - 1)
	{ }

	VLIRange (VLIImageRange range) :
		VGBRange(range.XOrigin(),
				 range.YOrigin(),
				 range.XOrigin() + range.XSize() - 1,
				 range.YOrigin() + range.YSize() - 1)
	{ }
};

/******************************************************************************
 *
 *	Name and purpose:
 *		VLIImageBufferInternal - Manage the state of hardware image buffers
 *
 *****************************************************************************/

class VLIImageBufferInternal : public VLIImageBuffer
{
public:

	// Constructor and destructor

	VLIImageBufferInternal (								// Create a VLIImageBuffer object
		VLILocation inLocation,								// Where to create buffer
		unsigned int inWidth,								// width in pixels
		unsigned int inHeight,								// height in pixels
		unsigned int inPixelSize							// size of pixel in bits (16, 32, or 64)
	);

	~VLIImageBufferInternal ();								// Destroy a VLIImageBuffer object

	// Location and size access

	VLILocation			GetLocation (void) const; 			// Return location of buffer

	void				GetSize (							// Return the size of the image in pixels
							unsigned int& outWidth,			// RETURNED width in pixels
							unsigned int& outHeight			// RETURNED height in pixels
						) const;

	unsigned int		GetWidth (void) const;				// Return the width of the image in pixels

	unsigned int		GetHeight (void) const;				// Return the height of the image in pixels

	unsigned int		GetPixelSize (void) const;			// Return the size of a pixel in bits

	// Field descriptor access

	VLIFieldDescriptor	GetFieldDescriptor (				// Return a field descriptor
							VLIChannel inFieldNumber	 	// which field to return
						) const;

	VLIStatus			SetFieldDescriptor (				// Set a field descriptor
							VLIChannel inFieldNumber,		// which field to set
							const VLIFieldDescriptor &inDescriptor // field descriptor
						);

	// Updating the data in the image

	VLIStatus			Update (							// Update a color image with new values
							const void * inData,			// location of input data
							const VLIImageRange & inRange,	// range of image to update
							unsigned int inWidth = 0		// width of application buffer (0 means use range)
						);

	VLIStatus			UpdateField (						// Update one color image field with new values
							const void * inData,			// location of input data
							const VLIFieldDescriptor & inDescriptor, // description of output
							const VLIImageRange & inRange,	// range of image to update
							unsigned int inWidth = 0		// width of application buffer (0 means use range)
						);

	VLISyncEvent		StartUpdate (						// ASYNCHRONOUS Start to update a color image with new values
							const void * inData,			// location of input data
							const VLIImageRange & inRange,	// range of image to update
							unsigned int inWidth = 0		// width of application buffer (0 means use range)
						);

	VLISyncEvent		StartUpdateField (					// ASYNCHRONOUS Start to update one color image field with new values
							const void * inData,			// location of input data
							const VLIFieldDescriptor & inDescriptor, // description of output
							const VLIImageRange & inRange,	// range of image to update
							unsigned int inWidth = 0		// width of application buffer (0 means use range)
						);

	VLIStatus			Clear (								// Clear a range of this buffer
							const VLIImageRange & inRange,	// range to clear
							VLIuint64 inValue				// clear value
						);

	// Reading the data in the image

	VLIStatus			Unload (							// Unload a color image to application storage
							void * outData, 				// RETURNED pixel data
							const VLIImageRange & inRange,	// range of image to return
							unsigned int inWidth = 0		// width of application buffer (0 means use range)
						) const;

	VLIStatus			UnloadField (						// Unload one color image field to application storage
							void * outData,					// RETURNED image data
							const VLIFieldDescriptor & inDescriptor, // description of output
							const VLIImageRange & inRange,	// range of image to return
							unsigned int inWidth = 0		// width of application buffer (0 means use range)
						) const;

	VLISyncEvent		StartUnload (						// ASYNCHRONOUS Start to unload a color image to application storage
							void * outData, 				// RETURNED pixel data
							const VLIImageRange & inRange,	// range of image to return
							unsigned int inWidth = 0		// width of application buffer (0 means use range)
						) const;

	VLISyncEvent		StartUnloadField (					// ASYNCHRONOUS Start to unload one color image field to application storage
							void * outData,					// RETURNED image data
							const VLIFieldDescriptor & inDescriptor, // description of output
							const VLIImageRange & inRange,	// range of image to return
							unsigned int inWidth = 0		// width of application buffer (0 means use range)
						) const;

	// Accessing the data in the image

	VLIStatus			Map (								// Map a 16-bit image into application memory space
							VLIuint16 *& outData,			// RETURNED pointer to image data
							const VLIImageRange & inRange,	// range of image to map inmapped image pointer to be releasedmapped image pointer to be released
							unsigned int & outWidth			// RETURNED width of application buffer
						);

	VLIStatus			Map (								// Map a 32-bit image into application memory space
							VLIuint32 *& outData,			// RETURNED pointer to image data
							const VLIImageRange & inRange,	// range of image to map inmapped image pointer to be releasedmapped image pointer to be released
							unsigned int & outWidth			// RETURNED width of application buffer
						);

	VLIStatus			Map (								// Map a 64-bit image into application memory space
							VLIuint64 *& outData,			// RETURNED pointer to image data
							const VLIImageRange & inRange,	// range of image to map inmapped image pointer to be releasedmapped image pointer to be released
							unsigned int & outWidth			// RETURNED width of application buffer
						);

	VLIStatus			Map (								// Map an image into application memory space
							void *& outData,				// RETURNED pointer to image data
							const VLIImageRange & inRange,	// range of image to map inmapped image pointer to be releasedmapped image pointer to be released
							unsigned int & outWidth			// RETURNED width of application buffer
						);

	VLIStatus			Unmap ( 							// Release an image buffer mapping
							void * inData					// mapped image pointer to be released
						);

	// Addressing modes

	VLIStatus			SetOffset (							// Set addressing mode to kVLIOffsetAddress and set the offset values
							int inOffsetX,					// Offset for X (must be even)
							int inOffsetY					// Offset for Y (must be even)
						);

	VLIStatus			SetWrap (							// Set addressing mode to kVLIWrapAddress and set the modulus values
							int inWrapX,					// Wrap modulus for X (must be a power of 2)
							int inWrapY						// Wrap modulus for Y (must be a power of 2)
						);

	VLIStatus			SetAddressParameters (				// Set the addressing parameters
							VLIAddressMode inMode,			// kVLIOffsetAddress or kVLIWrapAddress
							int inAddressParameterX,		// Offset or wrap modulus for X
							int inAddressParameterY			// Offset or wrap modulus for Y
						);

	void				GetAddressParameters (				// Return the addressing parameters
							VLIAddressMode & outMode,		// RETURNED kVLIOffsetAddress or kVLIWrapAddress
							int& outAddressParameterX,		// RETURNED Offset or wrap modulus for X
							int& outAddressParameterY		// RETURNED Offset or wrap modulus for Y
						) const;

	int					GetAddressParameterX (void) const;	// Return buffer offset or wrap X value

	int					GetAddressParameterY (void) const;	// Return buffer offset or wrap Y value

	VLIAddressMode		GetAddressMode (void) const;		// Return kVLIOffsetAddress or kVLIWrapAddress

	// Ranges of interest, input and output

	VLIImageRange		GetInputLimits (void) const;		// Return the input limits (initial range)

	VLIStatus			SetInputLimits (					// Set the input limits (initial range)
							const VLIImageRange & inLimits	// input limits
						);

	VLIImageRange		GetOutputLimits (void) const;		// Return the output limits (view frustum?)

	VLIStatus			SetOutputLimits (					// Set the output limits (view frustum?)
							const VLIImageRange & inLimits	// output limits
						);

	// The border value is used outside the input limits

	void				GetBorderValue (					// Return the border value (double)
							double & outRed, 				// red component, 0.0 to 1.0
							double & outGreen,				// green component, 0.0 to 1.0
							double & outBlue,				// blue component, 0.0 to 1.0
							double & outAlpha				// alpha component, 0.0 to 1.0
						) const;

	double				GetBorderRed (void) const;			// Return the red component of the border value		

	double				GetBorderGreen (void) const;		// Return the Green component of the border value		
	
	double				GetBorderBlue (void) const;			// Return the Blue component of the border value		

	double				GetBorderAlpha (void) const;		// Return the Alpha component of the border value		

	VLIStatus			SetBorderValue (					// Set the border value (double)
							double inRed,					// red component, 0.0 to 1.0
							double inGreen, 				// green component, 0.0 to 1.0
							double inBlue,					// blue component, 0.0 to 1.0
							double inAlpha					// alpha component, 0.0 to 1.0
						);

	// 3.1 routines

	VLIStatus		Resample (							// Resample the image to a different size
								VLIImageBuffer * outDestination,			// destination image buffer
								const VLIImageRange & inDestinationRange,	// detination range
								const VLIImageRange & inSourceRange			// source range
							);

	VLISyncEvent	StartResample (
								VLIImageBuffer * outDestination,	// ASYNCHRONOUS Start resampling the image
								const VLIImageRange & inDestinationRange,
								const VLIImageRange & inSourceRange
							);


	// New API for 3.3

	VLIStatus		SetMigrationMode (					// Set migration mode
								VLIMigrationMode inMode			// mode
							);

	VLIMigrationMode	GetMigrationMode (				// Return migration mode
							) const;

	VLIStatus		Migrate (							// Migrate buffer to particular location (board)
								VLILocation inLocation			// board
							);

	VLISyncEvent	StartMigrate (						// ASYNCHRONOUS Start to migrate buffer to particular location (board)
								VLILocation inLocation			// board
							);

	VLISerialNumber	GetLastVolumeRendered (				// Return ID of last volume rendered to this buffer
							) const;

	// Routines that are not part of VLIImageBuffer

	void				SetBuffer (VGBBuffer* inBuffer)
	{ m_buffer = inBuffer; }

	VGBBuffer*			GetBuffer (void)
	{ return m_buffer; }

	static VLIImageBufferInternal *  CreateSimple (							// Create a VLIImageBuffer object
							VLILocation inLocation, 		// location -- cannot be kVLIAnyBoard
							unsigned int inWidth,			// width in pixels
							unsigned int inHeight,			// height in pixels
							unsigned int inPixelSize,		// size of pixel in bits (16, 32, or 64)
							int inNumberOfFields = 0,		// number of fields in field array
							const VLIFieldDescriptor inFieldArray[] = 0 // pointer to field array
						);

	static VLIImageBufferInternal *  Create3D (							// Create a VLIImageBuffer object
							VLILocation inLocation, 		// location -- cannot be kVLIAnyBoard
							unsigned int inWidth,			// width in pixels
							unsigned int inHeight,			// height in pixels
							unsigned int inPixelSize,		// size of pixel in bits (16, 32, or 64)
							int inNumberOfFields = 0,		// number of fields in field array
							const VLIFieldDescriptor inFieldArray[] = 0, // pointer to field array
							int inNumberPlanes = 0
						);

	VLISyncEvent	DoStartMigrate (						// ASYNCHRONOUS Start to migrate buffer to particular location (board)
								VLILocation inLocation,			// board
								const VLIImageRange & inRange
							);

	void				SetLastVolumeRendered (VLISerialNumber inVolume) { m_lastVolume = inVolume; }

private:

	VLIStatus		ConvertTo3D (void);

	VLISyncEvent	DoStartResample (
								VLIImageBuffer * outDestination,	// ASYNCHRONOUS Start resampling the image
								const VLIImageRange & inDestinationRange,
								const VLIImageRange & inSourceRange
							);


	// Member data items

	VGBBoard*			m_board;							// board that holds this buffer
	VGBBuffer*			m_buffer;							// board buffer descriptor
	VLILocation			m_location;							// location of this buffer
	unsigned int		m_width;							// width in pixels
	unsigned int		m_height;							// height in pixels
	unsigned int		m_pixelSize;						// size of pixel in bits (16, 32, or 64)
	VLIImageRange		m_inputLimits;						// input limits (initial range)
	VLIImageRange		m_outputLimits;						// output limits (view frustum?)
	VLIAddressMode		m_addressMode;								// wrap mode flag
	int					m_addressParameterX;				// offset or modulus for X
	int					m_addressParameterY;				// offset or modulus for Y
	VLIuint16			m_borderValue[kVLIMaxOutputChannels]; // border color value
	VLIFieldDescriptor	m_fieldList[kVLIMaxVoxelFields];	// field descriptors
	VLIMigrationMode	m_migrationMode;					// can we migrate to another board?
	bool				m_is3D;								// True if this is a 3D buffer
	VLISerialNumber		m_lastVolume;						// last volume rendered to this buffer
};

/******************************************************************************
 *
 *	Name and purpose:
 *		VLIDepthBufferInternal - Manage the state of hardware depth buffers
 *
 *****************************************************************************/

class VLIDepthBufferInternal : public VLIDepthBuffer
{
public:

	// Constructor and destructor

	VLIDepthBufferInternal (								// Create a VLIDepthBuffer object
		VLILocation inLocation,								// Where to create buffer
		unsigned int inWidth,								// width in pixels
		unsigned int inHeight								// height in pixels
	);

	~VLIDepthBufferInternal ();								// Destroy a VLIDepthBuffer object

	// Location and size access

	VLILocation			GetLocation (void) const; 			// Return location of buffer

	void				GetSize (							// Return the size of the depth buffer
							unsigned int& outWidth,			// RETURNED width in depth elements
							unsigned int& outHeight			// RETURNED height in depth elements
						) const;

	unsigned int		GetWidth (void) const;				// Return the width of the depth buffer

	unsigned int		GetHeight (void) const;				// Return the height of the depth buffer

	// Updating the data in the buffer

	VLIStatus			Update (							// Update a depth buffer with new values
							const void * inData,			// location of input data
							const VLIImageRange & inRange,	// range of depth buffer to update
							unsigned int inWidth = 0,		// width of application buffer (0 means use range)
							DepthFormat inFormat = kDepth24Low	// format of this data
						);

	VLISyncEvent		StartUpdate (						// ASYNCHRONOUS Start to update a depth buffer with new values
							const void * inData,			// location of input data
							const VLIImageRange & inRange,	// range of depth buffer to update
							unsigned int inWidth = 0,		// width of application buffer (0 means use range)
							DepthFormat inFormat = kDepth24Low	// format of this data
						);

	VLIStatus			Clear (								// Clear a range of this buffer
							const VLIImageRange & inRange,	// range to clear
							VLIuint32 inValue				// clear value
						);

	// Reading the data in the buffer

	VLIStatus			Unload (							// Unload a depth buffer to application storage
							void * outData, 				// RETURNED pixel data
							const VLIImageRange & inRange,	// range of depth buffer to return
							unsigned int inWidth = 0,		// width of application buffer (0 means use range)
							DepthFormat inFormat = kDepth24Low	// format to be used for this data
						) const;

	VLISyncEvent		StartUnload (						// ASYNCHRONOUS Start to unload a depth buffer to application storage
							void * outData, 				// RETURNED pixel data
							const VLIImageRange & inRange,	// range of depth buffer to return
							unsigned int inWidth = 0,		// width of application buffer (0 means use range)
							DepthFormat inFormat = kDepth24Low	// format to be used for this data
						) const;

	// Accessing the data in the buffer

	VLIStatus			Map (								// Map a 32-bit depth buffer into application memory space
							VLIuint32 *& outData,			// RETURNED pointer to depth data
							const VLIImageRange & inRange,	// range of depth buffer to map in
							unsigned int & outWidth,		// RETURNED width of application buffer
							DepthFormat inFormat = kDepth24Low	// format to be used for this data
						);

	VLIStatus			Map (								// Map a depth buffer into application memory space
							void *& outData,				// RETURNED pointer to depth data
							const VLIImageRange & inRange,	// range of depth buffer to map in
							unsigned int & outWidth,		// RETURNED width of application buffer
							DepthFormat inFormat = kDepth24Low	// format to be used for this data
						);

	VLIStatus			Unmap ( 							// Release a depth buffer mapping
							void * inData					// mapped depth pointer to be released
						);

	// Addressing modes

	VLIStatus			SetOffset (							// Set addressing mode to kVLIOffsetAddress and set the offset values
							int inOffsetX,					// Offset for X (must be even)
							int inOffsetY					// Offset for Y (must be even)
						);

	VLIStatus			SetWrap (							// Set addressing mode to kVLIWrapAddress and set the modulus values
							int inWrapX,					// Wrap modulus for X (must be a power of 2)
							int inWrapY						// Wrap modulus for Y (must be a power of 2)
						);

	VLIStatus			SetAddressParameters (				// Set the addressing parameters
							VLIAddressMode inMode,			// kVLIOffsetAddress or kVLIWrapAddress
							int inAddressParameterX,		// Offset or wrap modulus for X
							int inAddressParameterY			// Offset or wrap modulus for Y
						);

	void				GetAddressParameters (				// Return the addressing parameters
							VLIAddressMode & outMode,		// RETURNED kVLIOffsetAddress or kVLIWrapAddress
							int& outAddressParameterX,		// RETURNED Offset or wrap modulus for X
							int& outAddressParameterY		// RETURNED Offset or wrap modulus for Y
						) const;

	int					GetAddressParameterX (void) const;	// Return buffer offset or wrap X value

	int					GetAddressParameterY (void) const;	// Return buffer offset or wrap Y value

	VLIAddressMode		GetAddressMode (void) const;		// Return kVLIOffsetAddress or kVLIWrapAddress

	// Ranges of interest, input and output

	VLIImageRange		GetInputLimits (void) const;		// Return the input limits (initial range)

	VLIStatus			SetInputLimits (					// Set the input limits (initial range)
							const VLIImageRange & inLimits	// input limits
						);

	VLIImageRange		GetOutputLimits (void) const;		// Return the output limits (view frustum?)

	VLIStatus			SetOutputLimits (					// Set the output limits (view frustum?)
							const VLIImageRange & inLimits	// output limits
						);

	// The border value is used outside the input limits

	VLIuint32			GetBorderValue (void				// Return the border value (VLIuint32)
						) const;

	VLIStatus			SetBorderValue (					// Set the border value (VLIuint32)
							VLIuint32 inBorderValue 		// border value (kVLIDepth24Low)
						);


	// New API for 3.3

	VLIStatus		SetMigrationMode (					// Set migration mode
								VLIMigrationMode inMode			// mode
							);

	VLIMigrationMode	GetMigrationMode (				// Return migration mode
							) const;

	VLIStatus		Migrate (							// Migrate buffer to particular location (board)
								VLILocation inLocation			// board
							);

	VLISyncEvent	StartMigrate (						// ASYNCHRONOUS Start to migrate buffer to particular location (board)
								VLILocation inLocation			// board
							);

	VLISerialNumber	GetLastVolumeRendered (				// Return ID of last volume rendered to this buffer
							) const;

	// Not part of the VLIDepthBuffer API

	void				SetBuffer (VGBBuffer* inBuffer)
	{ m_buffer = inBuffer; }

	VGBBuffer*			GetBuffer (void)
	{ return m_buffer; }

	static VLIDepthBufferInternal *  CreateSimple (							// Create a VLIDepthBuffer object
							VLILocation inLocation, 		// location -- cannot be kVLIAnyBoard
							unsigned int inWidth,			// width in pixels
							unsigned int inHeight
						);

	void				SetLastVolumeRendered (VLISerialNumber inVolume) { m_lastVolume = inVolume; }

private:

	// Member data items

	VGBBoard*			m_board;							// board that holds this buffer
	VGBBuffer*			m_buffer;							// board buffer descriptor
	VLILocation			m_location;							// location of this buffer
	unsigned int		m_width;							// width in pixels
	unsigned int		m_height;							// height in pixels
	VLIImageRange		m_inputLimits;						// input limits (initial range)
	VLIImageRange		m_outputLimits;						// output limits (view frustum?)
	VLIAddressMode		m_addressMode;								// wrap mode flag
	int					m_addressParameterX;							// offset or modulus for X
	int					m_addressParameterY;							// offset or modulus for Y
	VLIuint32			m_borderValue;						// border color value
	VLIMigrationMode	m_migrationMode;					// can we migrate to another board?
	VLISerialNumber		m_lastVolume;						// last volume rendered to this buffer

};

// This class encapsulates the data needed to display the results of volume
// rendering in a given graphics context.  It is shared between the
// context and possibly multiple rendering records.

static const int kVLILightMapSides = 6;		// A cube has 6 sides
static const int kVLILightMapQuadrants = 4;	// Each side has 4 quadrants
#define kVLILIGHTMAPSAMPLES 8				// Checked by vlitantable.h
static const int kVLILightMapSamples = kVLILIGHTMAPSAMPLES;	// We have 8x8 samples per quadrant
static const int kVLILightMapSize =					// 1536, if you really must know.
		kVLILightMapSides * kVLILightMapQuadrants 
		* kVLILightMapSamples * kVLILightMapSamples;

static const int kVLILightMapSize64 = kVLILightMapSize / 4;	// 4 entries per VLIuint64: 384
static const int kVLILightMapSizeBytes = kVLILightMapSize64 * 8;	// total bytes per light map


class LightMap : public VLIShareable
{
public:

	VLIuint64		map[kVLILightMapSize64];

};



enum RenderingType 
{
			kTypeLeaveOnBoard,	// RenderToBasePlane, no transfer at all
			kTypeFetch,			// RenderToBasePlane. transfer to main memory
			kTypeTransfer,		// RenderAndTransferBasePlane
			kTypeTransferAndDraw  // RenderToGC
};

enum RenderingState {
			kStateIdle,			// not in use
			kStateRendering,	// currently being rendered
			kStateTransfering,	// rendering done, being transfered (skipped if no transfer)
			kStateBasePlaneAvailable,	// transfer done (or rendering done, if no transfer)
			kStateBasePlaneFetched,	// Application has fetch this base plane
			kStateAborting,		// being aborted
			kStateAbortingNotified,	// being aborted, application has been notified
			kStateAborted,		// finished being aborted
			kStateError			// an internal error has been noted
};

struct AccumPixel 
{
	VLIuint16		r;
	VLIuint16		g;
	VLIuint16		b;
	VLIuint16		a;
};

class VLIContextInternal;

// VLILookupTableInternal definition moved to vlilookuptableinternal.h

// Event Queue data structures

struct EventDataPair
{
	VLIEventBase		* m_event;
	void				* m_data;
};

struct VLIEventQueue
{
public:
	VLIEventQueue (int queueSize);
	~VLIEventQueue (void);
	VLIStatus AddEvent (VLIEventBase * pEvent, void * pData);
	VLIStatus RemoveFirstEvent (long inTimeoutMilliseconds, VLIEventBase *&pEvent, void *&pData);

private:
	int					m_queueSize;
	EventDataPair		* m_queue;
	CriticalSection		* m_criticalSection;
	Semaphore			* m_semaphore;
	int					m_front;
	int					m_back;
};

// A VLIClassifierInternal adds no new data to a VLIClassifier,
// but does provide access to protected data.

// NOTE -- DO NOT ADD ANY DATA MEMBERS OR VIRTUAL FUNCTIONS
// We must be able to cast a VLIClassifier object to 
// a VLIClassifierInternal object without any consequences

class VLIClassifierInternal : public VLIClassifier
{
public:
	VLIStatus			ComputeHardwareRegisters (
							VLIVolume *			inVolume,
							VLIuint64 &			outVoxelFormat,
							VLIuint32 &			outInterpControl,
							VLILookupTable *	outLUT[kVLIMaxLookupTables],
							VLIuint32			outLUTFormat[kVLIMaxLookupTables],
							VLIuint32			outALU[kVLICombinationUnits],
							int					inOutGradientFields[3]
						) const;

};

template <class T>
class Range
{
	public:
		T minValue;
		T maxValue;
};

class VLIContextInternal :  public VLIContext
{
public:

	// Constructor and destructor
	VLIContextInternal (VLILookupTable* pColor);
	~VLIContextInternal (void);

	// VLIContext overrides 

	// Camera access

	VLICamera &		GetCamera (void					// Return a reference to the camera in this context
							);

	const VLICamera & GetCamera (void 				// Return a const reference to the camera in this context
							) const;

	VLIStatus		SetCamera (						// Set the camera in this context
								const VLICamera& inCamera	// new camera
							);
	
	// Lookup table access and combination operations

	VLILookupTable* GetLookupTable (				// DEPRECATED Return the requested lookup table
								) const;

	VLIStatus       SetLookupTable (				// DEPRECATED Set lookup table 0
								VLILookupTable* inLUT		// pointer to lookup table		
							);

	// Lights and Lighting properties


	VLIStatus		AddLight (						// Add this light to the context light list
								VLILight *inLight			// pointer to light to be added
							);

	VLIStatus		RemoveLight (					// Remove this light from the context light list
								VLILight *inLight			// pointer to light to be removed
							);

	unsigned int	GetLightCount (void				// Return the number of lights in the context light list
							) const;

	VLILight*		GetLight (						// Return a pointer to the indicated light
								unsigned int inI			// index of light to be returned
							) const;

	void			GetReflectionProperties (		// Return relection properties
								double& outDiffuse,			// RETURNED diffuse coefficient (0.0 to 1.0)
								double& outSpecular,		// RETURNED specular coefficient (0.0 to 1.0)
								double& outEmissive, 		// RETURNED emissive coefficient (0.0 to 1.0)
								double& outSpecularExponent	// RETURNED specular exponent (>= 0.0)
							) const;

	double			GetReflectionPropertiesDiffuse (	// Return diffuse coefficient
							) const;

	double			GetReflectionPropertiesSpecular (	// Return specular coefficient
							) const;

	double			GetReflectionPropertiesEmissive (	// Return emissive coefficient
							) const;

	double			GetReflectionPropertiesSpecularExponent (	// Return specular exponent
							) const;

	VLIStatus		SetReflectionProperties (		// Set relection properties
								double inDiffuse,			// diffuse coefficient (0.0 to 1.0)
								double inSpecular, 			// specular coefficient (0.0 to 1.0)
								double inEmissive, 			// emmisive coefficient (0.0 to 1.0)
								double inSpecularExponent	// specular exponent (>= 0.0)
							);


	void			GetSpecularColor (				// Return specular color
								double& outRed,				// RETURNED red component (0.0 to 1.0)
								double& outGreen, 			// RETURNED green component (0.0 to 1.0)
								double& outBlue				// RETURNED blue component (0.0 to 1.0)
							) const;

	VLIRGBAFloat	GetSpecularColor (void				// Return specular color (ignore alpha)
							) const;

	VLIStatus		SetSpecularColor (				// Set specular color
								double inRed,				// red component (0.0 to 1.0)
								double inGreen, 			// green component (0.0 to 1.0)
								double inBlue				// blue component (0.0 to 1.0)
							);

	VLIbool			GetGradientSpecularIlluminationModulation (void	// Return specular modulation flag
							) const;

	VLIbool			GetGradientDiffuseIlluminationModulation (void	// Return diffuse modulation flag
							) const;

	VLIbool			GetGradientEmissiveIlluminationModulation (void	// Return emmisive modulation flag
							) const;

	VLIStatus		SetGradientSpecularIlluminationModulation (		// Set specular modulation flag
								VLIbool inGMIMSpecular						// specular modulation desired
							);

	VLIStatus		SetGradientDiffuseIlluminationModulation  (		// Set diffuse modulation flag
								VLIbool inGMIMDiffuse						// diffuse modulation desired
							);

	VLIStatus		SetGradientEmissiveIlluminationModulation  (	// Set emissive modulation flag
								VLIbool inGMIMEmissive						// emissive modulation desired
							);

	// Opacity (Alpha) controls

	VLIbool			GetCorrectOpacity (void 			// Return opacity correction flag
					) const;

	VLIStatus		SetCorrectOpacity (					// Set opacity correction flag
						VLIbool inOn					// opacity correction desired
					);

	VLIbool			GetGradientOpacityModulation (void	// Return opacity modulation flag
							) const;

	VLIStatus		SetGradientOpacityModulation (		// Set opacity modulation flag
								VLIbool inOn			// opacity modulation desired
							);

	VLIbool 		GetCorrectGradient (void			// Return gradient correction flag
							) const;

	VLIStatus		SetCorrectGradient (				// Set gradient correction flag
								VLIbool inOn			// opacity correction desired
							);

	const double *	GetGradientTable (void			// Return pointer to gradient table
							) const;

	VLIStatus		SetGradientTable (				// Set gradient table
								const double *inTable		// gradient table (0.0 to 1.0)
					);

	// Cut Plane access

	VLIStatus		AddCutPlane (					// Add this cut plane to the context cut plane list
								VLICutPlane* inPlane		// cut plane to add
							);
	
	VLIStatus		RemoveCutPlane (				// Remove this cut plane to the context cut plane list
								VLICutPlane* inPlane		// cut plane to remove
							);

	unsigned int	GetCutPlaneCount (void			// Return the number of cut planes in the context cut plane list
							) const;

	VLICutPlane*	GetCutPlane (					// Return a pointer to the indicated cut plane
								unsigned int inI			// index of cut plane to be returned
							) const;

	
	// Cropping

	VLICrop	&		GetCrop (void					// Return a reference to the crop in this context
							);
	
	const VLICrop &	GetCrop (void					// Return a const reference to the crop in this context
							) const;
	
	VLIStatus		SetCrop (						// Set the crop in this context
								const VLICrop& inCrop		// new crop data
							);

	// The hardware 3D cursor DEPRECATED
	
	VLICursor &		GetCursor (void					// DEPRECATED Return a reference to the cursor in this context
							);
	
	VLIStatus		SetCursor (						// DEPRECATED Set the cursor in this context
								const VLICursor& inCursor	// new cursor data
							);
	// The Classifier section
	
	VLIClassifier &	GetClassifier (void				// Return a reference to the classifier in this context
							);
	
	const VLIClassifier &	GetClassifier (void		// Return a const reference to the classifier in this context
							) const;
	
	VLIStatus		SetClassifier (					// Set the classifer in this context
								VLIClassifier const &inClassifier	// new classifier data
							);

	// Super Sampling controls

	VLIStatus		SetSamplingFactor (					// Set the super sampling factor
								double inFactor			// super sampling factor in Z (0.5 to 8.0)
							);

	double			GetSamplingFactor (void				// Return the super sampling factor
							) const;

	void			GetSuperSamplingFactor (		// DEPRECATED Return the super sampling factors
								double& outX,				// RETURNED super sampling factor in X (1.0 to 0.0625)
								double& outY, 				// RETURNED super sampling factor in Y (1.0 to 0.0625)
								double& outZ				// RETURNED super sampling factor in Z (1.0 to 0.0625)
							) const;

	VLIStatus		SetSuperSamplingFactor (		// DEPRECATED Set the super sampling factors
								double inX, 				// super sampling factor in X (1.0 to 0.0625)
								double inY,  				// super sampling factor in Y (1.0 to 0.0625)
								double inZ 					// super sampling factor in Z (1.0 to 0.0625)
							);

	AccumulationMode GetBasePlaneAccumulation (void	// DEPRECATED Return the base plane accumulation mode
							) const;

	VLIStatus		SetBasePlaneAccumulation (		// DEPRECATED Set the base plane accumulation mode
								AccumulationMode inMode		// accumulation mode desired
							);

	VLICoordinateSpace GetSuperSamplingSpace (void	// DEPRECATED Return the super sampling space
							) const;

	VLIStatus		SetSuperSamplingSpace (			// DEPRECATED Set the super sampling space
								VLICoordinateSpace inSpace	// super sampling space: kVLIObjectSpace or kVLICameraSpace
								);

	// TODO AFV 5/24/2000: How to specify supersampling in image order rendering?

	// Rendering state

	VLIBlendMode	GetBlendMode (void				// Return accumulation blend mode
							) const; 

	VLIStatus		SetBlendMode (					// Set accumulation blend mode
								VLIBlendMode inMode			// accumulation blend mode
							);

	VLIBlendMode	GetLastBlendMode (void			// Return last blend mode
							) const; 

	VLIStatus		SetLastBlendMode (				// Set last blend mode
								VLIBlendMode inMode			// last blend mode
							);

	VLIStatus		SetRayTermination (					// Set early ray termination controls
								double inThreshold,				// threshold value (0.0 to 1.0)
								VLIbool inEnabled				// enable or disable
							);

	void			GetRayTermination (					// Return early ray termination controls
								double &outThreshold,		// RETURNED threshold value
								VLIbool &outEnabled			// RETURNED enable state
							) const;

	VLIbool			GetRayTerminationEnabled (void		// Return early ray termination enable state
							) const;
	
	double			GetRayTerminationThreshold (void	// Return early ray termination threshold
							) const;

	// Filter range values and controls. To update a depth buffer or exclude a sample, 
	// all enabled filters must pass.

	VLIStatus		SetGradientRange (				// Set the gradient range filter
								double inMinValue,			// minimum value to pass filter (square of gradient)
								double inMaxValue			// maximum value to pass filter (square of gradient)
							);

	void			GetGradientRange (				// Return the gradient range filter
								double & outMinValue,		// RETURNED minimum value to pass filter (square of gradient)
								double & outMaxValue		// RETURNED maximum value to pass filter (square of gradient)
							) const;

	double			GetGradientRangeMin (void			// Return the gradient range minimum
							) const;

	double			GetGradientRangeMax (void			// Return the gradient range maximum
							) const;

	VLIStatus		SetSampleAlphaRange (			// Set the sample alpha range filter
								double inMinValue,			// minimum value to pass filter
								double inMaxValue			// maximum value to pass filter
							);

	void			GetSampleAlphaRange (			// Return the sample alpha range filter
								double & outMinValue,		// RETURNED minimum value to pass filter
								double & outMaxValue		// RETURNED maximum value to pass filter
							) const;

	double			GetSampleAlphaRangeMin (void	// Return the sample alpha range minimum
							) const;

	double			GetSampleAlphaRangeMax (void	// Return the sample alpha range maximum
							) const;

	VLIStatus		SetAccumulatedAlphaRange (		// Set the accumulated alpha range filter
								double inMinValue,			// minimum value to pass filter
								double inMaxValue			// maximum value to pass filter
							);

	void			GetAccumulatedAlphaRange (		// Return the accumulated alpha range filter
								double & outMinValue,		// RETURNED minimum value to pass filter
								double & outMaxValue		// RETURNED maximum value to pass filter
							) const;

	double			GetAccumulatedAlphaRangeMin (void	// Return the accumulated alpha range minimum
							) const;

	double			GetAccumulatedAlphaRangeMax (void	// Return the accumulated alpha range maximum
							) const;

	VLIStatus		SetDepthTest (							// Set the depth test for a buffer
								DepthBufferNumber inDepthBuffer,	// depth buffer to change
								DepthTest inDepthTest				// depth test
							);

	DepthTest		GetDepthTest (							// Return the depth test for a buffer
								DepthBufferNumber inDepthBuffer		// depth buffer 
							) const;

	VLIStatus		SetDepthCombineFunction (				// Set how depth tests are used
								DepthCombineFunction inFunction		// how to use depth tests
							);

	DepthCombineFunction	GetDepthCombineFunction (void			// Return how depth tests are used
									) const;

	VLIStatus		SetDepthUpdateFilter (			// Set the filter mode for updating a depth buffer
								DepthBufferNumber inDepthBuffer,			// depth buffer (0 or 1)
								FilterTest inFilterTest			// filter test: bitwise or of FilterTest values
							);

	FilterTest		GetDepthUpdateFilter (			// Return the filter mode for updating a depth buffer
								DepthBufferNumber inDepthBuffer			// depth buffer (0 or 1)
							) const;

	VLIStatus		SetSampleFilter (		// Set the filter mode for excluding samples
								FilterTest inFilterTest			// filter test: bitwise or of FilterTest values
							);

	FilterTest		GetSampleFilter (void		// Return the filter mode for excluding samples
							) const;

	VLIStatus		SetImageOutputBuffer (		// Set the image buffer output switch
								ImageBufferNumber inBufferNumber
							);

	ImageBufferNumber	GetImageOutputBuffer (		// Return the image buffer output switch
							) const;

	// Source of gradient computation

	VLIStatus		SetGradientSource (						// Set the fields used to compute gradient (single)
								VLIFieldNumber inGradientField			// field used to compute all gradient values
							);

	VLIStatus		SetGradientSource (						// Set the fields used to compute gradient (multiple)
								VLIFieldNumber inGradientFieldX,		// field used to compute X gradient values
								VLIFieldNumber inGradientFieldY,		// field used to compute Y gradient values
								VLIFieldNumber inGradientFieldZ		// field used to compute Z gradient values
							);

	void			GetGradientSource (						// Return the fields used to compute gradient
								VLIFieldNumber & outGradientFieldX,	// RETURNED field used to compute X gradient values
								VLIFieldNumber & outGradientFieldY,	// RETURNED field used to compute Y gradient values
								VLIFieldNumber & outGradientFieldZ		// RETURNED field used to compute Z gradient values
							) const;

	VLIFieldNumber	GetGradientSourceX ( 							// Return the field used to compute gradient in X
							) const;

	VLIFieldNumber	GetGradientSourceY ( 							// Return the field used to compute gradient in Y
							) const;

	VLIFieldNumber	GetGradientSourceZ ( 							// Return the field used to compute gradient in Z
							) const;

	VLIStatus		SetGradientFunction (			// NOT SUPPORTED Set the gradient function
								GradientFunction inFunction	// function to set
							);

	GradientFunction GetGradientFunction (void		// NOT SUPPORTED Return the gradient function
							) const;


	VLIStatus		SetGradientInterpolationMode (		// Set the interpolation mode for gradients
								VLIInterpolationMode inMode		// interpolation mode
							);
	
	VLIInterpolationMode GetGradientInterpolationMode (void		// Return the interpolation mode for gradients
							) const;




	VLIStatus		SetTrimPlanes (					// Set the trim planes (object space)
								double inMinX,				// minimum x value
								double inMaxX,				// maximum x value
								double inMinY,				// minimum y value
								double inMaxY,				// maximum y value
								double inMinZ,				// minimum z value
								double inMaxZ				// maximum z value
							);

	void			GetTrimPlanes (					// Return the trim planes (object space)
								double & outMinX,			// RETURNED minimum x value
								double & outMaxX,			// RETURNED maximum x value
								double & outMinY,			// RETURNED minimum y value
								double & outMaxY,			// RETURNED maximum y value
								double & outMinZ,			// RETURNED minimum z value
								double & outMaxZ			// RETURNED maximum z value
							) const;

	

	double			GetTrimPlanesMinX (void			// Return the trim plane min X value
							) const;

	double			GetTrimPlanesMaxX (void			// Return the trim plane max X value
							) const;

	double			GetTrimPlanesMinY (void			// Return the trim plane min Y value
							) const;

	double			GetTrimPlanesMaxY (void			// Return the trim plane max Y value
							) const;

	double			GetTrimPlanesMinZ (void			// Return the trim plane min Z value
							) const;

	double			GetTrimPlanesMaxZ (void			// Return the trim plane max Z value
							) const;

	// Event support DEPRECATED

	VLIStatus		SetNotifyCallback (				// DEPRECATED Set the callback for some event type
								VLIEvent inEvent, 			// event type
								VLIEventCallback inNotify,	// callback routine or kVLIEventNoCallbackRoutine
								void *inData				// user data pointer
							);

	VLIStatus 		WaitForEvent (					// DEPRECATED Wait for the next event to occur
								long inTimeoutMilliseconds, // time to wait, or 0 for wait forever
								VLIEventBase *&outEvent,	// RETURNED event (must be deleted by caller)
								void *&outData				// RETURNED user data pointer
							);


	// VLI 1.x Rendering support DEPRECATED

	VLIStatus		RenderBasePlane (				// DEPRECATED Render a volume to a base plane buffer
								VLIVolume *inVolume,		// volume to render
								int inBuffer,				// buffer number
								VLIbool inLeaveOnBoard = VLIfalse // NOT SUPPORTED if VLItrue, don't DMA to buffer
							);
	
	VLIStatus		FetchBasePlane (				// DEPRECATED Fetch a base plane buffer
								int inBuffer,				// buffer number
								int &outBaseWidth,			// RETURNED width of base plane buffer (in pixels)
								int &outBaseHeight,			// RETURNED height of base plane buffer (in pixels)
								int &outImageWidth,			// RETURNED width of image in base plane buffer (in pixels)
								int &outImageHeight,		// RETURNED height of image in base plane buffer (in pixels)
								VLIPixel *&outBasePlane,	// RETURNED pointer to base plane buffer
								VLIVector3D outHexGeometry[6],		// RETURNED eye-space geometry of hexagonal volume footprint
								VLIVector2D outTexCoordinates[6]	// RETURNED texture coordinates of hexagonal volume footprint
							); 

	VLIStatus		ReleaseBasePlane (				// DEPRECATED Release a base plane buffer
								int inBuffer				// buffer number
							);


	VLIStatus		RenderToGraphicsContext (		// DEPRECATED Render volume using graphic context interface
								VLIVolume* inVolume, 		// volume to be rendered
								int inBuffer,				// buffer number
    							VLIGraphicsContext& inGC	// graphics context object to handle base plane transfer and rendering
							);

	VLIStatus		Abort (							// DEPRECATED Abort specified rendering operation
								int inBuffer				// buffer number
							);


	VLIPixelFormat	GetBasePlaneFormat (void		// DEPRECATED Return the pixel format
							) const;

	VLIStatus		SetBasePlaneFormat (			// DEPRECATED Set the pixel format
								VLIPixelFormat inFormat		// pixel format
							);

	VLIStatus		SetLightMode (LightMode inMode);

	LightMode		GetLightMode (void) const;

	VLIStatus		SetRenderArea (RenderArea inArea);

	RenderArea		GetRenderArea (void) const;

	VLIStatus		SetSamplingLimits ( 				// Set sampling limits
								double inMinXY, 				// min XY sampling factor
								double inMaxXY, 				// max XY sampling factor
								double inMinZ,					// min Z sampling factor
								double inMaxZ					// max Z sampling factor
							);

	void			GetSamplingLimits ( 				// Return sampling limits
								double& outMinXY,				// RETURNED min XY sampling factor
								double& outMaxXY,				// RETURNED max XY sampling factor
								double& outMinZ,				// RETURNED min Z sampling factor
								double& outMaxZ 				// RETURNED max Z sampling factor
							) const;

	VLIStatus		SetMinViewingDistance (double inDistance);

	double			GetMinViewingDistance (void) const;

	VLIStatus SetSpecularColorOpacityWeighting(SpecularColorOpacityWeighting inSpecularColorOpacityWeighting);

	SpecularColorOpacityWeighting GetSpecularColorOpacityWeighting(void) const;

private:

	// Internal routines and data

	VLILookupTable* m_lut;      // Current lookup table, shared and ref-counted

	VLIStatus		DoRender(VLIVolume *vliv, int buffer, RenderingType type, 
						VLIGraphicsContext *GC = 0);

	void			GenerateEventTransferDone (int inBufferNumber);
	void			GenerateEventRenderDone (int inBufferNumber);

	// Owned structures
	VLICamera			m_camera;   // Current camera
	VLICursor			m_cursor;   // hardware 3D cursor
	VLICrop				m_crop;		// Cropping
	VLIClassifier		m_classifier;


	struct VLIBufferInfoMap
	{
		enum VLIBasePlaneState
		{
			kBasePlaneReleased =0,
			kBasePlaneRendered,
			kBasePlaneFetched
		} m_state;

		VLIImageBuffer *	m_vliBuffer;
		char *				m_hostBuffer;
		long				m_hostBufferSizeBytes;
		VLISyncEvent		m_renderEvent;
		VLISyncEvent		m_unloadEvent;
		unsigned int		m_baseWidth;
		unsigned int		m_baseHeight;
		unsigned int		m_imageSizeX;
		unsigned int		m_imageSizeY;
		VLIVector3D			m_hexagon[6];
		VLIVector2D			m_texture[6];
	} m_bufferInfo[kVLIMaxRenderBuffers];



	// Shared structures, possibly multiple
	VLIListInternal<VLILight>		m_LightList;
	VLIListInternal<VLICutPlane>	m_CutPlaneList;

	// preferred bpi pixel format.
	VLIPixelFormat		m_bpiFormat;

	// Reflection coefficients
	double				m_emissive, m_diffuse, m_specular, m_specularExponent;

	// Specular color
	double				m_specularRed, m_specularGreen, m_specularBlue;

	// Flags to turn on/off gradient modulation of lighting
	bool				m_gradientIlluminationModSpecular;
	bool				m_gradientIlluminationModDiffuse;

	// Flag to turn on/off gradient modulation of opacity
	bool				m_gradientOpacityMod;

    // Flag to turn on/off opacity adjustment based on sample spacing.
	bool				m_correctOpacity;

	// Super Sampling data
	VLICoordinateSpace	m_SuperSpace;			// object or camera space, 
												// baseplane space, image space
	VLIVector3D			m_SuperSample;			// Given sampling deltas
	long				m_sampleMultiple[3];	// computed sampling multiples
	double				m_sampleZ;
	bool				m_supervolume;			// supervolume processing needed
	double				m_minSampleXY;			// Minimum XY sample factors allowed
	double				m_maxSampleXY;			// Maximum XY sample factors allowed
	double				m_minSampleZ;			// Minimum Z sample factor allowed
	double				m_maxSampleZ;			// Maximum Z sample factor allowed
	double				m_minViewDistance;		// Minimum voxel distance to camera


	// Do we want a large base plane, or a blended one? (Multi-pass rendering)
	AccumulationMode	m_accumulationMode;

	// gradient magnitude lookup
	double				*m_gradientTable;

	// Blend mode MIP, MinIP or Weighted average
	VLIBlendMode		m_blendMode;

	// callback functions and the event queue
	VLIEventCallback	m_eventCallback[kVLINumberOfEvents];
	void				* m_eventCallbackData[kVLINumberOfEvents];
	VLIEventQueue		m_eventQueue;

	// We need to ensure base planes are in strict FIFO order.
	// When we start a rendering, we store the current contents
	// of m_lastBufferStarted in rr->m_previousBuffer, then
	// bump m_lastBufferStarted by one.

	// When the rendering record is ready to return its base plane,
	// it must first wait for rr->m_previousBuffer to equal
	// m_lastBufferCompleted. It then returns its base plane
	// and sets m_lastBufferCompleted to the next value.

	// In order to wait efficiently, we use the m_orderCriticalSection
	// and m_orderSemaphore members. We need to be inside the critical
	// section in order to test or update m_lastBufferCompleted.
	// However, we assume that only one thread calls the Render routines
	// for a single context concurrently, so we don't need to access/update
	// m_lastBufferStarted or rr->m_previousBuffer inside a C.S.

	unsigned int		m_lastBufferStarted;
	unsigned int		m_lastBufferCompleted;


	// VLI Condor


private:
	VLIbool				m_gradientIlluminationModEmissive;
	VLIBlendMode		m_LastBlendMode;
	bool				m_ertEnabled;
	double				m_ertThreshold;

	Range<double>		m_gradientRange;
	Range<double>		m_SampleAlphaRange;
	Range<double>		m_AccumulatedAlphaRange;

	FilterTest			m_DepthFilterTest[2]; //for Depth0 and Depth1
	FilterTest			m_SampleFilterTest;

	DepthTest			m_DepthTest[2];
	DepthCombineFunction	m_DepthCombineFunction;

	//variables for gradient computation
	VLIFieldNumber		m_gradientField[3]; //for X, Y , & Z.
	GradientFunction	m_gradientFunction;
	VLIInterpolationMode m_gradientInterpolation;
	bool				m_correctGradient;

	//trim plane variables
	Range<double>		m_TrimPlane[3]; //X,Y, & Z trim planes

	ImageBufferNumber	m_outputImageBuffer;

	// MinimizeRenderArea control
	RenderArea			m_renderArea;

	// Light mode

	LightMode			m_lightMode;

	SpecularColorOpacityWeighting 	m_specularColorOpacityWeighting;

};

VLIContextInternal * CloneContext (const VLIContext * inContext);

class VLIAccessInternal
{
public:
	VLIAccessType	m_control;
	unsigned int	m_refCount;

	VLIAccessInternal()
	{
		m_control = kVLIAccessNoControl;
		m_refCount = 0;
	}

	~VLIAccessInternal()
	{
		VLI_ASSERT (m_control == kVLIAccessNoControl);
		VLI_ASSERT (m_refCount == 0);
	}

	VLIStatus AddAccess (VLIAccessType inToAdd);
	VLIStatus ReleaseAccess (void);

};

inline bool VLIAccessIsWrite(VLIAccessType inAccess)
{
	return inAccess >= kVLIAccessWrite;
}

inline bool VLIAccessIsRead(VLIAccessType inAccess)
{
	return inAccess < kVLIAccessWrite;
}

inline bool VLIAccessIsValid (VLIAccessType inAccess)
{
	return (inAccess > kVLIAccessNoControl)
			&& (inAccess <= kVLIAccessWriteOnlyExclusive);
}

inline bool VLIValidChannel (VLIChannel inChannel)
{
	return (inChannel >= kVLIChannelRed && inChannel <= kVLIChannelAlpha);
}

class VLIVolumeSourceMemory : public VLIVolumeSource
{
public:
	VLIVolumeSourceMemory (int voxelSize,	// size of each voxel in bits
							void *pVoxels, 
							VLIVolumeRange inRange);

	~VLIVolumeSourceMemory (void);

	VLIVolumeRange	GetVolumeSize (void) const;

	VLIbool		IsReadOnly (void) const;
	VLIbool		CanResize (void) const; 
	VLIStatus	Resize (const VLIVolumeRange & inNewRange);

	VLIbool		HasData (void) const;
	VLIMatrix	GetInitialCorrectionMatrix (void) const;

	int			GetVoxelSize (void) const;

	VLIFieldDescriptor	GetFieldDescriptor (
								VLIFieldNumber inFieldNumber) const;
	
	VLIStatus	UnloadVoxels (void * outVoxels, const VLIVolumeRange &inSubVolume);

	VLIStatus	MapVoxels(const VLIVolumeRange &inSubVol,		// What portion do we want?
							VLIbool inMayWrite,				// modifiable?
                	    	void *& outVoxels,				// RETURNED pointer
                  	    	unsigned int & outYStride, unsigned int & outZStride);   // RETURNED strides

	VLIStatus	ReleaseVoxels (void *inVoxels);	// subvolume to release

	VLIStatus	UpdateVoxels(const VLIVolumeRange &inSubVol,		// What portion do we want to change?
							const void *inVoxels           // data
				);

	VLIVolumeRange	ChangedRange (							// Return the portion of the volume range that has changed
							const VLIVolumeRange & inVolumeRange	// What range is being queried
				) const;

	void		ResetChangedRange (void);					// Reset the modified range

private:
	inline char *			GetVoxelAddress (int inX, int inY, int inZ)
	{
		VLI_ASSERT (inX >= m_range.XOrigin() && inX < m_range.XOrigin() + m_range.XSize() );
		VLI_ASSERT (inY >= m_range.YOrigin() && inY < m_range.YOrigin() + m_range.YSize() );
		VLI_ASSERT (inZ >= m_range.ZOrigin() && inZ < m_range.ZOrigin() + m_range.ZSize() );
		unsigned long offset = inZ - m_range.ZOrigin();
		offset = offset * m_range.YSize() + inY - m_range.YOrigin();
		offset = offset * m_range.XSize() + inX - m_range.XOrigin();
		offset *= m_voxelSizeBytes;
		return 	m_baseAddress + offset;
	}

	char			* m_baseAddress;
	VLIVolumeRange	m_range;
	VLIVolumeRange	m_modifiedRange;
	int				m_voxelSizeBits;
	int				m_voxelSizeBytes;

};

// A VLICachedObject<T> is used to cache information on
// a particular VLIShareable object -- we save
// a pointer to the object plus the object number
// and serial number (change count). If (and only if)
// all three match, the cached values are good.

template <class T> class VLICachedObject
{
public:
	VLICachedObject () : m_objectNumber (0), m_serialNumber (0), m_object (NULL) {}

	bool		IsDifferent (T * pObject)
	{
		if (pObject != m_object) return true;
		if (pObject == NULL) return false;
		if (m_objectNumber != pObject->GetObjectID()) return true;
		if (m_serialNumber != pObject->GetSerial()) return true;

		return false;
	}

	void		SetToObject (T * pObject)
	{
		m_object = pObject;
		if (pObject != NULL)
		{
			m_objectNumber = pObject->GetObjectID();
			m_serialNumber = pObject->GetSerial();
		}
	}

	VLISerialNumber	m_objectNumber;
	VLISerialNumber	m_serialNumber;
	T *				m_object;
};

#include <vector>
#ifdef hpux
typedef vector<VLICachedObject<VLILight> >	LightCacheVector;
#else
typedef std::vector<VLICachedObject<VLILight> >	LightCacheVector;
#endif

#if qSharedLUT
struct LookupTableInfo
{

	VGBBoard *				m_board;
	double					m_sampleDistance;
	double                  m_MPRScale;
	VGBBuffer *				m_vgbTable;
	int						m_vgbTableSize;
	int						m_inuseCount;
	VLICachedObject<VLILookupTable>	m_vliTable;
};

class VLILookupTableCache : public VLIShareable
{
public:
	VLILookupTableCache(VLILookupTable * inLUT);
	VLISerialNumber			m_lutObjectID;

	VLISyncEvent			m_lutTableSyncEvent;
	VLIuint64				m_tempBuffer[4096];

	LookupTableInfo m_LookupTableInfo[kVLIMaxLookupTablesWithDiffSampleDistance];
	// Cached LUT information

	~VLILookupTableCache();

};


class VLIRenderCache
{
public:
	// In order to boost performance when some things are not changing,
	// we cache certain information on the last used board.

	VLIRenderCache ()
	  :	m_board(NULL), 
		m_vliLights(), 
		m_diffuseMap(NULL), 
		m_specularMap(NULL),
		m_vgbGMLut(NULL),
		m_vliGMLut(NULL),
		m_vliGMLutSize(0),
		m_vgbACLut(NULL),
	    m_alphaScaled (false),
		m_maxSampleDistance (-1.0),
		m_MPRScale(-1.0),
		m_rgbScaled(false),
		m_alphaCorrSyncEvent(kVLIOK),
		m_diffuseLightMapSyncEvent(kVLIOK),
		m_specularLightMapSyncEvent(kVLIOK),
		m_ModelMatrix (),
		m_GradientCorrection (false),
		m_EyeVector (0, 0, 0),
		m_LightMode (-1),
		m_specularExponent (-1.0)


	{
		for (int i = 0; i < kVLIMaxLookupTables; ++i) 
		{
			m_pLookupTableCache[i] = NULL;
			m_currentIndex[i] = 0;
		}
	}

	~VLIRenderCache ();

	static void				Cleanup (void);

	void					Clear (VGBBoard * inNewBoard);

	VLIStatus				SetupLightMaps (const VLIContext * inContext, 
									const VLIMatrix & inLightMatrix, const VLIbool inGradientCorrection,
									VLIVector3D &inEyeVector);
	VLIStatus				SetupLookupTables (const VLIContext * inContext, VLILookupTable * inLut[kVLIMaxLookupTables], 
									 double *inScaleTable = NULL, int inUpAlphaLimit =0, double inMaxSampleDistance =0,
									 bool isMPRRGBOn = false);
	VLIStatus				SetupGradientMagLut (const VLIContext * inContext);
	VLIStatus				SetupAlphaCorrectionLut( VLISampleSpace * inSamplespace);
	void					ReleaseLookupTableCache(unsigned int lut);
	VLILookupTableCache	*	FindAppropriateLut(	bool &outCorrectionChanged, bool inIsMPROn,
												VLILookupTable * inLut, unsigned int iniLut,
												double inMaxSampleDistance, int inRealLutSize);

	VLIbool					LookupTablesChanged(VLILookupTable* inLut[kVLIMaxLookupTables]);

	bool					GetLutBuffers(VGBBuffer *outvgbTables[kVLIMaxLookupTables]);
	void					ReleaseLUT(void);

	// Cached lighting information

	VGBBoard *				m_board;		// chached on what board?

	LightCacheVector		m_vliLights;
	VGBBuffer *				m_diffuseMap;
	VGBBuffer *				m_specularMap;

	VGBBuffer *             m_vgbGMLut;
	double    *				m_vliGMLut;
	int						m_vliGMLutSize;
	VGBBuffer *             m_vgbACLut;

	bool                    m_alphaScaled;	
	double					m_maxSampleDistance;

	double					m_MPRScale;
	bool					m_rgbScaled;

	// Cached LUT information

	VLISyncEvent			m_alphaCorrSyncEvent;
	VLIuint64				m_diffuseLightMap[kVLILightMapSize64];
	VLIuint64				m_specularLightMap[kVLILightMapSize64];
	VLISyncEvent			m_diffuseLightMapSyncEvent;
	VLISyncEvent			m_specularLightMapSyncEvent;
	VLIMatrix				m_ModelMatrix;
	VLIbool					m_GradientCorrection;
	VLIVector3D				m_EyeVector;
	int						m_LightMode;
	double					m_specularExponent;
	VLILookupTableCache*	m_pLookupTableCache[kVLIMaxLookupTables];
	int						m_currentIndex[kVLIMaxLookupTables];

	// static critical section 

	static CriticalSection*	s_criticalSection;


};

#else
class VLIRenderCache
{
public:
	// In order to boost performance when some things are not changing,
	// we cache certain information on the last used board.

	VLIRenderCache ()
	  :	m_board(NULL), 
		m_vliLights(), 
		m_diffuseMap(NULL), 
		m_specularMap(NULL),
		m_vgbGMLut(NULL),
		m_vliGMLut(NULL),
		m_vliGMLutSize(0),
		m_vgbACLut(NULL),
	    m_alphaScaled (false),
		m_maxSampleDistance (-1.0),
		m_MPRScale(-1.0),
		m_rgbScaled(false),
		m_alphaCorrSyncEvent(kVLIOK),
		m_diffuseLightMapSyncEvent(kVLIOK),
		m_specularLightMapSyncEvent(kVLIOK),
		m_ModelMatrix (),
		m_GradientCorrection (false),
		m_EyeVector (0, 0, 0),
		m_LightMode (-1),
		m_specularExponent (-1.0)
	{
		for (int i = 0; i < kVLIMaxLookupTables; ++i) m_vgbTables[i] = NULL;
	}

	~VLIRenderCache ();

	static void				Cleanup (void) {}

	void Clear (VGBBoard * inNewBoard);

	VLIStatus	SetupLightMaps (const VLIContext * inContext, 
					const VLIMatrix & inLightMatrix, const VLIbool inGradientCorrection,
					VLIVector3D &inEyeVector);
	VLIStatus	SetupLookupTables (const VLIContext * inContext, VLILookupTable * inLut[kVLIMaxLookupTables], 
											 double *inScaleTable = NULL, int inUpAlphaLimit =0, double inMaxSampleDistance =0,
											  bool isMPRRGBOn = false);
	VLIStatus	SetupGradientMagLut (const VLIContext * inContext);
	VLIStatus   SetupAlphaCorrectionLut( VLISampleSpace * inSamplespace);
	VLIbool     LookupTablesChanged(VLILookupTable* inLut[kVLIMaxLookupTables]);

	// On what board was everything cached?
	VGBBoard *				m_board;

	// Cached lighting information

	LightCacheVector		m_vliLights;
	VGBBuffer *				m_diffuseMap;
	VGBBuffer *				m_specularMap;

	VGBBuffer *             m_vgbGMLut;
	double    *				m_vliGMLut;
	int						m_vliGMLutSize;
	VGBBuffer *             m_vgbACLut;
	double					m_MPRScale;
	bool 					m_rgbScaled;
	bool                    m_alphaScaled;	
	double					m_maxSampleDistance;

	// Cached LUT information

	VLICachedObject<VLILookupTable>	m_vliTables[kVLIMaxLookupTables];	// we have four tables
	VGBBuffer *				m_vgbTables[kVLIMaxLookupTables];
	VLISyncEvent			m_alphaCorrSyncEvent;
	VLIuint64				m_diffuseLightMap[kVLILightMapSize64];
	VLIuint64				m_specularLightMap[kVLILightMapSize64];
	VLISyncEvent			m_diffuseLightMapSyncEvent;
	VLISyncEvent			m_specularLightMapSyncEvent;
	VLIMatrix				m_ModelMatrix;
	VLIbool					m_GradientCorrection;
	VLIVector3D				m_EyeVector;
	int						m_LightMode;
	double					m_specularExponent;
};
#endif

class VLISpaceLeapingCache
{
public:
	
	VLISpaceLeapingCache();
	VLIbool VolumeChanged(VLIVolumeInternal *inVolume);
	VLIbool LookupTablesChanged(VLILookupTable* inLut[kVLIMaxLookupTables], 
		VLIuint64		inVoxelFormat,
		VLIuint32		inLutFormat[kVLIMaxLookupTables],
		VLIuint32	    inAlu[kVLICombinationUnits]);
	VLIbool ContextChanged(VLIBlendMode inBlendTestMode, VLIuint16 inThres12[kVLIMaxOutputChannels]);
	
	void SetContextInfo(VLIBlendMode inBlendTestMode,
		VLIuint16 inThres12[kVLIMaxOutputChannels]);	
	void SetVolumeInfo (VLIVolumeInternal *inVolume);	
	void SetLookupTableInfo (VLILookupTable* inLut[kVLIMaxLookupTables], 
		VLIuint64		inVoxelFormat,
		VLIuint32		inLutFormat[kVLIMaxLookupTables],
		VLIuint32	    inAlu[kVLICombinationUnits]);
	
	
	VLICachedObject<VLILookupTable>	m_lutCache[kVLIMaxLookupTables];
	VLICachedObject<VLIVolumeInternal>	m_volumeCache;
	
	VLIuint64	m_voxelFormat;
	VLIuint32	m_lutFormat[kVLIMaxLookupTables];
	VLIuint32	m_Alu[kVLICombinationUnits];
	VLIuint16   m_threshold[kVLIMaxOutputChannels];
	
	VLIBlendMode m_testBlendMode;
	
	
};

class PerspInterf;

typedef enum 
{
	kOneToOne,
	kSideways,
	kUnload,
	kUpdate
} sideways;


class BlockSortHelper;

class VLIVolumeInternal :  
			public VLIVolume, 
			public VLIAccessInternal
{

public:

	// Routines to implement VLIVolume virtual routines.
	// These are all overrides
	// Queries for whole volume state

	VLIbool		IsReadOnly (void				// Was this volume created in read-only mode?
				) const;

	VLIuint32	GetFormat(void					// DEPRECATED Return format of the volume
				) const;

	Layout		GetLayout(void					// DEPRECATED Return layout of the volume(slice/block)
				) const;
	
	VLIVolumeRange	GetRange (void				// Return the range (size and origin) of the volume in voxels
				) const;


	void		GetSize (						// Return the size of the volume in voxels
					unsigned int& nXVox,		// RETURNED size of volume in X in voxels
					unsigned int& nYVox, 		// RETURNED size of volume in Y in voxels
					unsigned int& nZVox			// RETURNED size of volume in Z in voxels
				) const;

	unsigned int GetSizeX (void					// Return the X size of the volume
				) const;

	unsigned int GetSizeY (void					// Return the Y size of the volume
				) const;

	unsigned int GetSizeZ (void					// Return the Z size of the volume
				) const;

	int			GetVoxelSize (void				// Return the size of voxel in bits (8, 16 or 32)
				) const;

	// Field descriptor access

	VLIFieldDescriptor	GetFieldDescriptor (	// Return a field descriptor
					VLIFieldNumber inFieldNumber 					// which field to return
				) const;

	VLIStatus	SetFieldDescriptor (			// Set a field descriptor
					VLIFieldNumber inFieldNumber,				// which field to set
					const VLIFieldDescriptor &inDescriptor	// field descriptor
				);

	// Locking and unlocking

	VLIStatus	LockVolume (					// Lock volume onto a board
					VLILocation inLocation		// board on which to lock: kVLIAnyBoard for any board
				);

	VLIbool		IsLocked (void					// Return VLItrue if volume is locked
				) const;

	VLIStatus	UnlockVolume (					// Unlock the volume from a board
					VLIbool inUnloadToSource	// should VLI unload modified data back to the source?
				);

	// Access to model and correction matrices

	VLIStatus	SetModelMatrix (				// DEPRECATED Set the model matrix from the given one
					const VLIMatrix& inModel	// new model matrix to set in volume
				);

	VLIMatrix	GetModelMatrix (void			// DEPRECATED Return the model matrix
				) const;

	VLIStatus	SetCorrectionMatrix (			// Set the correction matrix
					const VLIMatrix& inCorrection	// new correction matrix to set in volume
				);

	VLIMatrix	GetCorrectionMatrix (void		// Return the correction matrix
				) const;

	// Subvolume Rendering

	VLIStatus	SetActiveSubVolumeSize (		// DEPRECATED Set the active subvolume size
					unsigned int inNX,			// size of active subvolume in X in voxels
					unsigned int inNY,			// size of active subvolume in Y in voxels
					unsigned int inNZ			// size of active subvolume in Z in voxels
				);

	void		GetActiveSubVolumeSize (		// DEPRECATED Return the active subvolume size
					unsigned int& inNX,			// RETURNED size of active subvolume in X in voxels
					unsigned int& inNY,			// RETURNED size of active subvolume in Y in voxels
					unsigned int& inNZ			// RETURNED size of active subvolume in Z in voxels
				) const;

	int GetActiveSubVolumeSizeX (void	// Return the active subvolume size in X
				) const;

	int GetActiveSubVolumeSizeY (void	// Return the active subvolume size in Y
				) const;
	
	int GetActiveSubVolumeSizeZ (void	// Return the active subvolume size in Z
				) const;

	VLIStatus	SetActiveSubVolumeOrigin (		// DEPRECATED Set the active subvolume origin
					unsigned int inNX,			// origin of active subvolume in X in voxels
					unsigned int inNY,			// origin of active subvolume in Y in voxels
					unsigned int inNZ			// origin of active subvolume in Z in voxels
				);

	void		GetActiveSubVolumeOrigin (		// DEPRECATED Return the active subvolume origin
					unsigned int& inNX,			// RETURNED origin of active subvolume in X in voxels
					unsigned int& inNY,			// RETURNED origin of active subvolume in Y in voxels
					unsigned int& inNZ			// RETURNED origin of active subvolume in Z in voxels
				) const;

	int GetActiveSubVolumeOriginX (void			// Return the active subvolume origin in X
				) const;

	int GetActiveSubVolumeOriginY (void			// Return the active subvolume origin in Y
				) const;
	
	int GetActiveSubVolumeOriginZ (void			// Return the active subvolume origin in Z
				) const;

	VLIStatus	SetActiveSubVolume (			// Set the active subvolume
					const VLIVolumeRange &inVolumeRange	// range for the active subvolume
				);

	VLIVolumeRange		GetActiveSubVolume (	// Return the active subvolume
				) const;

	VLIStatus		SetBorderValue (					// Set the border value (VLIuint32)
								VLIuint32 inBorderValue 		// border value (voxel value)
							);

	VLIuint32		GetBorderValue (void				// Return the border value
							) const;

	VLIStatus		SetExtendMode (						// Set extend modes for all dimensions
								ExtendMode inCommonMode			// extend mode to use for all dimension
							);

	VLIStatus		SetExtendModes (					// Set extend modes
								ExtendMode inXMode,				// extend mode to use for the X dimension
								ExtendMode inYMode,				// extend mode to use for the Y dimension
								ExtendMode inZMode				// extend mode to use for the Z dimension
							);

	void			GetExtendModes (					// Return extend modes
								ExtendMode &outXMode,			// RETURNED extend mode to use for the X dimension
								ExtendMode &outYMode,			// RETURNED extend mode to use for the Y dimension
								ExtendMode &outZMode			// RETURNED extend mode to use for the Z dimension
							) const;

	ExtendMode		GetExtendModeX (void				// Return extend mode to use for the X dimension
							) const;

	ExtendMode		GetExtendModeY (void				// Return extend mode to use for the Y dimension
							) const;

	ExtendMode		GetExtendModeZ (void				// Return extend mode to use for the Z dimension
							) const;

	// Updating the volume with new data

	VLIStatus	UpdateVolume (					// DEPRECATED Update a range of a volume with new data
					VLIuint32 inFormat,			// voxel format
					const void *inVoxels,		// new data
					unsigned int inTargetXVox,	// where to change the volume in X
					unsigned int inTargetYVox,	// where to change the volume in Y
					unsigned int inTargetZVox,	// where to change the volume in Z
					unsigned int inNXVox,		// size of the volume range in X
					unsigned int inNYVox,		// size of the volume range in Y
					unsigned int inNZVox,		// size of the volume range in Z
					VLIVolume::Layout layout	// layout: must be kSliced
				);

	VLIStatus	Update (					// Update a range of a volume with new data
					const void *inVoxels,				// data
					const VLIVolumeRange &inVolumeRange	// range of data to update
				);

	VLIStatus	Update (						// Update a range of a volume from another volume
					const VLIVolume * inVolume,	// volume supplying source
					const VLIVolumeRange &inDestinationRange,	// range of data to update
					int inSourceX,				// X Origin of source range
					int inSourceY,				// Y Origin of source range
					int inSourceZ,				// Z Origin of source range
					VLISource inSource			// Do we want the source or the buffer of inVolume?
												// (default: current target)
				);

	VLIStatus	UpdateField (					// Update a field of a range of a volume with new data
					const void				 * inVoxels,			// location of input data
					const VLIVolumeRange	 & inVolumeRange,		// range of volume to update
					const VLIFieldDescriptor & inDestinationField	// description of output
				);

	VLISyncEvent StartUpdate (					// ASYNCHRONOUS Start to Update a range of a volume with new data
					const void *inVoxels,		// data
					const VLIVolumeRange &inDestinationRange	// range of data to update
				);

	VLISyncEvent StartUpdate (					// ASYNCHRONOUS Start to update a range of a volume from another volume
					const VLIVolume * inVolume,	// volume supplying source
					const VLIVolumeRange &inDestinationRange,	// range of data to update
					int inSourceX,				// X Origin of source range
					int inSourceY,				// Y Origin of source range
					int inSourceZ,				// Z Origin of source range
					VLISource inSource		// Do we want the source or the buffer of inVolume?
												// (default: current target)
				);

	VLISyncEvent StartUpdateField (				// ASYNCHRONOUS Start to update a field of a range of a volume with new data
					const void				 * inVoxels,			// location of input data
					const VLIVolumeRange	 & inVolumeRange,		// range of volume to update
					const VLIFieldDescriptor & inDestinationField	// description of output
				);

	// Mapping the volume for application access

	VLIStatus	MapVolume ( 					// Return a pointer to 8-bit voxel data
					VLIAccessType inAccess,		// access type requested
					VLIuint8 *&outBaseAddress,	// RETURNED address of data
					unsigned int &outSx,		// RETURNED size of mapping in X, in voxels
					unsigned int &outSy,		// RETURNED size of mapping in Y, in voxels
					VLISource inSource			// Do we want the source or the buffer of inVolume?
				);

	VLIStatus	MapVolume ( 					// Return a pointer to 16-bit voxel data
					VLIAccessType inAccess,		// access type requested
					VLIuint16 *&outBaseAddress,	// RETURNED address of data
					unsigned int &outSx,		// RETURNED size of mapping in X, in voxels
					unsigned int &outSy,		// RETURNED size of mapping in Y, in voxels
					VLISource inSource			// Do we want the source or the buffer of inVolume?
				);

	VLIStatus	MapVolume ( 					// Return a pointer to 32-bit voxel data
					VLIAccessType inAccess,		// access type requested
					VLIuint32 *&outBaseAddress,	// RETURNED address of data
					unsigned int &outSx,		// RETURNED size of mapping in X, in voxels
					unsigned int &outSy,		// RETURNED size of mapping in Y, in voxels
					VLISource inSource			// Do we want the source or the buffer of inVolume?
				);

	VLIStatus	MapVolume ( 					// Return a pointer to voxel data
					VLIAccessType inAccess,		// access type requested
					void *&outBaseAddress,		// RETURNED address of data
					unsigned int &outSx,		// RETURNED size of mapping in X, in voxels
					unsigned int &outSy,		// RETURNED size of mapping in Y, in voxels
					VLISource inSource			// Do we want the source or the buffer of inVolume?
				);

	VLIStatus	MapSubVolume (					// DEPRECATED Return a pointer to a portion of voxel data
					VLIAccessType inAccess,		// access type requested
					unsigned int inAtX,			// position of volume range in X
					unsigned int inAtY, 		// position of volume range in Y
					unsigned int inAtZ,			// position of volume range in Z
					unsigned int inNx, 			// position of volume range in X
					unsigned int inNy, 			// position of volume range in Y
					unsigned int inNz,			// position of volume range in Z
					void *&outBaseAddress,		// RETURNED address of data
					unsigned int &outSx,		// RETURNED size of mapping in X, in voxels
					unsigned int &outSy,		// RETURNED size of mapping in Y, in voxels
					VLISource inSource			// Do we want the source or the buffer?
				);

	VLIStatus	MapSubVolume (					// Return a pointer to a portion of 8-bit voxel data
					VLIAccessType inAccess,		// access type requested
					const VLIVolumeRange & inVolumeRange,	// range of data to map
					VLIuint8 *&outBaseAddress,	// RETURNED address of data
					unsigned int &outSx,		// RETURNED size of mapping in X, in voxels
					unsigned int &outSy,		// RETURNED size of mapping in Y, in voxels
					VLISource inSource			// Do we want the source or the buffer?
				);

	VLIStatus	MapSubVolume (					// Return a pointer to a portion of 16-bit voxel data
					VLIAccessType inAccess,		// access type requested
					const VLIVolumeRange & inVolumeRange,	// range of data to map
					VLIuint16 *&outBaseAddress,	// RETURNED address of data
					unsigned int &outSx,		// RETURNED size of mapping in X, in voxels
					unsigned int &outSy,		// RETURNED size of mapping in Y, in voxels
					VLISource inSource			// Do we want the source or the buffer?
				);

	VLIStatus	MapSubVolume (					// Return a pointer to a portion of 32-bit voxel data
					VLIAccessType inAccess,		// access type requested
					const VLIVolumeRange & inVolumeRange,	// range of data to map
					VLIuint32 *&outBaseAddress,	// RETURNED address of data
					unsigned int &outSx,		// RETURNED size of mapping in X, in voxels
					unsigned int &outSy,		// RETURNED size of mapping in Y, in voxels
					VLISource inSource			// Do we want the source or the buffer?
				);

	VLIStatus	MapSubVolume (					// Return a pointer to a portion of voxel data
					VLIAccessType inAccess,		// access type requested
					const VLIVolumeRange & inVolumeRange,	// range of data to map
					void *&outBaseAddress,		// RETURNED address of data
					unsigned int &outSx,		// RETURNED size of mapping in X, in voxels
					unsigned int &outSy,		// RETURNED size of mapping in Y, in voxels
					VLISource inSource			// Do we want the source or the buffer?
				);

	VLIStatus	UnmapVolume (void				// Unmap volume or subvolume
				);

	// Unloading volume data to application memory

	VLIStatus	Unload (						// Unload volume data to application memory
					void * outVoxels,						// where to place the data
					const VLIVolumeRange & inVolumeRange,	// range of data to unload
					VLISource inSource						// Do we want the source or the buffer?
				) const;

	VLIStatus	UnloadField (							// Unload a field of volume data to application memory
					void * outVoxels,					// where to place the data
					const VLIVolumeRange	 & inVolumeRange,	// range of volume to unload
					const VLIFieldDescriptor & inVolumeField,	// description of field to unload
					VLISource inSource					// Do we want the source or the buffer?
				) const;

	VLISyncEvent StartUnload (					// ASYNCHRONOUS Start to unload volume data to application memory
					void * outVoxels,						// where to place the data
					const VLIVolumeRange & inVolumeRange,	// range of data to unload
					VLISource inSource						// Do we want the source or the buffer?
				) const;

	VLISyncEvent StartUnloadField (				// ASYNCHRONOUS Start to unload a field of volume data to application memory
					void * outVoxels,							// where to place the data
					const VLIVolumeRange	 & inVolumeRange,	// range of volume to unload
					const VLIFieldDescriptor & inVolumeField,	// description of field to unload
					VLISource inSource							// Do we want the source or the buffer?
				) const;

	// Other queries

	VLIbool		IsLoaded (void					// Return VLItrue if volume is loaded on a board
				) const;

	VLIAccessType GetAccessControl (void		// Return current access control
				) const;

	VLIStatus	Resize (						// Resize a sourceless volume
					unsigned int inNewSizeX,	// new size for X
					unsigned int inNewSizeY,	// new size for Y
					unsigned int inNewSizeZ,	// new size for Z
					VLIbool inResizeBuffer	// resize buffer also?
				);

	VLIStatus	Resize (							// Resize a volume
					const VLIVolumeRange & inNewRange,	// new addressing range for this volume
					VLIbool inResizeBuffer			// resize buffer also?
				);


	// Buffer routines

	VLIStatus	CreateBuffer (
					VLILocation inLocation		// Where to create buffer
				);

	VLIStatus	CreateBuffer (
					VLILocation inLocation,		// Where to create buffer
					unsigned int inSizeX,		// X size of buffer
					unsigned int inSizeY,		// Y size of buffer
					unsigned int inSizeZ		// Z size of buffer
				);

	VLIStatus	CreateBuffer (						// Create a buffer with the given range
					VLILocation inLocation, 		// Where to create buffer
					const VLIVolumeRange & inRange	// Size and offset for buffer
				);

	VLIBufferID	GetBufferID (void				// Return buffer ID or kVLINoBuffer
				) const;

	void		GetBufferSize (					// Return buffer size; all 0 if no buffer attached
					unsigned int & outSizeX,	// RETURNED size in X
					unsigned int & outSizeY,	// RETURNED size in Y
					unsigned int & outSizeZ		// RETURNED size in Z
				) const;

	unsigned int GetBufferSizeX (void			// Return buffer size in X; 0 if no buffer attached
				) const;

	unsigned int GetBufferSizeY (void			// Return buffer size in Y; 0 if no buffer attached
				) const;

	unsigned int GetBufferSizeZ (void			// Return buffer size in Z; 0 if no buffer attached
				) const;

	VLIVolumeRange	GetBufferRange (void		// Return buffer addressing range; all 0 if no buffer attached
				) const;


	VLIStatus	AttachBuffer (					// Attach this volume to the specified buffer
					VLIBufferID inBufferID		// Buffer ID
				);
	
	VLIStatus	ReleaseBuffer (void				// Release any buffer that may be attached
				);

	VLIStatus	SetBufferPermission (			// Set permission for other processes
					VLIPermission inBufferPermission
				);

	VLIPermission	GetBufferPermission (void	// Return permission
				) const;

	VLILocation	GetBufferLocation (void			// Return location of buffer
				) const;							// or kVLINoBuffer

	VLIStatus	ResizeBuffer (					// Change the size of the buffer
					unsigned int inNewSizeX,	// new size for X
					unsigned int inNewSizeY,	// new size for Y
					unsigned int inNewSizeZ		// new size for Z
				);

	VLIStatus	ResizeBuffer (						// Change the buffer addressing range (offset mode)
					const VLIVolumeRange & inNewRange		// new addressing range
				);

	VLIStatus	SetBufferWrap (						// Set addressing mode to kVLIWrapAddress and set the modulus values
					int inModulusX,					// modulus for X (must be a power of 2)
					int inModulusY,					// modulus for Y (must be a power of 2)
					int inModulusZ					// modulus for Z (must be a power of 2)
				);

	VLIStatus	SetBufferOffset (					// Set addressing mode to kVLIOffsetAddress and set the offset values
					int inOffsetX,					// offset for X (must be even)
					int inOffsetY,					// offset for Y (must be even)
					int inOffsetZ					// offset for Z (must be even)
				);

	void		GetBufferAddressParameters (		// Return the addressing parameters
					VLIAddressMode & outMode,		// RETURNED kVLIOffsetAddress or kVLIWrapAddress
					int &outAddressParameterX, 		// RETURNED offset or modulus for X
					int &outAddressParameterY,		// RETURNED offset or modulus for Y
					int &outAddressParameterZ		// RETURNED offset or modulus for Z
				) const;

	VLIStatus	SetBufferAddressParameters (		// Set the addressing parameters
					VLIAddressMode inMode,			// kVLIOffsetAddress or kVLIWrapAddress
					int inAddressParameterX, 		// offset or modulus for X
					int inAddressParameterY,		// offset or modulus for Y
					int inAddressParameterZ			// offset or modulus for Z
				);

	VLIAddressMode	GetBufferAddressMode (void		// Return kVLIOffsetAddress or kVLIWrapAddress
				) const;

	int			GetBufferAddressParameterX (		// Return the offset/modulus X field
				) const;

	int			GetBufferAddressParameterY (		// Return the offset/modulus Y field
				) const;
	
	int			GetBufferAddressParameterZ (		// Return the offset/modulus Z field
				) const;

	VLIStatus	SetTarget (						// Select source or buffer as target for updates
					VLITarget inNewTarget		// Do we want the source or the buffer?
				);

	VLITarget	GetTarget (void					// Return current target
				) const;

	// VLI 3.x rendering routines

	VLIStatus	Render (						// Render a volume to a color image
					const VLIContext * inContext,		// context (state)
					VLIImageBuffer * inOutColor0,	// color image 0 INPUT (FRONT) and/or OUTPUT
					VLIDepthBuffer * inOutDepth0,	// depth image 0 INPUT (NEAR)  and/or OUTPUT
					VLIImageBuffer * inOutColor1,	// color image 1 INPUT (BACK)  and/or OUTPUT
					VLIDepthBuffer * inOutDepth1	// depth image 1 INPUT (FAR)   and/or OUTPUT
				);

	VLISyncEvent StartRender (					// Start to render a volume to a color image
					const VLIContext * inContext,	// context (state)
					VLIImageBuffer * inOutColor0,	// color image 0 INPUT (FRONT) and/or OUTPUT
					VLIDepthBuffer * inOutDepth0,	// depth image 0 INPUT (NEAR)  and/or OUTPUT
					VLIImageBuffer * inOutColor1,	// color image 1 INPUT (BACK)  and/or OUTPUT
					VLIDepthBuffer * inOutDepth1	// depth image 1 INPUT (FAR)   and/or OUTPUT
				);

	VLIStatus	RenderMPR (
					const VLIContext * inContext,
					double inNegativeDistance,
					int inQuality,
					MPRMode inMode,
					VLIImageBuffer * inOutColor0
				);

	VLISyncEvent StartRenderMPR (
					const VLIContext * inContext,
					double inNegativeDistance,
					int inQuality,
					MPRMode inMode,
					VLIImageBuffer * inOutColor0
				);

	VLIStatus	ResampleBuffer (
					VLIVolume * pDestination,
					const VLIVolumeRange & inSourceRange,
					const VLIVolumeRange & inDestinationRange,
					const VLIClassifier & inClassifier
				);

	VLISyncEvent StartResampleBuffer (
									VLIVolume * pDestination,
									const VLIVolumeRange & inSourceRange,
									const VLIVolumeRange & inDestinationRange,
									const VLIClassifier &inClassifier
									);
	
	VLIStatus	SetSpaceLeapingParameters (
					SpaceLeapingMode inMode,
					double inThresholdRed	= -1,
					double inThresholdGreen	= -1,
					double inThresholdBlue	= -1,
					double inThresholdAlpha	= -1
				);

	void		GetSpaceLeapingParameters (
					SpaceLeapingMode & outMode,
					double & outThresholdRed,
					double & outThresholdGreen,
					double & outThresholdBlue,
					double & outThresholdAlpha
				) const;

	VLIStatus	RenderToVolume (					// ASYNCHRONOUS Start to peform a volume-to-volume render
					const VLIContext * inContext,	// Context (state) to use (INPUT)
					VLIVolume * inOutVolume,		// volume OUTPUT
					RenderToVolumeMode inMode		// special rendering mode
				);

	VLISyncEvent StartRenderToVolume (				// ASYNCHRONOUS Start to peform a volume-to-volume render
					const VLIContext * inContext,	// Context (state) to use (INPUT)
					VLIVolume * inOutVolume,		// volume OUTPUT
					RenderToVolumeMode inMode		// special rendering mode
				);

	// VLIVolumeInternal routines, not overrides of VLIVolume

public:
	// Constructor and destructor

	VLIVolumeInternal (VLIVolumeSource * pSource);	// Volume source 

	~VLIVolumeInternal (void);

	static VLIVolumeInternal * CreateSimpleVolume (		// Create VLI volume from main memory data (or sourceless)
					int inVoxelSize,					// size of voxels, in bits (must be 8, 16 or 32)
					const VLIVolumeRange & inRange,		// size and origin of the volume in voxels
					int inNumberOfFields = 0,			// number of fields in field array
					const VLIFieldDescriptor * inFieldArray = 0,	// field array
					void * inVoxels = 0 				// pointer to voxel data in slices
				);

	static VLIVolumeInternal * CreateSimpleVolume (		// Create VLI volume from application defined source
					VLIVolumeSource * inVolumeSource	// application defined source
				);

	VLISerialNumber GetBufferSerial (void) const
	{ 
		return m_bufferSerial; 
	}
	VLISerialNumber GetSourceSerial (void) const
	{ 
		return m_volumeSource->GetSerial(); 
	}

	VLIStatus SetSource (VLIVolumeSource * pSource, bool setAll);

	VLIVolumeSource * GetSource (void) const
	{
		return m_volumeSource;
	}

	VLISyncEvent DoStartRender (					// Start to render a volume to a color image
					const VLIContext * inContext,	// context (state)
					VLIImageBuffer * inOutColor0,	// color image 0 INPUT (FRONT) and/or OUTPUT
					VLIDepthBuffer * inOutDepth0,	// depth image 0 INPUT (NEAR)  and/or OUTPUT
					VLIImageBuffer * inOutColor1,	// color image 1 INPUT (BACK)  and/or OUTPUT
					VLIDepthBuffer * inOutDepth1	// depth image 1 INPUT (FAR)   and/or OUTPUT
				);

	VGBBuffer * GetVGBBuffer (void) { return m_buffer; }

	VLIStatus	PrepareVolume (void);				// Set up for rendering

	VLIStatus	FinishWithVolume (void);			// rendering complete

	VLISyncEvent		StraightRender(const VLIContext * inContext,
									   int inTrimMin, int inTrimMax,
										VLIImageBuffer * inOutColor0,	
										VLIImageBuffer * inOutColor1 =0,
										bool inLookupTableOn = false,
									    int inDim=2);

	VLISampleSpace		m_sampleSpace;
	VLIuint32			m_format;            // voxel format

private:


	VLIStatus	StartRenderCheckBuffers (			// CheckBuffers for StartRender	
					const VLIContext * inContext,
					VLIImageBuffer * inOutColor0,	// color image 0 INPUT (FRONT) and/or OUTPUT
					VLIDepthBuffer * inOutDepth0,	// depth image 0 INPUT (NEAR)  and/or OUTPUT
					VLIImageBuffer * inOutColor1,	// color image 1 INPUT (BACK)  and/or OUTPUT
					VLIDepthBuffer * inOutDepth1,	// depth image 1 INPUT (FAR)   and/or OUTPUT
					VLIImageBuffer*	&outImageBuffer
				);
	
	VLIStatus	StartRenderPrepareMaps (
					const VLIContext * inContext,
					VLILookupTable * lut[4]
				);


	inline VLISyncEvent VGB_START_RENDER (
					VGBBuffer * vgbImage0,
					VGBBuffer * vgbImage1,
					VGBBuffer * vgbDepth0,
					VGBBuffer * vgbDepth1,
					unsigned int writeTo
				);
	

	VLIStatus	StartRenderInitTempImage (VLIImageBuffer *outImageBuffer);

	VLISyncEvent	DoStartRenderAndWarp (					// Start to render a volume to a color image
		const VLIContext * inContext,	// context (state)
		VLIImageBuffer * inOutColor0,	// color image buffer 0
		VLIDepthBuffer * inOutDepth0,	// depth image buffer 0
		VLIImageBuffer * inOutColor1,	// color image buffer 1
		VLIDepthBuffer * inOutDepth1	// depth image buffer 1
		);
	
	VLISyncEvent Warp3DImage (const VLIContext * inContext, 
		VLIImageBuffer * inOutColor0, VLIImageBuffer * inOutColor1,
		const VLIImageRange & inRange,
		const VLIImageBuffer * inSource,
		const VLIImageRange & inSourceRange);

	VLIStatus	WaitForVolumeLoaded (void);

	// StartUpdateVolumeSource will update the given volume source
	// from the given input volume (source or buffer)

	VLISyncEvent StartUpdateVolumeSource (					// ASYNCHRONOUS Start to update a range of a volume from another volume
				const VLIVolume * inVolume,	// volume supplying source
				const VLIVolumeRange &inDestinationRange,	// range of data to update
				int inSourceX,	// X Origin of source range
				int inSourceY,	// Y Origin of source range
				int inSourceZ,	// Z Origin of source range
				VLISource inSource		// Do we want the source or the buffer of inVolume?
			);

	// StartUpdateVolumeBuffer will update this volume's buffer
	// from the given input volume (source or buffer)

	VLISyncEvent StartUpdateVolumeBuffer (			// ASYNCHRONOUS Start to update a range of a volume from another volume
				const VLIVolume * inVolume,	// volume supplying source
				const VLIVolumeRange &inDestinationRange,	// range of data to update
				int inSourceX,	// X Origin of source range
				int inSourceY,	// Y Origin of source range
				int inSourceZ,	// Z Origin of source range
				VLISource inSource		// Do we want the source or the buffer of inVolume?
			);

	// StartUpdateInternal does the work of StartUpdate, but assumes that all
	// protection checking has been done already.

	VLISyncEvent StartUpdateInternal (				// ASYNCHRONOUS Start to Update a range of a volume with new data
					const void * inVoxels,			// data
					const VLIVolumeRange & inDestinationRange,	// range of data to update
					int inSizeX = 0,				// stride: if 0, use range.XSize()
					int inSizeY = 0					// stride: if 0, use range.YSize()
				);

	VLISyncEvent StartUpdateBuffer (
					const VLIVolumeRange &inDestinationRange, 
					const void * inVoxels,
					int inSizeX,
					int inSizeY
				);

	VLISyncEvent StartUpdateBufferFromSource (
					const VLIVolumeRange &inDestinationRange, 
					VLIVolumeSource *pSource = NULL,
					int inSourceX = 0,
					int inSourceY = 0,
					int inSourceZ = 0
				);
	
	VLISyncEvent StartUpdateBufferOneMapFromSource (
					const VLIVolumeRange &inDestinationRange, 
					VLIVolumeSource *pSource,
					int inSourceX,
					int inSourceY,
					int inSourceZ
				);
	
	VLISyncEvent StartUpdateBufferOneCopyFromSource (
					const VLIVolumeRange &inDestinationRange, 
					VLIVolumeSource *pSource,
					int inSourceX,
					int inSourceY,
					int inSourceZ
				);

	VLISyncEvent StartUpdateBufferMap (
					const VLIVolumeRange &inDestinationRange, 
					const void * inVoxels,
					int inStrideX,
					int inStrideY,
					bool inCopyUnaligned
				);

	VLISyncEvent StartUpdateBufferMapFromSource (
					const VLIVolumeRange &inDestinationRange, 
					VLIVolumeSource *pSource,
					int inSourceX,
					int inSourceY,
					int inSourceZ,
					bool inCopyUnaligned
				);
	
	VLISyncEvent StartUpdateBufferKernel (
					const VLIVolumeRange &inDestinationRange, 
					const void * inVoxels,
					int inStrideX,
					int inStrideY
				);

	VLISyncEvent StartUpdateBufferKernelFromSource (
					const VLIVolumeRange &inDestinationRange, 
					VLIVolumeSource *pSource,
					int inSourceX,
					int inSourceY,
					int inSourceZ
				);

	VLISyncEvent StartUpdateBufferCopy (
					const VLIVolumeRange &inDestinationRange, 
					const void * inVoxels,
					int inStrideX,
					int inStrideY
				);

	VLISyncEvent StartUpdateBufferCopyFromSource (
					const VLIVolumeRange &inDestinationRange, 
					VLIVolumeSource *pSource,
					int inSourceX,
					int inSourceY,
					int inSourceZ
				);
#if 0
	VLISyncEvent StartUpdateBufferEverything (
					const VLIVolumeRange &inDestinationRange, 
					VLIVolumeSource *pSource,
					int inSourceX,
					int inSourceY,
					int inSourceZ
				);
#endif

	VLIStatus AllocateBuffer (
					VLILocation inLocation, 
					const VLIVolumeRange &inDesiredSubVolume
				);

	VLIStatus SetAllRenderingRegisters (
					const VLIContext * inContext,
					VLIImageBuffer * inColor0,
					VLIDepthBuffer * inDepth0,
					VLIImageBuffer * inColor1,
					VLIDepthBuffer * inDepth1,
					VLILookupTable* outLut[4],
					bool inIsSpaceLeaping
				);

	// RenderHang IC fix

	// Defines for pass control

#define kBlendLast				1
#define kOutputToI0				2
#define kOutputToI1				4

	VLIStatus			SetPartialRenderingRegistersforMultiPass(
											const VLIContext * inContext,
											VLIImageBuffer * inOutColor0,
											VLIImageBuffer * inOutColor1, 
											VLIDepthBuffer * inOutDepth0,
											VLIDepthBuffer * inOutDepth1,
											int inPassControl,
											int inCurrentPass = -1);

	VLIStatus			SetPartialRenderingRegistersforMultiPassSetBlendLast(
											VLIImageBuffer *inBlendLastImage);

	VLIStatus			SetPartialRenderingRegistersforMultiPassOutputImage(
											const VLIImageBuffer *inTempBuffer,
											const VLIImageBuffer *inOutputImageBuffer);

	VLIStatus			SetCommandQueuesBlocks(void);

	VLISyncEvent		DoStartResampleBuffer (
											VLIVolume * pDestination,
											const VLIVolumeRange & inSourceRange,
											const VLIVolumeRange & inDestinationRange,
											VLIClassifier inClassifier,
											sideways	inSideways, 
											VLIint64	originX = 0, 
											VLIint64	spacingX = 0);

	// for hw blending render

	int ComputeSpaceLeapingPass(int inCurrentRenderPass, const VLIContext *inContext);

	// Space leaping
	VLIStatus			SetSpaceLeapingRange(const VLIVolumeRange inSpaceLeapingRange);

	VLIStatus			SpaceLeapingInitTempImageBuffer(const int inWidth, const int inHeight);

	VLIStatus			CheckEdgeTransparency(const VLIContext *inContext,
											  VLIint32 outVolumeMin[3], 
											  VLIint32 outVolumeMax[3], 
											  VLIbool &outEmptyVolume);

	VLIbool				CheckOneEdgeTransparency(VLIuint64 *inHostImage, int inVolumeMaxSize, 
												int inRealVolumeMin[3],
												VLIint32 inOutVolumeMin[3], 
												VLIint32 inOutVolumeMax[3],int inRenderAxis, 
												bool inTest1stDim); //return true if empty volume



	// Allocate and reserve a page aligned buffer for this volume

	VLIStatus	AllocateHostBuffer (long inSizeNeeded);

	VLIStatus	AllocateHostBuffer (const VLIVolumeRange & inRange);

#if dCheckHostBufferUsage
	// release the host buffer
	void		ReleaseHostBuffer (void);

#define RELEASE_HOST_BUFFER()	do { ReleaseHostBuffer(); } while (0)

#define RELEASE_HOST_BUFFER_IF_ERROR(s_)	\
	do { if (VLIFailed(s_)) ReleaseHostBuffer(); } while (0)

#define RELEASE_HOST_BUFFER_IF_NOT_IN_PROGRESS(ev_)	\
	do { if ((ev_).Status() != kVLIInProgress) ReleaseHostBuffer(); } while (0)

#else
#define RELEASE_HOST_BUFFER()	do { /* nothing */ } while (0)
#define RELEASE_HOST_BUFFER_IF_ERROR(s_)	do { /* nothing */ } while (0)
#define RELEASE_HOST_BUFFER_IF_NOT_IN_PROGRESS(ev_)	do { /* nothing */ } while (0)
#endif

	// My data
	
	VLIVolumeSource		*m_volumeSource;	// Where to get voxels when needed

	Layout				m_layout;			// Sliced, blocked...
	int					m_voxelSizeBytes;
	bool				m_readOnly;
	bool				m_hasData;			// Backup data in main memory or a file
											// If false, it only contains data when locked into voxel memory
	VLISyncEvent		m_waitForLoad;		// If true, we started a load and haven't waited for it
	bool				m_releaseMapping;	// We have started to load from a mapped volume; we need to release it

	// We have a lot of subvolumes hanging around

	// m_wholeVolume is (will be) the whole volume; all offsets are 0

	// m_userSubVolume is the subvolume the app wants
	//      if offsets and sizes are zero, use m_wholeVolume
	
	// m_currentSubVolume is m_userSubVolume intersected with m_wholeVolume
	//      it is the subvolume we want to render.
	//      PrepareVolume computes this

	// On the board, we have potentially other subvolumes

	// m_loadedVolume is the portion of m_wholeVolume that is loaded
	//      in voxel memory. Actually loaded, so this is set by
	//      LoadSubVolume, not by allocating a board volume.
	
	VLIVolumeRange		m_wholeVolume;		// Full volume

	VLIVolumeRange		m_userSubVolume;	// What the user asked for
	bool				m_renderFullVolume;

	VLIVolumeRange		m_currentSubVolume;	// userSubVolume clipped to volume limits

	bool				m_locked;
	bool				m_fullyLoaded;		// Loaded completely onto a board
	bool				m_partlyLoaded;		// True if a subvolume is currently loaded

	unsigned int		m_mapCount;
	VLIVolumeRange		m_changedBuffer;

	VGBBuffer *			m_buffer;				// Buffer information from VGB wrapper
	VGBBoard *			m_board;				// m_board may now be != 0 but without
	bool				m_bufferValid;			// a valid volume. 
	VLIVolumeRange		m_bufferRange;			// Volume range for the buffer
	bool				m_partialVolumeLocked;	// boardSize < currentSubVolume.m_size

	VLIVolumeRange		m_loadedVolume;		// (sub)volume currently loaded
	bool				m_FinishWithVolumeShouldReleaseVolume; // private communication from PrepareVolume
												// to FInishWithVolume

	void				* m_mapAddress;
	void				* m_mappedVoxelMemory;	// be able to have a mapped file & locked???jch
	VLIuint32			  m_mappedOffset;	
	VLIuint32			  m_mappedSize;
	char				* m_hostBufferBase;
	char				* m_hostBufferAddress;		// page aligned
	unsigned int		  m_hostBufferSize;
	VLISyncEvent		  m_hostBufferEvent;
#if dCheckHostBufferUsage
	bool				  m_hostBufferBusy;
#endif

	VLIFieldDescriptor	m_fields[kVLIMaxVoxelFields];

	ExtendMode			m_extendModes[3];
	VLIuint32			m_borderValue;

	VLIMatrix			m_correctionMatrix;
	VLIAddressMode		m_bufferAddressMode;
	VLILocation			m_bufferLocation;
	VLIBufferID			m_bufferID;
	VLIPermission		m_bufferPermission;
	VLIAccessInternal	m_bufferAccess;
	VLISerialNumber		m_bufferSerial;
	VLITarget			m_target;

	VLIRenderCache		m_renderCache;
	VLIAllRenderRegisters m_regs;

#if qSeparateStateAndRenderBlocks
	VGBCommandBuffer *	m_stateBuffer;
	VGBCommandBlockID	m_stateBlock;
	unsigned int		m_stateBlockSize;
#endif

	VGBCommandBuffer *	m_renderBuffer;
	VGBCommandBlockID	m_renderBlock;
	unsigned int		m_renderBlockSize;

	VLISyncEvent		m_lastRenderEvent;

	// Status if new changes from app
	bool				m_newSampleSpace;
	bool				m_newClassifier;
	bool				m_newControl;
	bool				m_newThreshold;
	bool				m_newImageValues;
	bool				m_newLighting;
	bool				m_newTrim;
	bool				m_newCrop;
	bool				m_newCutplane;
	bool				m_newDepthValues;
	bool				m_newImageFieldSel;

	bool				m_needDepthRegisters;

	// RenderHang IC fix
	VLIImageBufferInternal *	m_tempImageBuffer;
	
	//MPR
	
	VLICutPlane	*				m_MPR;
	bool						m_MPRRGBOn;
	bool						m_MPRSumAndCountOn;
	double						m_MPRScale;
	double                      m_MPRPreScale;

	VLIImageBufferInternal *	m_sumAndCountBuffer; //SumAndCountBuffer
	char *						m_mprBuffer;
	long						m_mprBufferSize;
	VLISyncEvent                m_mprUnloadEvent;				



	// Perspective handling
	PerspInterf *		m_perspInterface;		// Interface with perspective library

	// When updating and unloading YZ slices, we create a cache of some
	// portion of the volume in a "sideways" direction -- reordered as
	// Y, Z, X. This allows us to unload one YZ slice with fast DMA.

	// The cache has valid data when m_cacheSerialNumber is equal to 
	// the main volume's buffer serial number. The cache has more
	// recent data than the main volume buffer when a YZ slice update
	// has been done -- this is noted by m_cacheHasLatestData.
	// All volume updates, unload and render operations should always
	// call UpdateVolumeFromCache() before doing anything else

	// Cache data members are labelled mutable because they can
	// be updated within the const methods for Unload, etc.

	class VolumeCacheForYZSlices
	{
	public:
		VolumeCacheForYZSlices ();
		~VolumeCacheForYZSlices();

		VLILocation					GetLocation() const {return m_location;}
		VLIVolumeRange				GetRange () const {return m_volumeRange;}
		const VLIVolumeInternal *	GetVolume() const {return m_volume;}
		VLIVolumeInternal*			GetVolume()       {return m_volume;}
		void						SetLocation (VLILocation inLocation);
		VLIStatus					SetVolumeRange (VLIRange inRange);
		VLIStatus					SetFieldDescriptors (const VLIFieldDescriptor inFieldArray[]);
		void						SetVoxelSize (int inVoxelSize);

		VLIStatus					Resize(VLIVolumeRange inVolumeRange, bool & );
		
	private:

		VLIStatus					DoResize ();

		// Private data

		bool						m_mustResize;

		VLIVolumeInternal *			m_volume;
		VLIVolumeRange				m_volumeRange;
		unsigned int				m_voxelSize;
														// between boards
		VLILocation					m_location;			// Current location of blend volume
		VLIFieldDescriptor			m_fieldDescriptor[kVLIMaxVoxelFields];

	};

	mutable VolumeCacheForYZSlices 		m_cacheForYZSlices;
	mutable VLIVolumeRange				m_cacheRange;
	mutable VLISerialNumber				m_cacheSerialNumber;
	mutable bool						m_cacheHasLatestData;

	VLISyncEvent	UnloadOptimizedYZSlice (				// ASYNCHRONOUS Start to unload a field of volume data to application memory
						void * outVoxels,							// where to place the data
						const VLIVolumeRange	 & inVolumeRange,	// range of volume to unload
						VLISource inSource							// Do we want the source or the buffer?
					) const;

	VLISyncEvent	UpdateOptimizedYZSlice(		// ASYNCHRONOUS Start to unload a field of volume data to application memory
						const void * inVoxels,						// where to place the data
						const VLIVolumeRange	 & inVolumeRange,	// range of volume to unload
						VLITarget inSource							// Do we want the source or the buffer of inVolume?
					); 

	VLIStatus		UpdateVolumeFromCache(
						void
					) const;

	VLISyncEvent	UnloadVolumeToCache (
						VLIVolumeRange	 inVolumeRange
					) const;

	//////////////////////////////////////////////////////////////////
	// The member function variables neeeded for space leaping
	//            Before create derivation
	//
	//
	/////////////////////////////////////////////////////////////////

	//-----------------------------------------------------------------------------
	/////////////////////////////////////////////////////////////////
	// volumeBrick info
	/////////////////////////////////////////////////////////////////
	bool				BlockTestOverlap(int splitBlock, int testBlock, int inOption, int &dim);
	VLIStatus			SplitBlocks();
	int					SplitConflictOfThreeBlock(int inBlockI, int inBlockJ, int inBlockK,
												  int splitDim,int inOption, BlockSortHelper & helper);
	VLIStatus			SplitBlock(int n, int splitPoint[3], int inOption, int inSplitDim);
	void				SplitCycles( int inOption, BlockSortHelper & helper);
	bool				SplitCycle(const TVectorInt &cycle, int inBlock, int inOption, BlockSortHelper & helper);
	VLIStatus			MergeBlock(int inStartBrick);

	class VLIVolumeBrick
	{
	public:
		VLIVolumeBrick ()
			: m_range (),
			  m_isTransparent (VLIfalse),
			  m_isGroup (false),
			  m_isHead (false),
			  m_gIndex (-1)
		{
			for (int i=0; i <4; i++)
				m_isSplit[i] = false;
		}

		VLIbool IsTransparent () {return m_isTransparent;}
		bool IsGroup() const {return m_isGroup;}
		bool IsRenderingBrick() const {return (!m_isTransparent && (!m_isGroup || m_isHead));}
		bool IsRenderingBrick(int inOption) const {return (!m_isTransparent && (!m_isGroup || m_isHead || m_isSplit[inOption]));}
			
		void SetTransparentFlag(VLIbool iFlag) {m_isTransparent = iFlag;}

		void SetIndex(int inX, int inY, int inZ)
		{
			m_index[0] = inX;
			m_index[1] = inY;
			m_index[2] = inZ;
		}

		void SetRange(int xMin, int xSize,
					  int yMin, int ySize,
					  int zMin, int zSize)
		{
			m_range.XOrigin() =xMin;
			m_range.YOrigin() =yMin;
			m_range.ZOrigin() =zMin;

			m_range.XSize() =xSize;
			m_range.YSize() =ySize;
			m_range.ZSize() =zSize;
		}

		VLIVolumeRange m_range;

		VLIbool m_isTransparent;
		bool m_isHead;
		bool m_isGroup;
		bool m_isSplit[4];
		int  m_splitIndex[4];

		int  m_index[3];
		int  m_endIndex[3];
		int  m_gIndex;
		int  m_numOfSplitBlock;
	};

	VLIStatus PreRenderIndex(int inMaxBlock);
	bool SortUntilConflict(int option, BlockSortHelper & helper);
	bool SortGroupUntilConflict(TVectorInt &group, int option, BlockSortHelper & helper);
	void ComputeRenderOrderMatrix(int option, BlockSortHelper & helper);
	void RecomputeRenderOrderMatrix(int splitBlockIndex, int newBlockIndex, int option, BlockSortHelper & helper);
	void ExtractBlockRange (int inOption, const VLIVolumeBrick & inBlock, int outStart[3], int outEnd[3]);

	VLIVolume::SpaceLeapingMode m_spaceLeapingMode;			// Set by SetSpaceLeapingParameters()
	VLIBlendMode m_spaceLeapingBlendMode;					// Calculated when IsSpaceLeapingRefreshContext()
	double m_spaceLeapingThreshold[kVLIMaxOutputChannels];	// Set by SetSpaceLeapingParameters()
	VLIuint16 m_spaceLeapingThre12[kVLIMaxOutputChannels];	// Calculated when IsSpaceLeapingRefreshContext()

#ifdef hpux
	vector <VLIVolumeBrick>	m_listOfBricks;
#else
	std::vector <VLIVolumeBrick>	m_listOfBricks;
#endif

	int				m_numOfBricksDimension[3];
	int				m_numOfVisibleBrick;
	int				m_numOfRenderBrick;
	int				m_numOfSplitBlock;
	int				m_brickSize;
	bool			m_newBricks;
	int *			m_brickIndex;
	int				m_lastOption;	// 0-3 for positive direction, 4-7 for negative
	TVectorInt		m_preRenderList[4];
	VLIbool			m_FTB;

	VLISpaceLeapingCache m_spaceLeapingCache;

	int				m_currentRenderPass;
	
	VLIStatus ClearSpaceLeaping();
	VLIStatus InitializeSpaceLeaping();
	VLIStatus CheckSpaceLeapingTransparency(const VLIContext *inContext );
	VLIStatus CreateSpaceLeapingVolumeInfo (const VLIContext *inContext );

	VLIStatus SetSpaceLeapingCommandQueuesBlocks(int blockNum, bool zShift, int blockCount);
	VLIStatus GenerateSpaceLeapingIndex();

	VLIbool IsSpaceLeapingRefreshContext(const VLIContext *inContext, VLIbool &isNeedNewSpaceLeaping);
	VLIint32 m_spaceLeapingEdgeMin[3], m_spaceLeapingEdgeMax[3];
	VLIVolumeRange		m_spaceLeapingRange;
};

// Utility method that lives in VLIVolumeRender.cpp and is used to set
// the last volume rendered state for image and depth buffers.

extern void SetLastVolumeRendered (
		VLISerialNumber inVolumeID,
		const VLIContext * inContext,	// context (state)
		VLIImageBuffer * inOutColor0,	// color image buffer 0
		VLIDepthBuffer * inOutDepth0,	// depth image buffer 0
		VLIImageBuffer * inOutColor1,	// color image buffer 1
		VLIDepthBuffer * inOutDepth1	// depth image buffer 1
	);


// Some aids and utilities for debugging use
// They are not dependent on _DEBUG because we may
// want to use them in release code also.

const char *VliGetStatusString(VLIStatus status);


// Timer stuff.

#if qUsePerformanceCounter

typedef __int64 TIMER_TimeT;
TIMER_TimeT TimerTimeStamp (void);

#elif defined (_WIN32)	// Win32, but not USE_PERFORMANCE_COUNTER

typedef long TIMER_TimeT;
inline TIMER_TimeT TimerTimeStamp (void)
{
	return (TIMER_TimeT) GetTickCount();
}

#else // Not Win32; use UNIX calls

#include <sys/time.h>

typedef struct timeval	TIMER_TimeT;
inline TIMER_TimeT TimerTimeStamp (void)
{
	struct timeval		temp;
	gettimeofday (&temp, NULL);
	return (TIMER_TimeT) temp;
}

#endif

TIMER_TimeT TimerTimeStamp (void);
double TimerSecondsBetween (TIMER_TimeT first, TIMER_TimeT second);
void TimerOutputTime (TIMER_TimeT first, TIMER_TimeT second, const char * what);
void TimerOutputSpeed (TIMER_TimeT first, TIMER_TimeT second, const char * where, const char * units = 0, double mult = 1.0);

#define TIMER_DECLARE_VARIABLES	\
	TIMER_TimeT	timer_start, timer_end

#define TIMER_START_TIMING	\
	timer_start = TimerTimeStamp()

#define TIMER_STOP_TIMING	\
	timer_end = TimerTimeStamp()

#define TIMER_OUTPUT_TIMING(_string)	\
	TimerOutputTime (timer_start, timer_end, _string)

// Tracing facility. 

#if qTracing

typedef unsigned int	VliTraceMask;

static const VliTraceMask	kvliTraceEnterBit		= 0x01;
static const VliTraceMask	kvliTraceExitBit		= 0x02;
static const VliTraceMask	kvliTraceErrorExitBit	= 0x04;
static const VliTraceMask	kvliTraceTraceBit		= 0x08;
static const VliTraceMask	kvliTraceMessageBit		= 0x10;
static const VliTraceMask	kvliTraceArgumentBit	= 0x20;

static const int kNumberTraceMasks = 10;
extern VliTraceMask		gTraceMaskArray[kNumberTraceMasks];
static const int kTraceIDNone	= 0;
static const int kTraceIDAll	= 1;
static const int kTraceIDEnter	= 2;
static const int kTraceIDError	= 3;
static const int kTraceIDVolume	= 4;

class VliTraceClass
{
public:
	VliTraceClass (int traceID, VLISerialNumber inObjectID, const char * funcName, VLIStatus * returnStatus, 
						const char * fileName, int lineNumber);
	~VliTraceClass (void);
	
	void Trace (const char * inTypeName);
	void Trace (VLIStatus inStatus);
	void TraceBack (void);

	void Output (const char * inFormat, ...);

	void AddArgument (const char * inFormat, ...);

	int				m_traceID;
	char			m_objectID[16];
	VliTraceMask	m_mask;
	const char *	m_idName;
	int				m_indent;
	const char *	m_funcName;
	const char *	m_fileName;
	int				m_lineNumber;
	VLIStatus *		m_returnStatus;
	VliTraceClass *	m_previous;				// trace back up the stack
	char			m_argString[1000];
};

extern VliTraceClass * gTraceStack;

#define ROUTINE_TRACE_STATUS(id_,name_,status_) \
VliTraceClass trace_local (id_, GetObjectID(), name_, &status_, __FILE__, __LINE__);

#define ROUTINE_TRACE(id_,name_) \
VliTraceClass trace_local (id_, GetObjectID(), name_, 0, __FILE__, __LINE__);

#define ROUTINE_TRACE_NOSHARE(id_,name_) \
VliTraceClass trace_local (id_, 0, name_, 0, __FILE__, __LINE__);

#define ROUTINE_ARGUMENT(arg_)	\
	trace_local.AddArgument arg_;

#else // not qTracing

#define ROUTINE_TRACE_STATUS(id_,name_,status_)	/* nothing */
#define ROUTINE_TRACE(id_,name_)	/* nothing */
#define ROUTINE_TRACE_NOSHARE(id_,name_) /* nothing */
#define ROUTINE_ARGUMENT(args_) /* nothing */

#endif // not qTracing



//	D.M. All template definitions must reside in an include file
// VLIListInternal support

template<class T> VLIListInternal<T>::VLIListInternal(void)
:	m_maxElements (0),
	m_allocElements (0),
	m_curElements (0),
	m_array (0),
	m_listChanged (true)
{
}

// Note: no need to try/catch around calls to new, because
// this will be created as part of a VLIContextInternal, and
// that creation is protected.

template <class T> VLIListInternal<T>::VLIListInternal (unsigned int maxElements, unsigned int defElements)
:	m_maxElements (maxElements),
	m_allocElements (defElements),
	m_curElements (0),
	m_array ( defElements > 0 ? (new Triplet [defElements]) : 0 ),
	m_listChanged (true)
{
	// If m_maxElements > 0 then m_allocElements cannot be greater than that
	VLI_ASSERT (m_maxElements == 0 || m_allocElements <= m_maxElements);

	// If m_allocElements > 0 then m_array must be non null
	VLI_ASSERT (m_allocElements == 0 || m_array != 0);
}

template <class T> void VLIListInternal<T>::ReleaseAllObjects (void)
{
	VLI_ASSERT (m_curElements <= m_allocElements);

	// Release all elements in the array, if any
	for (unsigned int i = 0; i < m_curElements; i++)
	{
		VLI_ASSERT (m_array[i].pObject != 0);
		m_array[i].pObject->Release();
	}

	// Delete the array

	delete [] m_array;
	m_curElements = 0;
	m_allocElements = 0;
	m_array = 0;
	m_listChanged = true;
}

template <class T> VLIListInternal<T>::~VLIListInternal (void)
{
	ReleaseAllObjects ();
}

// Copy constructor

// Note: No try/catch around calls to new -- see normal constructor

template <class T> VLIListInternal<T>::VLIListInternal (const VLIListInternal<T> & inCopyFrom)
:	m_maxElements (inCopyFrom.m_maxElements),
	m_allocElements (inCopyFrom.m_allocElements),
	m_curElements (inCopyFrom.m_curElements),
	m_array (inCopyFrom.m_allocElements > 0 ? (new Triplet [inCopyFrom.m_allocElements]) : 0),
	m_listChanged (true)
{
	
	// If m_maxElements > 0 then m_allocElements cannot be greater than that
	// ditto for m_curElements
	VLI_ASSERT (m_maxElements == 0 || m_allocElements <= m_maxElements);
	VLI_ASSERT (m_maxElements == 0 || m_curElements <= m_maxElements);

	// If m_allocElements > 0 then m_array must be non null
	VLI_ASSERT (m_allocElements == 0 || m_array != 0);

	VLI_ASSERT (m_curElements <= m_allocElements);

	for (unsigned int i = 0; i < m_curElements; i++)
	{
		VLI_ASSERT (inCopyFrom.m_array[i].pObject != 0);
		m_array[i].pObject = inCopyFrom.m_array[i].pObject;
		m_array[i].pObject->AddRef();
		m_array[i].objectNumber = 0;
		m_array[i].serialNumber = 0;
	}

}

// Copy operator

// Note: no try/catch around the calls to new.

template <class T> VLIListInternal<T> & VLIListInternal<T>::operator= (const VLIListInternal<T> &inCopyFrom)
{
	// Check incoming list

	// If m_maxElements > 0 then m_allocElements cannot be greater than that
	// ditto for m_curElements
	VLI_ASSERT (inCopyFrom.m_maxElements == 0 || inCopyFrom.m_allocElements <= inCopyFrom.m_maxElements);
	VLI_ASSERT (inCopyFrom.m_maxElements == 0 || inCopyFrom.m_curElements <= inCopyFrom.m_maxElements);

	// If inCopyFrom.m_allocElements > 0 then inCopyFrom.m_array must be non null
	VLI_ASSERT (inCopyFrom.m_allocElements == 0 || inCopyFrom.m_array != 0);

	VLI_ASSERT (inCopyFrom.m_curElements <= inCopyFrom.m_allocElements);

	// Create new list

	Triplet * newList = 
				(inCopyFrom.m_allocElements > 0 
					? (new Triplet [inCopyFrom.m_allocElements])
					: 0 );
	VLI_ASSERT (inCopyFrom.m_allocElements == 0 || newList != 0);

	// Now copy from the source to the new list

	for (unsigned int i = 0; i < inCopyFrom.m_curElements; i++)
	{
		VLI_ASSERT (inCopyFrom.m_array[i].pObject != 0);
		newList[i].pObject = inCopyFrom.m_array[i].pObject;
		newList[i].pObject->AddRef();
		newList[i].objectNumber = 0;	// New object for this list
		newList[i].serialNumber = 0;
	}

	// now swap newList for the current list
	// and set the parameters correctly

	Triplet * temp = newList;
	newList = m_array;
	m_array = temp;

	m_listChanged = true;
	m_maxElements = inCopyFrom.m_maxElements;
	m_allocElements = inCopyFrom.m_allocElements;

	unsigned int numToRelease = m_curElements;

	m_curElements = inCopyFrom.m_curElements;

	// Finally, get rid of the old list, now pointed to by newList
	// If one of the Release calls throws, there is a memory leak here.

	for (unsigned int j = 0; j < numToRelease; ++j)
	{
		VLI_ASSERT (newList[j].pObject);
		newList[j].pObject->Release();
	}

	delete [] newList;

	return *this;

}

template <class T> VLIStatus VLIListInternal<T>::Add(T *element)
{
	if (element == 0) return kVLIErrArgument;

	// First check to see if already in the list

	for (int i = 0; i < m_curElements; i++)
	{
		if (m_array[i].pObject == element)
		{
			return kVLIErrDuplicate;
		}
	}

	// Do we already have the maximum?

	if (m_maxElements > 0 && m_curElements == m_maxElements)
	{
		return kVLIErrTooMany;
	}

	if (m_curElements >= m_allocElements)
	{
		// We don't have enough room to add one more
		unsigned int		new_size = 8;

		if (m_allocElements != 0) 
		{
			new_size = m_allocElements * 2;
		}

		if (m_maxElements > 0 && new_size > m_maxElements)
		{
			new_size = m_maxElements;
		}

		Triplet * new_array = 0;
		VLI_SAFE_NEW (new_array, Triplet [new_size] );
		if (new_array == 0)
		{
			return kVLIErrAlloc;
		}

		// Copy the old pointers to the new array

		for (unsigned int i = 0; i < m_curElements; i++)
		{
			VLI_ASSERT (m_array[i].pObject != 0);
			new_array[i] = m_array[i];
			// Don't call AddRef since we are destroying the old pointer soon
		}

		delete [] m_array;

		m_array = new_array;

		m_allocElements = new_size;

	}

	element->AddRef();

	m_array[m_curElements].pObject = element;
	m_array[m_curElements].objectNumber = 0;
	m_array[m_curElements].serialNumber = 0;

	++m_curElements;

	m_listChanged = true;

	return kVLIOK;

}

template <class T> VLIStatus VLIListInternal<T>::Remove(T *element)
{
	// First check to see if already in the list

	if (element == 0) return kVLIErrArgument;

	for (unsigned int i = 0; i < m_curElements; i++)
	{
		VLI_ASSERT (m_array[i].pObject != 0);
		if (m_array[i].pObject == element)
		{
			// We want to remove this one and shift
			// all the others down one.
			while (++i < m_curElements)
			{
				m_array[i-1] = m_array[i];
			}
			--m_curElements;
			m_listChanged = true;
			
			element->Release();

			return kVLIOK;
		}
	}

	// Not here, bad argument

	return kVLIErrArgument;

}

template <class T> bool VLIListInternal<T>::HasNewData(void)
{

	if (m_listChanged) return true;

	for (unsigned int i = 0; i < m_curElements; i++)
	{
		if (m_array[i].pObject->GetObjectID() != m_array[i].objectNumber
			|| m_array[i].pObject->GetSerial() != m_array[i].serialNumber)
		{
			return true;
		}
	}

	return false;

}

template <class T> void VLIListInternal<T>::ResetSerialNumbers(void)
{
	m_listChanged = false;

	for (unsigned int i = 0; i < m_curElements; i++)
	{
		m_array[i].objectNumber = m_array[i].pObject->GetObjectID();
		m_array[i].serialNumber = m_array[i].pObject->GetSerial();
	}

}


// Special version of smart pointers for objects that must be
// released rather than deleted

template<class T> class ReleasablePointer
{
public:
	ReleasablePointer ()
		: ptr (NULL)
	{ }

	ReleasablePointer (T* inPtr)
		: ptr (inPtr)
	{ }

	~ReleasablePointer ()
	{
		if (ptr)
			ptr->Release();
	}

	void Assign (T* inPtr)
	{
		if (ptr)
			ptr->Release();
		ptr = inPtr;
	}

	operator T* () const
	{
		return ptr;
	}

	T* operator -> () const
	{
		return ptr;
	}

	T* GetPointer() const { return ptr; }

private:
	T* ptr;
};


#endif   /* VLIINTERNAL */
