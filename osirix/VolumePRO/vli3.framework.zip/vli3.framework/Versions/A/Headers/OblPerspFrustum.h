/*
 * $Id: OblPerspFrustum.h,v 1.3 2002/10/14 21:03:37 vesper Exp $
 *
 *    Copyright 2002 by Real Time Visualization, TeraRecon, Inc.
 *    All Rights Reserved.
 *
 */  
// Oblique Perspective Frustum - Object Declaration
#ifndef OBLPERSPFRUSTUM_H
#define OBLPERSPFRUSTUM_H

class OblPerspFrustum {
public:

  // Constructors
  OblPerspFrustum ();

  // Create with everything needed to Render the Frustum
  OblPerspFrustum (PolygonST3H &nearPoly, DualHyper &nearHyper, DualHyper &farHyper,
                   Mat44 &pmvMat);

  // Create with Dual Hyperbolics, and Matrix
  OblPerspFrustum (DualHyper &nearHyper, DualHyper &farHyper, Mat44 &pmvMat);

#ifdef NEVER
  // Create with Scale Factor, Dual Hyperbolics, and Matrix
  OblPerspFrustum (VolContr &inVolContr, DualHyper &inNearHyper, DualHyper &inFarHyper,
                   Mat44 &inPmvMat);
#endif

  // Operate on Oblique Perspective Frustum

  // Create Near Polygon from Box in S,T
  void CreateNearPoly (Tile2D &inTileST, Point3D &inVolDim,
                       int inNearSide);

  // Create Near Polygon from Box in S,T
  void CreateNearPoly (Tile2D &inTileST, PointST3H &inClipMin,
                       PointST3H &inClipMax, int inNearSide);

  // Transform Near Polygon
  void Transform (void);

  // DivideW Near Polygon (gives NearPoly in Screen Coordinates)
  void DivideW (void);

  // Calculate Far X,Y, Z = 0 (Direct from S,T,Far)
  void CalcFarXYZ (int inVerbose = 0);

  // Get/Put

  // For now return the Near and Far Polygons, later return a reference
  PolygonST3H GetNearPoly (void);
  PolygonST3H GetFarPoly  (void);

  // Calculate the Near Z, Far Z, and number of Steps of sampling
  void CalcStepsZ (PointST3H &inVolMin, PointST3H &inVolMax, int inNearSide,
                   double inScaleZ, double &nearZ, double &farZ, int &stepsZ);

  // Calculate Scale X,Y for the Frustum
  void CalcScaleXY (double &outScaleX, double &outScaleY);

private:

#ifdef NEVER
  // SuperSampling Scale Factors
  Point3D mSampMult;
#endif

  // Near Polygon used to Represent the Rectangle of the Frustum
  //  where it intersects the plane of the near side of the volume
  PolygonST3H mNearPoly;

  // Far Polygon used to Represent the Rectangle of the Frustum
  //  where it intersects the plane of the far side of the volume
  PolygonST3H mFarPoly;

  // Dual Hyperbolic functions for Near and Far
  DualHyper mNearHyper, mFarHyper;

  // Perspective, Model View Matrix
  Mat44 mPmvMat;
};
#endif
