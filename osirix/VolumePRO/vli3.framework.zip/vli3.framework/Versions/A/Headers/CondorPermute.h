/*
 * $Id: CondorPermute.h,v 1.2 2002/10/14 21:03:36 vesper Exp $
 *
 *    Copyright 2002 by Real Time Visualization, TeraRecon, Inc.
 *    All Rights Reserved.
 *
 */  
// CondorPermute.h - Condor Permutation Matrix Functionality Declaration
#ifndef CONDORPERMUTE_H
#define CONDORPERMUTE_H


// CondorPermute - Class Declaration
class CondorPermute {
public:

  // Constructors
  // Default Constructor, permutation not yet specified
  CondorPermute ();

  // Constructor with "Top Left Origin" setting
  CondorPermute (bool inTLOrig);

  // Permutation Matrix set by the view Vector in Object Space
  CondorPermute (Point3D &inEye, Point3D &inSight);

  // Permutation Matrix set by the view Vector in Object Space
  //  with optional "Top Left Origin" boolean
  CondorPermute (Point3D &inEye, Point3D &inSight, bool inTLOrig);


  // Get/Set Methods

  // Set Condor Permute State, given an Eye Point, and Sight Point
  bool SetPermute (Point3D &inEye, Point3D &inSight);

  // Get the Current Transform Register member variable
  int  GetTransformReg (void);

  // Set the Transform Register and member storage
  void SetTransformReg (int inReg);

  // Operate on the Condor Permutation Object

  // Apply the Condor Permute Transformation (P)
  void PermuteToXYZ (Point3D &inOutPt);

  // Apply the Inverse Condor Permute Transformation (P inv)
  void PermuteToUVW (Point3D &inOutPt);

  // Apply the Inverse PST Permute Transformation (PST inv)
  void PermutePSTtoUVW (Point3D &inOutPt);

  // Permute Polygon3D from PST to Permuted XYX
  void PermutePolyPSTtoXYZ (Polygon3D &inOutPoly);

  // Print Permute Object
  void Print (void);

private:

  // Set Default "Noop" Permute Transform
  void SetDefaultPermute (void);

  // Fields needed to construct the Transform Register
  // Special case indicating Top Left, or Bottom Left Origin
  bool mTopLeftOrigin;

  // Combined Case allows direct index of the Permute Case
  int mCombinedCase;

  // U,V,W axis are assigned to X, Y, Z Permutation axis
  int mSelectX, mSelectY, mSelectZ;

  // Signs of X, Y, Z axis
  int mNegX, mNegY, mNegZ;

  // Permute Coordinate Adjustment factor
  double mAdjX, mAdjY, mAdjZ;

  // Transform Register
  int mTransformReg;
};

#endif
