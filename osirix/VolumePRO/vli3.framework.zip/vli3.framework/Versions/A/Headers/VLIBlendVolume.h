/*
 *  $Id: VLIBlendVolume.h,v 1.10 2004/10/19 17:07:00 vesper Exp $
 *
 *    Copyright 2002,2003,2004 by Real Time Visualization, TeraRecon, Inc.
 *    All Rights Reserved.
 *
 */
// VLIBlendVolume.h: interface for the VLIBlendVolume class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(VLIBLENDVOLUME_H_)
#define VLIBLENDVOLUME_H_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "vliinternal.h"
#include "vliimagebuffer.h"

class VLIBlendVolume
{
public:
	VLIBlendVolume ();
	~VLIBlendVolume();

	int							GetBufferNumber() const {return m_bufferNumber;}
	int							GetNumSubvolumes() const {return m_numSubvolumes;}
	const VLIVolumeRange		GetRange () const {return m_volumeRange;}
	VLIImageBufferInternal*		GetBuffer(int i) {return m_buffer3D[i];}
	VLIVolumeInternal*			GetVolume(int i) {return m_volume[i];}

	
	void						SetBufferNumber (int inBufferNumber);
	VLIStatus					SetVolumeRange (VLIRange inRange);
	VLIStatus					SetFieldDescriptors (const VLIFieldDescriptor inFieldArray[]);
	void						SetVoxelSize (int inVoxelSize);

	void						SetNumOfSubvolumes (int inNumOfSubvolumes);

	VLIStatus					Resize(VLIImageRange inImageRange);
	VLIStatus					Resize(VLIVolumeRange inVolumeRange);
	
	VLISyncEvent				StartUpdate(int inBlendIndex[],char* inTransferBuffers[], const VLIImageRange & inLimits);
	
	VLISyncEvent				Render(	
										VLIContext*		inContext,
										VLIImageBuffer*	buffer0,
										VLIImageBuffer*	buffer1);

private:

	VLIStatus					DoResize ();

	// Private data

	bool						m_mustResize;

	VLIVolumeInternal*			m_volume[kMultiboardMaxVolumes];
	VLIVolumeRange				m_volumeRange;
	unsigned int				m_voxelSize;
	VLIImageBufferInternal*		m_buffer3D[kMultiboardMaxVolumes];		// 3D buffer
													// between boards
	int							m_bufferNumber;		// Current buffer to use
	int							m_numSubvolumes;
	int							m_numBoards;
	VLIFieldDescriptor			m_fieldDescriptor[kVLIMaxVoxelFields];

};



	


#endif 
