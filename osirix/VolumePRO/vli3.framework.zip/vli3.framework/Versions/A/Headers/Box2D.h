/*
 * $Id: Box2D.h,v 1.4 2004/04/13 20:11:58 ford Exp $
 *
 *    Copyright 2002 by Real Time Visualization, TeraRecon, Inc.
 *    All Rights Reserved.
 *
 */  
// Box2D.h - Box in X,Y,Z - Object Declaration
// Used to calculate the min, max extent of a set of Points in X,Y,Z
#ifndef BOX2D_H
#define BOX2D_H

// Tile2D Class Declaration
// #include "Tile2D.h"

class Box2D {
public:

  // Constructor
  Box2D ();
  Box2D ( const Point2D &inPoint);
  Box2D ( const Point2D &inMin,  const Point2D &inMax);
  Box2D (double inMinX, double inMinY, double inMaxX, double inMaxY);

  // Special Initialization
  void InitMaxMin (void);

  // Operate on the Box

  // Add to the area of the Box using a single X,Y coordinate
  void Update (double inX, double inY);

  // Add to the area of the Box using coordinates from another Box2D
  void Update ( const Box2D &inBox2D);

  // Limit the Box2D to lie within the Range of the Input Argument
  void Limit ( const Box2D &inLimit);

  // Test for Area Non-Null by detecting positive width, height
  bool NonNull (void) const ;

  // Add a new form of Update
//void Update (Point2D &inPt);

  // Get/Put
  Point2D GetMin (void) const ;
  Point2D GetMax (void) const ;
  double GetMinX (void) const ;
  double GetMinY (void) const ;
  double GetMaxX (void) const ;
  double GetMaxY (void) const ;

  void SetMin (Point2D &inPoint);
  void SetMax (Point2D &inPoint);
  void SetMinX (double &inX);
  void SetMinY (double &inY);
  void SetMaxX (double &inX);
  void SetMaxY (double &inY);

private:

  // One Point stores the Min, one stores the Max
  Point2D m_min, m_max;
};
#endif
