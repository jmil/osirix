/*
 * $Id: PermuteTiler.h,v 1.4 2004/04/13 20:25:23 ford Exp $
 *
 *    Copyright 2002-2004 by Real Time Visualization, TeraRecon, Inc.
 *    All Rights Reserved.
 *
 */  
// Permute Tiler - Calculate all the Tiles of an area with const. Perm. Mat
#ifndef PERMUTETILER_H
#define PERMUTETILER_H

class PermuteTiler {
public:

  // Constructor
  PermuteTiler (const Tile2D &inScrSize, const PolygonST3H &inNear, const PolygonST3H &inFar,
                const Point3D &inVolDepth, int inNearSide);

  PermuteTiler (const Tile2D &inScrSize, const PolygonST3H &inNear, const PolygonST3H &inFar,
                const PointST3H &inVolMin, const PointST3H &inVolMax, int inNearSide);

  // Operate on Permute Tiler

  // Initialize Tiling
  void InitTiling (void);

  // Calculate Deltas
  void CalcDeltas (void);

  // Get/Put

  // Get Next Tile, return "valid tile"
  bool GetNextTile (Tile2D &outTile);

  // Get tile with extra rows and columns for pre-warp (don't advance to next tile)
  bool GetExtendedTile (Tile2D &outTile, double inExtendX, double inExtendY);

  // Print the PermuteTiler internal values
  void Print (void);

private:

  // Size of Screen
  Tile2D mScrSize;

  // Near Polygon used to Represent the Rectangle of the Frustum
  //  where it intersects the plane of the near side of the volume
  PolygonST3H mNearPoly;

  // Far Polygon used to Represent the Rectangle of the Frustum
  //  where it intersects the plane of the far side of the volume
  PolygonST3H mFarPoly;

  // Dimensions of the Volume, used to determine depth through the volume
  PointST3H mVolMin, mVolMax;
  Point3D   mVolDepth;

  // Cube side more near the EyePoint
  int mNearSide;

  // Condor Delta and Double Delta Registers
  // Xv Registers
  double Xv0;
  double dXv_dXs, dXv_dYs, dXv_dZs;
  double d_dXv_dXs_dZs, d_dXv_dYs_dZs;

  // Yv Registers
  double Yv0;
  double dYv_dXs, dYv_dYs, dYv_dZs;
  double d_dYv_dXs_dZs, d_dYv_dYs_dZs;

  // Key locations in Xs, Ys for partitioning the screen
  double n45Xs, npXs, p45Xs;
  double n45Ys, npYs, p45Ys;

  // Tile iterator
  int mTileNo;
};
#endif
