/*
 * $Id: VectMat.h,v 1.3 2002/10/14 21:03:39 vesper Exp $
 *
 *    Copyright 2002 by Real Time Visualization, TeraRecon, Inc.
 *    All Rights Reserved.
 *
 */  
// VectMat.h - Vector and Matrix Class Definitions
// Taken from Vli.h, and before that from Graphics Gems
#ifndef VECTMAT_H
#define VECTMAT_H

typedef VLIVector2D Vector2D;
typedef VLIVector3D Vector3D;

void TransPointHom(VLIMatrix inMatrix, const VLIVector3D& inVector, VLIVector3D& outVector);

#endif // VECTMAT_H
